/**
 *
 *
 * @module @sorrell/docs-ui/ApiReference
 *
 * @file      ApiReference.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { ApiReferencePageProps } from "./Types.js";
export declare const ApiReferencePage: ({ record, navigation }: ApiReferencePageProps) => import("react").JSX.Element;
//# sourceMappingURL=ApiReference.d.ts.map