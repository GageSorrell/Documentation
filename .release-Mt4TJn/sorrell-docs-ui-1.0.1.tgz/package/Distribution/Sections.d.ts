/**
 *
 *
 * @module @sorrell/docs-ui/Sections
 *
 * @file      Sections.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { InstallCommandProps, LlmDocument } from "./Types.js";
import { type ReactNode } from "react";
export declare const InstallCommand: ({ command }: InstallCommandProps) => import("react").JSX.Element;
export declare const ArticlePage: ({ title, description, breadcrumbs, document, children }: {
    readonly title: string;
    readonly description?: string;
    readonly breadcrumbs?: ReactNode;
    readonly document: LlmDocument;
    readonly children: ReactNode;
}) => import("react").JSX.Element;
export declare const QuoteRail: ({ author, quote }: {
    readonly quote: string;
    readonly author: string;
}) => import("react").JSX.Element;
export declare const Faq: ({ items }: {
    readonly items: ReadonlyArray<{
        readonly question: string;
        readonly answer: ReactNode;
    }>;
}) => import("react").JSX.Element;
export declare const Cta: ({ title, children, href, label }: {
    readonly title: string;
    readonly children?: ReactNode;
    readonly href: string;
    readonly label: string;
}) => import("react").JSX.Element;
export declare const DocsFooter: ({ children }: {
    readonly children?: ReactNode;
}) => import("react").JSX.Element;
//# sourceMappingURL=Sections.d.ts.map