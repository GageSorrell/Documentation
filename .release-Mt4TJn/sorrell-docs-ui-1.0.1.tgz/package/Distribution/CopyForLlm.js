import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { formatAgentDocument } from "@sorrell/docs-core";
import { useCallback, useState } from "react";
export /** @internal */ const formatLlmDocument = formatAgentDocument;
const copyWithFallback = async (value) => {
    if (typeof navigator !== "undefined" && navigator.clipboard !== undefined) {
        await navigator.clipboard.writeText(value);
        return;
    }
    const textarea = document.createElement("textarea");
    textarea.value = value;
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand("copy");
    textarea.remove();
};
export /** @internal */ const CopyForLlmButton = ({ document }) => {
    const [copied, setCopied] = useState(false);
    const onCopy = useCallback(async () => {
        await copyWithFallback(formatAgentDocument(document));
        setCopied(true);
        window.setTimeout(() => setCopied(false), 1600);
    }, [document]);
    return (_jsxs("button", { "aria-live": "polite", className: "docs-copy-button", onClick: onCopy, type: "button", children: [_jsx("span", { "aria-hidden": "true", children: copied ? "✓" : "⧉" }), copied ? "Copied" : "Copy for LLM"] }));
};
//# sourceMappingURL=CopyForLlm.js.map