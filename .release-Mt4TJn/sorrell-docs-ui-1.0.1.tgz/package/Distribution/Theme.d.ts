/**
 *
 *
 * @module @sorrell/docs-ui/Theme
 *
 * @file      Theme.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { type ReactNode } from "react";
import type { DesignTokens } from "@sorrell/docs-core";
import type { ThemeMode } from "./Types.js";
interface ThemeContextValue {
    readonly mode: ThemeMode;
    readonly resolvedMode: "light" | "dark";
    readonly setMode: (mode: ThemeMode) => void;
    readonly toggleMode: () => void;
}
export declare const createThemeCss: (tokens: DesignTokens) => string;
export declare const ThemeProvider: ({ children, initialMode }: {
    readonly children: ReactNode;
    readonly initialMode?: ThemeMode;
}) => import("react").JSX.Element;
export declare const useTheme: () => ThemeContextValue;
export declare const ThemeToggle: () => import("react").JSX.Element;
export {};
//# sourceMappingURL=Theme.d.ts.map