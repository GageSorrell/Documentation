/**
 *
 *
 * @module @sorrell/docs-ui/Landing
 *
 * @file      Landing.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { LandingPageProps } from "./Types.js";
import type { ReactNode } from "react";
export declare const LandingPage: ({ content, installCommand, children }: LandingPageProps) => import("react").JSX.Element;
export declare const LandingSection: ({ children, title, eyebrow }: {
    readonly children: ReactNode;
    readonly title: string;
    readonly eyebrow?: string;
}) => import("react").JSX.Element;
//# sourceMappingURL=Landing.d.ts.map