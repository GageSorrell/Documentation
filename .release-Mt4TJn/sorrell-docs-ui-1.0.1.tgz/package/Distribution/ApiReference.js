import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Breadcrumbs, DocsSidebar, OnThisPage } from "./Navigation.js";
import { CopyForLlmButton } from "./CopyForLlm.js";
import { DocCode } from "./Mdx.js";
import { apiReferenceRecordToAgentDocument } from "@sorrell/docs-core";
const declarationHref = (id) => `#${id}`;
const sourceHref = (source) => [
    `${source.repositoryUrl}/blob/`,
    `${source.revision}/`,
    source.file,
    source.line === undefined ? "" : `#L${source.line}`
].join("");
const apiNavigation = (record) => record.categories.map((category) => ({
    items: record.declarations
        .filter((declaration) => declaration.categoryId === category.id)
        .map((declaration) => ({
        active: false,
        href: declarationHref(declaration.id),
        label: declaration.name
    })),
    label: category.label
}));
const tocItems = (record) => record.categories.map((category) => ({
    children: record.declarations
        .filter((declaration) => declaration.categoryId === category.id)
        .map((declaration) => ({
        href: declarationHref(declaration.id),
        label: declaration.name
    })),
    href: `#category-${category.id}`,
    label: category.label
}));
const declarationDocument = (record, name, description, signature) => ({
    content: `${description}\n\n${signature}`,
    context: `${record.packageName} ${record.version}`,
    description,
    id: `${record.packageId}:${record.module}:${name}`,
    kind: "api-module",
    metadata: {
        declarationKind: record.declarations.find((declaration) => declaration.name === name)?.kind ?? "unknown"
    },
    title: name,
    url: `${record.link?.href ?? ""}#${name}`,
    version: record.version
});
export /** @internal */ const ApiReferencePage = ({ record, navigation = [] }) => {
    const groups = navigation.length === 0 ? apiNavigation(record) : navigation;
    const document = apiReferenceRecordToAgentDocument(record);
    return (_jsxs("div", { className: "docs-api-page", children: [_jsx(DocsSidebar, { groups: groups, label: "API Reference" }), _jsxs("main", { className: "docs-api-main", children: [_jsx(Breadcrumbs, { items: record.breadcrumbs }), _jsxs("div", { className: "docs-api-heading-row", children: [_jsxs("div", { children: [_jsx("h1", { children: record.displayName }), _jsx("p", { children: record.summary })] }), _jsx(CopyForLlmButton, { document: document })] }), _jsxs("div", { className: "docs-api-meta", children: [_jsxs("span", { children: [record.exportCount, " exports"] }), record.introductionVersion === undefined ? null : (_jsxs("span", { children: ["Added in ", record.introductionVersion] })), record.source === undefined ? null : (_jsx("a", { href: sourceHref(record.source), children: "\u25C9 Source \u2197" }))] }), record.categories.map((category) => (_jsxs("section", { className: "docs-api-category", id: `category-${category.id}`, children: [_jsx("h2", { children: category.label }), record.declarations
                                .filter((declaration) => declaration.categoryId === category.id)
                                .map((declaration) => (_jsxs("article", { className: "docs-api-declaration", id: declaration.id, children: [_jsxs("div", { className: "docs-declaration-heading", children: [_jsxs("h3", { children: [_jsx("a", { "aria-label": `Link to ${declaration.name}`, className: "docs-declaration-anchor", href: declarationHref(declaration.id), children: "#" }), declaration.name, declaration.kind ===
                                                        "interface" ? (_jsx("span", { className: "docs-kind-badge", children: "INTERFACE" })) : null] }), _jsxs("div", { className: "docs-declaration-links", children: [declaration.introductionVersion ===
                                                        undefined ? null : (_jsxs("span", { children: ["Added in", " ", declaration.introductionVersion] })), declaration.source ===
                                                        undefined ? null : (_jsx("a", { href: sourceHref(declaration.source), children: "Source \u2197" })), _jsx(CopyForLlmButton, { document: declarationDocument(record, declaration.name, declaration.description, declaration.signature) })] })] }), _jsx("p", { children: declaration.description }), _jsx("h4", { children: "Signature" }), _jsx(DocCode, { language: "typescript", children: declaration.signature })] }, declaration.id)))] }, category.id)))] }), _jsx(OnThisPage, { items: tocItems(record) })] }));
};
//# sourceMappingURL=ApiReference.js.map