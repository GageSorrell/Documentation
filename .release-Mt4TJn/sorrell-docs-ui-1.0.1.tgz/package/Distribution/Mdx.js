import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/**
 *
 *
 * @module @sorrell/docs-ui/Mdx
 *
 * @file      Mdx.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { useState } from "react";
export /** @internal */ const DocCode = ({ children, language = "text" }) => (_jsxs("div", { className: "docs-code-block", children: [_jsx("div", { className: "docs-code-language", children: language }), _jsx("pre", { children: _jsx("code", { children: children }) })] }));
export /** @internal */ const Callout = ({ children, tone = "note", title }) => (_jsxs("aside", { className: `docs-callout docs-callout-${tone}`, children: [title === undefined ? null : _jsx("strong", { children: title }), _jsx("div", { children: children })] }));
export /** @internal */ const Tabs = ({ tabs }) => {
    const [active, setActive] = useState(0);
    return (_jsxs("div", { className: "docs-tabs", children: [_jsx("div", { "aria-label": "Examples", className: "docs-tab-list", role: "tablist", children: tabs.map((tab, index) => (_jsx("button", { "aria-selected": index === active, className: index === active ? "is-active" : undefined, onClick: () => setActive(index), role: "tab", type: "button", children: tab.label }, tab.label))) }), _jsx("div", { className: "docs-tab-panel", role: "tabpanel", children: tabs[active]?.content })] }));
};
export /** @internal */ const Heading = ({ level = 2, id, children }) => {
    const Tag = `h${level}`;
    return (_jsxs(Tag, { className: "docs-heading", id: id, children: [children, id === undefined ? null : (_jsx("a", { "aria-label": `Link to ${String(children)}`, className: "docs-heading-link", href: `#${id}`, children: "#" }))] }));
};
//# sourceMappingURL=Mdx.js.map