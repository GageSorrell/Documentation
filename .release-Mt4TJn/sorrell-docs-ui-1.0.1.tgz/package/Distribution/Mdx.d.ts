/**
 *
 *
 * @module @sorrell/docs-ui/Mdx
 *
 * @file      Mdx.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { type ReactNode } from "react";
export declare const DocCode: ({ children, language }: {
    readonly children: ReactNode;
    readonly language?: string;
}) => import("react").JSX.Element;
export declare const Callout: ({ children, tone, title }: {
    readonly children: ReactNode;
    readonly tone?: "note" | "warning" | "tip";
    readonly title?: string;
}) => import("react").JSX.Element;
export declare const Tabs: ({ tabs }: {
    readonly tabs: ReadonlyArray<{
        readonly label: string;
        readonly content: ReactNode;
    }>;
}) => import("react").JSX.Element;
export declare const Heading: ({ level, id, children }: {
    readonly level?: 2 | 3 | 4;
    readonly id?: string;
    readonly children: ReactNode;
}) => import("react").JSX.Element;
//# sourceMappingURL=Mdx.d.ts.map