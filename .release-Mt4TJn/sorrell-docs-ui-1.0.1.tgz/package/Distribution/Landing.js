import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/**
 *
 *
 * @module @sorrell/docs-ui/Landing
 *
 * @file      Landing.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { InstallCommand } from "./Sections.js";
export /** @internal */ const LandingPage = ({ content, installCommand, children }) => (_jsxs("div", { className: "docs-landing", children: [_jsxs("section", { className: "docs-landing-hero", children: [_jsx("div", { className: "docs-eyebrow", children: "Documentation toolkit" }), _jsx("h1", { children: content.title }), _jsx("p", { children: content.description }), installCommand === undefined ? null : (_jsx(InstallCommand, { command: installCommand }))] }), _jsx("section", { "aria-label": "Documentation sections", className: "docs-landing-grid", children: content.sections.map((section) => (_jsxs("a", { className: "docs-landing-card", href: section.href ?? `#${section.id}`, children: [_jsx("span", { className: "docs-card-index", children: section.id }), _jsx("h2", { children: section.title }), _jsx("p", { children: section.body }), _jsx("span", { "aria-hidden": "true", className: "docs-card-arrow", children: "\u2197" })] }, section.id))) }), children] }));
export /** @internal */ const LandingSection = ({ children, title, eyebrow }) => (_jsxs("section", { className: "docs-landing-section", children: [eyebrow === undefined ? null : (_jsx("div", { className: "docs-eyebrow", children: eyebrow })), _jsx("h2", { children: title }), children] }));
//# sourceMappingURL=Landing.js.map