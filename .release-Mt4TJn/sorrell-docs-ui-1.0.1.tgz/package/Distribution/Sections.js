import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useCallback, useState } from "react";
import { CopyForLlmButton } from "./CopyForLlm.js";
export /** @internal */ const InstallCommand = ({ command }) => {
    const [copied, setCopied] = useState(false);
    const copy = useCallback(async () => {
        if (navigator.clipboard !== undefined) {
            await navigator.clipboard.writeText(command);
        }
        setCopied(true);
        window.setTimeout(() => setCopied(false), 1400);
    }, [command]);
    return (_jsxs("button", { "aria-label": "Copy install command", className: "docs-install-command", onClick: copy, type: "button", children: [_jsx("code", { children: command }), _jsx("span", { children: copied ? "Copied" : "Copy" })] }));
};
export /** @internal */ const ArticlePage = ({ title, description, breadcrumbs, document, children }) => (_jsxs("article", { className: "docs-article", children: [breadcrumbs, _jsxs("div", { className: "docs-article-topline", children: [_jsxs("div", { children: [_jsx("h1", { children: title }), description === undefined
                            ? null
                            : (_jsx("p", { className: "docs-article-description", children: description }))] }), _jsx(CopyForLlmButton, { document: document })] }), _jsx("div", { className: "docs-prose", children: children })] }));
export /** @internal */ const QuoteRail = ({ author, quote }) => (_jsxs("figure", { className: "docs-quote-rail", children: [_jsxs("blockquote", { children: ["\u201C", quote, "\u201D"] }), _jsxs("figcaption", { children: ["\u2014 ", author] })] }));
export /** @internal */ const Faq = ({ items }) => (_jsx("section", { className: "docs-faq", children: items.map((item) => (_jsxs("details", { children: [_jsxs("summary", { children: [item.question, _jsx("span", { "aria-hidden": "true", children: "+" })] }), _jsx("div", { children: item.answer })] }, item.question))) }));
export /** @internal */ const Cta = ({ title, children, href, label }) => (_jsxs("section", { className: "docs-cta", children: [_jsxs("div", { children: [_jsx("h2", { children: title }), children] }), _jsxs("a", { href: href, children: [label, " ", _jsx("span", { "aria-hidden": "true", children: "\u2197" })] })] }));
export /** @internal */ const DocsFooter = ({ children = "Built for readable, durable documentation." }) => (_jsxs("footer", { className: "docs-footer", children: [_jsx("span", { children: children }), _jsxs("span", { children: ["\u00A9 ", new Date().getFullYear(), " Sorrell"] })] }));
//# sourceMappingURL=Sections.js.map