/**
 *
 *
 * @module @sorrell/docs-ui/Navigation
 *
 * @file      Navigation.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { BreadcrumbItem, DocumentationNavGroup, DocumentationNavItem } from "./Types.js";
import { type ReactNode } from "react";
export declare const DocsHeader: ({ title, links, repositoryHref }: {
    readonly title?: string;
    readonly links?: ReadonlyArray<DocumentationNavItem>;
    readonly repositoryHref?: string;
}) => import("react").JSX.Element;
export declare const DocsSidebar: ({ groups, label }: {
    readonly groups: ReadonlyArray<DocumentationNavGroup>;
    readonly label?: string;
}) => import("react").JSX.Element;
export declare const Breadcrumbs: ({ items }: {
    readonly items: ReadonlyArray<BreadcrumbItem>;
}) => import("react").JSX.Element;
export declare const OnThisPage: ({ items }: {
    readonly items: ReadonlyArray<DocumentationNavItem>;
}) => import("react").JSX.Element;
export declare const DocumentationShell: ({ children, title, headerLinks: InHeaderLinks, navigation: InNavigation, toc: InToc, repositoryHref }: {
    readonly children: ReactNode;
    readonly title?: string;
    readonly headerLinks?: ReadonlyArray<DocumentationNavItem>;
    readonly navigation?: ReadonlyArray<DocumentationNavGroup>;
    readonly toc?: ReadonlyArray<DocumentationNavItem>;
    readonly repositoryHref?: string;
}) => import("react").JSX.Element;
//# sourceMappingURL=Navigation.d.ts.map