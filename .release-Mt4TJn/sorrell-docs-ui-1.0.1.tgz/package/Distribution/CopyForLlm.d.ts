/**
 *
 *
 * @module @sorrell/docs-ui/CopyForLlm
 *
 * @file      CopyForLlm.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { AgentDocument } from "@sorrell/docs-core";
export declare const formatLlmDocument: (document: AgentDocument) => string;
export declare const CopyForLlmButton: ({ document }: {
    readonly document: AgentDocument;
}) => import("react").JSX.Element;
//# sourceMappingURL=CopyForLlm.d.ts.map