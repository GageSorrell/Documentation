/**
 * MCP transport and tool definitions for documentation corpora.
 *
 * @module @sorrell/docs-mcp/Server
 *
 * @file      Server.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { AgentCorpusSchema, AgentDocumentSchema, AgentManifestSchema, AgentSearchIndexSchema } from "@sorrell/docs-core";
import { Context, Effect, Layer, Schema } from "effect";
import { HttpRouter, HttpServer, HttpServerResponse } from "effect/unstable/http";
import { McpProtocol, McpServer as McpServerModule, Tool, Toolkit } from "effect/unstable/ai";
/** @internal */
export class McpCorpus extends Context.Service()("sorrell/docs-mcp/McpCorpus") {
}
const wordPattern = /[a-z0-9][a-z0-9_-]*/giu;
const termsFor = (document) => [
    ...new Set(`${document.id} ${document.title} ${document.description ?? ""} ${document.content}`
        .toLocaleLowerCase()
        .match(wordPattern) ?? [])
].sort();
export /** @internal */ const buildSearchIndex = (corpus, checksum) => ({
    checksum,
    entries: corpus.documents
        .map((document) => ({
        id: document.id,
        ...(document.version === undefined
            ? {}
            : { version: document.version }),
        terms: termsFor(document)
    }))
        .sort((left, right) => `${left.version ?? ""}:${left.id}`.localeCompare(`${right.version ?? ""}:${right.id}`)),
    version: 1
});
const score = (document, query) => {
    const terms = termsFor(document);
    return query
        .toLocaleLowerCase()
        .split(/\s+/u)
        .filter(Boolean)
        .reduce((total, term) => total +
        (terms.includes(term)
            ? 3
            : terms.some((value) => value.includes(term))
                ? 1
                : 0), 0);
};
export /** @internal */ const searchDocuments = (corpus, query, version, limit = 20) => corpus.documents
    .filter((document) => version === undefined || document.version === version)
    .map((document) => ({ document, score: score(document, query) }))
    .filter((value) => value.score > 0)
    .sort((left, right) => right.score - left.score ||
    left.document.title.localeCompare(right.document.title))
    .slice(0, Math.max(1, Math.min(limit, 100)))
    .map((value) => value.document);
const SearchDocs = Tool.make("search_docs", {
    description: "Search the versioned documentation corpus.",
    parameters: Schema.Struct({
        limit: Schema.optional(Schema.Number),
        query: Schema.String,
        version: Schema.optional(Schema.String)
    }),
    success: Schema.Array(AgentDocumentSchema)
});
const GetDocument = Tool.make("get_document", {
    description: "Get one documentation article, API module, or component by id.",
    parameters: Schema.Struct({
        id: Schema.String,
        version: Schema.optional(Schema.String)
    }),
    success: AgentDocumentSchema
});
const GetApi = Tool.make("get_api", {
    description: "Get one API reference module by id.",
    parameters: Schema.Struct({
        id: Schema.String,
        version: Schema.optional(Schema.String)
    }),
    success: AgentDocumentSchema
});
const ListVersions = Tool.make("list_versions", {
    description: "List documentation versions.",
    success: Schema.Array(Schema.String)
});
const ListPackages = Tool.make("list_packages", {
    description: "List package ids represented in the current documentation corpus.",
    success: Schema.Array(Schema.String)
});
const ListComponents = Tool.make("list_components", {
    description: "List Storybook component documentation.",
    success: Schema.Array(AgentDocumentSchema)
});
export /** @internal */ const DocumentationToolkit = Toolkit.make(SearchDocs, GetDocument, GetApi, ListVersions, ListPackages, ListComponents);
const findDocument = (corpus, id, version, kind) => {
    const value = corpus.documents.find((document) => document.id === id &&
        (version === undefined || document.version === version) &&
        (kind === undefined || document.kind === kind));
    return value === undefined
        ? Effect.die(`Documentation document not found: ${id}`)
        : Effect.succeed(value);
};
const toolkitLayer = Layer.effectContext(Effect.gen(function* () {
    const source = yield* McpCorpus;
    return yield* DocumentationToolkit.toHandlers({
        get_api: ({ id, version }) => findDocument(source.corpus, id, version, "api-module"),
        get_document: ({ id, version }) => findDocument(source.corpus, id, version),
        list_components: () => Effect.succeed(source.corpus.documents.filter((document) => document.kind === "component")),
        list_packages: () => Effect.succeed([
            ...new Set(source.corpus.documents.flatMap((document) => typeof document.metadata?.packageId ===
                "string"
                ? [document.metadata.packageId]
                : []))
        ].sort()),
        list_versions: () => Effect.succeed(source.manifest.versions),
        search_docs: ({ query, version, limit }) => Effect.succeed(searchDocuments(source.corpus, query, version, limit))
    });
}));
const resourceLayers = (corpus) => corpus.documents.reduce((layer, document) => Layer.merge(layer, McpServerModule.resource({
    content: Effect.succeed(document.content),
    description: document.description,
    mimeType: "text/markdown",
    name: document.id,
    uri: document.url
})), Layer.empty);
export /** @internal */ const makeMcpLayer = (source, transport, path = "/") => {
    const sourceLayer = Layer.succeed(McpCorpus, source);
    const serverOptions = {
        description: "Search and retrieve Sorrell documentation.",
        name: "sorrell-documentation",
        protocols: [McpProtocol.v2025_06_18],
        version: "1.0.1",
        ...(transport === "http" ? { path } : {})
    };
    const transportLayer = transport === "http"
        ? McpServerModule.layerHttp({
            ...serverOptions,
            path: path
        })
        : McpServerModule.layerStdio(serverOptions);
    return Layer.mergeAll(transportLayer, McpServerModule.toolkit(DocumentationToolkit), resourceLayers(source.corpus)).pipe(Layer.provide(toolkitLayer), Layer.provide(sourceLayer));
};
export /** @internal */ const createHttpHandler = (source, path = "/") => {
    const health = HttpRouter.add("GET", "/health", () => HttpServerResponse.json({
        corpusChecksum: source.corpus.checksum,
        releaseId: source.manifest.generatedAt
    }, { headers: { "cache-control": "no-store" }, status: 200 }));
    const routes = Layer.mergeAll(makeMcpLayer(source, "http", path), health);
    return HttpRouter.toWebHandler(routes.pipe(Layer.provide(HttpServer.layerServices)));
};
export /** @internal */ const runStdio = (source) => Layer.launch(makeMcpLayer(source, "stdio"));
export /** @internal */ const decodeMcpSource = (value) => ({
    corpus: Schema.decodeUnknownSync(AgentCorpusSchema)(value.corpus),
    index: Schema.decodeUnknownSync(AgentSearchIndexSchema)(value.index),
    manifest: Schema.decodeUnknownSync(AgentManifestSchema)(value.manifest)
});
//# sourceMappingURL=Server.js.map