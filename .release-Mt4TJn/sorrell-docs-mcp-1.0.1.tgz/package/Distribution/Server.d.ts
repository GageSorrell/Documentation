/**
 * MCP transport and tool definitions for documentation corpora.
 *
 * @module @sorrell/docs-mcp/Server
 *
 * @file      Server.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { type AgentCorpus, type AgentDocument, type AgentManifest, type AgentSearchIndex } from "@sorrell/docs-core";
import { Context, Effect, Layer, Schema } from "effect";
import { Tool, Toolkit } from "effect/unstable/ai";
declare const McpCorpus_base: Context.ServiceClass<McpCorpus, "sorrell/docs-mcp/McpCorpus", {
    readonly corpus: AgentCorpus;
    readonly manifest: AgentManifest;
    readonly index: AgentSearchIndex;
}>;
/** @internal */
export declare class McpCorpus extends McpCorpus_base {
}
/** @internal */
export interface McpSource {
    readonly corpus: AgentCorpus;
    readonly manifest: AgentManifest;
    readonly index: AgentSearchIndex;
}
export declare const buildSearchIndex: (corpus: AgentCorpus, checksum: string) => AgentSearchIndex;
export declare const searchDocuments: (corpus: AgentCorpus, query: string, version?: string, limit?: number) => ReadonlyArray<AgentDocument>;
export declare const DocumentationToolkit: Toolkit.Toolkit<{
    readonly search_docs: Tool.Tool<"search_docs", {
        readonly parameters: Schema.Struct<{
            readonly limit: Schema.optional<Schema.Number>;
            readonly query: Schema.String;
            readonly version: Schema.optional<Schema.String>;
        }>;
        readonly success: Schema.$Array<Schema.Struct<{
            readonly content: Schema.String;
            readonly context: Schema.optionalKey<Schema.String>;
            readonly description: Schema.optionalKey<Schema.String>;
            readonly id: Schema.String;
            readonly kind: Schema.Literals<readonly ["article", "api-module", "component"]>;
            readonly metadata: Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>;
            readonly source: Schema.optionalKey<Schema.Struct<{
                readonly endLine: Schema.optionalKey<Schema.Number>;
                readonly file: Schema.String;
                readonly line: Schema.optionalKey<Schema.Number>;
                readonly repositoryUrl: Schema.String;
                readonly revision: Schema.String;
            }>>;
            readonly title: Schema.String;
            readonly url: Schema.String;
            readonly version: Schema.optionalKey<Schema.String>;
        }>>;
        readonly failure: Schema.Never;
        readonly failureMode: "error";
    }, never>;
    readonly get_document: Tool.Tool<"get_document", {
        readonly parameters: Schema.Struct<{
            readonly id: Schema.String;
            readonly version: Schema.optional<Schema.String>;
        }>;
        readonly success: Schema.Struct<{
            readonly content: Schema.String;
            readonly context: Schema.optionalKey<Schema.String>;
            readonly description: Schema.optionalKey<Schema.String>;
            readonly id: Schema.String;
            readonly kind: Schema.Literals<readonly ["article", "api-module", "component"]>;
            readonly metadata: Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>;
            readonly source: Schema.optionalKey<Schema.Struct<{
                readonly endLine: Schema.optionalKey<Schema.Number>;
                readonly file: Schema.String;
                readonly line: Schema.optionalKey<Schema.Number>;
                readonly repositoryUrl: Schema.String;
                readonly revision: Schema.String;
            }>>;
            readonly title: Schema.String;
            readonly url: Schema.String;
            readonly version: Schema.optionalKey<Schema.String>;
        }>;
        readonly failure: Schema.Never;
        readonly failureMode: "error";
    }, never>;
    readonly get_api: Tool.Tool<"get_api", {
        readonly parameters: Schema.Struct<{
            readonly id: Schema.String;
            readonly version: Schema.optional<Schema.String>;
        }>;
        readonly success: Schema.Struct<{
            readonly content: Schema.String;
            readonly context: Schema.optionalKey<Schema.String>;
            readonly description: Schema.optionalKey<Schema.String>;
            readonly id: Schema.String;
            readonly kind: Schema.Literals<readonly ["article", "api-module", "component"]>;
            readonly metadata: Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>;
            readonly source: Schema.optionalKey<Schema.Struct<{
                readonly endLine: Schema.optionalKey<Schema.Number>;
                readonly file: Schema.String;
                readonly line: Schema.optionalKey<Schema.Number>;
                readonly repositoryUrl: Schema.String;
                readonly revision: Schema.String;
            }>>;
            readonly title: Schema.String;
            readonly url: Schema.String;
            readonly version: Schema.optionalKey<Schema.String>;
        }>;
        readonly failure: Schema.Never;
        readonly failureMode: "error";
    }, never>;
    readonly list_versions: Tool.Tool<"list_versions", {
        readonly parameters: Tool.EmptyParams;
        readonly success: Schema.$Array<Schema.String>;
        readonly failure: Schema.Never;
        readonly failureMode: "error";
    }, never>;
    readonly list_packages: Tool.Tool<"list_packages", {
        readonly parameters: Tool.EmptyParams;
        readonly success: Schema.$Array<Schema.String>;
        readonly failure: Schema.Never;
        readonly failureMode: "error";
    }, never>;
    readonly list_components: Tool.Tool<"list_components", {
        readonly parameters: Tool.EmptyParams;
        readonly success: Schema.$Array<Schema.Struct<{
            readonly content: Schema.String;
            readonly context: Schema.optionalKey<Schema.String>;
            readonly description: Schema.optionalKey<Schema.String>;
            readonly id: Schema.String;
            readonly kind: Schema.Literals<readonly ["article", "api-module", "component"]>;
            readonly metadata: Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>;
            readonly source: Schema.optionalKey<Schema.Struct<{
                readonly endLine: Schema.optionalKey<Schema.Number>;
                readonly file: Schema.String;
                readonly line: Schema.optionalKey<Schema.Number>;
                readonly repositoryUrl: Schema.String;
                readonly revision: Schema.String;
            }>>;
            readonly title: Schema.String;
            readonly url: Schema.String;
            readonly version: Schema.optionalKey<Schema.String>;
        }>>;
        readonly failure: Schema.Never;
        readonly failureMode: "error";
    }, never>;
}>;
export declare const makeMcpLayer: (source: McpSource, transport: "http" | "stdio", path?: string) => Layer.Layer<any, unknown, any>;
export declare const createHttpHandler: (source: McpSource, path?: string) => {
    readonly handler: (request: globalThis.Request, context?: Context.Context<never> | undefined) => Promise<Response>;
    readonly dispose: () => Promise<void>;
};
export declare const runStdio: (source: McpSource) => Effect.Effect<void, unknown, never>;
export declare const decodeMcpSource: (value: unknown) => McpSource;
export {};
//# sourceMappingURL=Server.d.ts.map