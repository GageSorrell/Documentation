/**
 * MCP server for Sorrell documentation agent corpora.
 *
 * @module @sorrell/docs-mcp
 *
 * @file      index.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
export * from "./Server.js";
//# sourceMappingURL=index.js.map