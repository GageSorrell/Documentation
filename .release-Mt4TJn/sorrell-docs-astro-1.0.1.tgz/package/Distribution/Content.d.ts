/**
 * Content models and deterministic ordering for Astro documentation pages.
 *
 * @module @sorrell/docs-astro/Content
 *
 * @file      Content.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
/** @internal */
export interface DocumentationFrontmatter {
    readonly title: string;
    readonly description: string;
    readonly group: string;
    readonly order: number;
    readonly draft: boolean;
}
/** @internal */
export interface DocumentationPageSummary extends DocumentationFrontmatter {
    readonly id: string;
    readonly slug: string;
}
export declare const documentationSlug: (id: string) => string;
export declare const sortDocumentationPages: <Page extends DocumentationPageSummary>(pages: ReadonlyArray<Page>) => ReadonlyArray<Page>;
export declare const visibleDocumentationPages: <Page extends DocumentationPageSummary>(pages: ReadonlyArray<Page>) => ReadonlyArray<Page>;
//# sourceMappingURL=Content.d.ts.map