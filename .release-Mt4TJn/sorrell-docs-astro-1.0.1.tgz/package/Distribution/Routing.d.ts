/**
 * Route and canonical URL helpers for Astro documentation applications.
 *
 * @module @sorrell/docs-astro/Routing
 *
 * @file      Routing.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { SiteRouting } from "@sorrell/docs-core";
export declare const normalizeDocsPrefix: (prefix?: string) => string;
export declare const docsPath: (prefix: string, path?: string) => string;
export declare const docsVersionPath: (prefix: string, version: string, path?: string) => string;
export declare const canonicalUrl: (siteUrl: string, path: string) => string;
export declare const documentationRouting: (routing?: Partial<SiteRouting>) => SiteRouting;
//# sourceMappingURL=Routing.d.ts.map