/**
 * Content models and deterministic ordering for Astro documentation pages.
 *
 * @module @sorrell/docs-astro/Content
 *
 * @file      Content.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
export /** @internal */ const documentationSlug = (id) => id.replace(/(?:^|\/)index$/, "");
export /** @internal */ const sortDocumentationPages = (pages) => [...pages].sort((left, right) => {
    return (left.order - right.order ||
        left.title.localeCompare(right.title) ||
        left.id.localeCompare(right.id));
});
export /** @internal */ const visibleDocumentationPages = (pages) => sortDocumentationPages(pages.filter((page) => !page.draft));
//# sourceMappingURL=Content.js.map