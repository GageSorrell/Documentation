/**
 * Route and canonical URL helpers for Astro documentation applications.
 *
 * @module @sorrell/docs-astro/Routing
 *
 * @file      Routing.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
export /** @internal */ const normalizeDocsPrefix = (prefix = "/docs") => {
    if (prefix === "/") {
        return "/";
    }
    return `/${prefix.replace(/^\/+/, "").replace(/\/+$/, "")}`;
};
export /** @internal */ const docsPath = (prefix, path = "") => {
    const normalizedPrefix = normalizeDocsPrefix(prefix);
    const normalizedPath = path.replace(/^\/+/, "");
    return normalizedPath === ""
        ? `${normalizedPrefix}/`
        : `${normalizedPrefix}/${normalizedPath}`;
};
export /** @internal */ const docsVersionPath = (prefix, version, path = "") => docsPath(prefix, `${version.replace(/^\/+|\/+$/g, "")}/${path.replace(/^\/+/, "")}`);
export /** @internal */ const canonicalUrl = (siteUrl, path) => {
    const normalizedSite = siteUrl.replace(/\/+$/, "");
    const normalizedPath = path.startsWith("/") ? path : `/${path}`;
    return `${normalizedSite}${normalizedPath}`;
};
export /** @internal */ const documentationRouting = (routing) => ({
    documentationPrefix: normalizeDocsPrefix(routing?.documentationPrefix),
    storybookPrefix: normalizeDocsPrefix(routing?.storybookPrefix ?? "/storybook")
});
//# sourceMappingURL=Routing.js.map