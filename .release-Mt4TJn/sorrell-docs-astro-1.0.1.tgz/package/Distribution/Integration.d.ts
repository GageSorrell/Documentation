/**
 * Astro integration for the normalized Sorrell documentation route.
 *
 * @module @sorrell/docs-astro/Integration
 *
 * @file      Integration.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { AstroIntegration } from "astro";
/** @internal */
export interface DocsAstroIntegrationOptions {
    readonly prefix?: string;
    readonly site?: string;
}
export declare const docsAstroIntegration: (options?: DocsAstroIntegrationOptions) => AstroIntegration;
//# sourceMappingURL=Integration.d.ts.map