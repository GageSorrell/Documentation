/**
 * Three-package website workspace generation.
 *
 * @module @sorrell/docs-create-website/Generator
 *
 * @file      Generator.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { type DocsConfig } from "@sorrell/docs-core";
import { Effect } from "effect";
import type { GeneratedWebsite, WebsiteGenerationOptions } from "./Types.js";
export declare const createGeneratedWebsite: (options: WebsiteGenerationOptions) => GeneratedWebsite;
export declare const createGeneratedWebsiteFromConfig: (target: string, config: DocsConfig, options?: Omit<WebsiteGenerationOptions, "config" | "target">) => GeneratedWebsite;
export declare const writeGeneratedWebsite: (website: GeneratedWebsite) => Effect.Effect<void, unknown>;
//# sourceMappingURL=Generator.d.ts.map