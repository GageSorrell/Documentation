/**
 * Public route and Vercel rewrite generation.
 *
 * @module @sorrell/docs-create-website/Routing
 *
 * @file      Routing.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { WebsiteDeployments } from "./Types.js";
import type { DocsConfig, Redirect, SiteRouting, VercelProjects } from "@sorrell/docs-core";
/** @internal */
export interface VercelRewrite {
    readonly source: string;
    readonly destination: string;
}
/** @internal */
export interface VercelRedirect {
    readonly source: string;
    readonly destination: string;
    readonly statusCode: 301 | 302;
}
/** @internal */
export interface VercelHeader {
    readonly source: string;
    readonly headers: ReadonlyArray<{
        readonly key: string;
        readonly value: string;
    }>;
}
/** @internal */
export interface LandingVercelConfig {
    readonly buildCommand?: "npm run build";
    readonly installCommand?: "npm install";
    readonly outputDirectory?: "Distribution";
    readonly version: 2;
    readonly rewrites: ReadonlyArray<VercelRewrite>;
    readonly redirects: ReadonlyArray<VercelRedirect>;
    readonly headers: ReadonlyArray<VercelHeader>;
}
export declare const createLandingRewrites: (routing: SiteRouting, deployments: WebsiteDeployments, redirects?: ReadonlyArray<Redirect>) => LandingVercelConfig;
export declare const createPlaceholderDeployments: (config: DocsConfig, snapshot?: boolean) => WebsiteDeployments;
export declare const createSnapshotProjects: (config: DocsConfig) => VercelProjects;
export declare const publicUrl: (siteUrl: string, prefix: string, path?: string) => string;
//# sourceMappingURL=Routing.d.ts.map