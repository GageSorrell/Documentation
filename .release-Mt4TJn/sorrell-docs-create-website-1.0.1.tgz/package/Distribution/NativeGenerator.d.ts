/**
 * Expo and React Native Storybook project templates.
 *
 * @module @sorrell/docs-create-website/NativeGenerator
 *
 * @file      NativeGenerator.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Effect } from "effect";
import type { NativeAppGenerationOptions, NativeAuthoringOptions, NativeGeneratedApp, NativeGeneratedFile } from "./NativeTypes.js";
export declare const createNativeStorybookApp: (options: NativeAppGenerationOptions) => NativeGeneratedApp;
export declare const createNativeAuthoringFile: ({ kind, name }: NativeAuthoringOptions) => NativeGeneratedFile;
export declare const writeNativeStorybookApp: (app: NativeGeneratedApp) => Effect.Effect<void, unknown>;
export declare const writeNativeAuthoringFile: (options: NativeAuthoringOptions) => Effect.Effect<void, unknown>;
//# sourceMappingURL=NativeGenerator.d.ts.map