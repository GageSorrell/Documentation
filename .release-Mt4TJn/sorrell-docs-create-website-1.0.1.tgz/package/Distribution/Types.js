/**
 * Models for generated website workspaces and deployment manifests.
 *
 * @module @sorrell/docs-create-website/Types
 *
 * @file      Types.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
export {};
//# sourceMappingURL=Types.js.map