/**
 * Build and verify the generated application graph.
 *
 * @module @sorrell/docs-create-website/Build
 *
 * @file      Build.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Effect } from "effect";
import type { GeneratedWebsite } from "./Types.js";
export declare const readGeneratedWebsite: (target: string) => Effect.Effect<GeneratedWebsite, unknown>;
export declare const buildWebsite: (target: string) => Effect.Effect<void, unknown>;
export declare const verifyWebsite: (target: string) => Effect.Effect<void, unknown>;
export declare const devWebsite: (target: string) => Effect.Effect<never, unknown>;
//# sourceMappingURL=Build.d.ts.map