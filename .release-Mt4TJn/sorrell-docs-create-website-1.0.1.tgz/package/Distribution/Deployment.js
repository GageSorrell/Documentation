/**
 * Child-first deployment and release-manifest orchestration.
 *
 * @module @sorrell/docs-create-website/Deployment
 *
 * @file      Deployment.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { AtomicWriter, DocsFileSystem, DocsPath, NetworkRetry, VercelService } from "@sorrell/docs-cli";
import { Data, Effect, Layer, Result } from "effect";
import { createLandingRewrites } from "./Routing.js";
/** @internal */
export class DeploymentVerificationError extends Data.TaggedError("DeploymentVerificationError") {
}
/** @internal */
export class ReleaseManifestError extends Data.TaggedError("ReleaseManifestError") {
}
const targetFrom = (project, output, revision) => ({
    deploymentId: output.deploymentId,
    url: output.url,
    ...(revision === undefined ? {} : { revision }),
    project
});
const projectOptions = (project, production) => ({
    production,
    ...(project.project === undefined ? {} : { name: project.project })
    // VercelService authenticates with VERCEL_ORG_ID via --scope. Keeping the
    // project map's team field for metadata avoids emitting duplicate flags.
});
const localPackageDirectories = {
    "@sorrell/docs-api-reference": "ApiReference",
    "@sorrell/docs-astro": "Astro",
    "@sorrell/docs-cli": "Cli",
    "@sorrell/docs-core": "Core",
    "@sorrell/docs-create-website": "CreateWebsite",
    "@sorrell/docs-mcp": "Mcp",
    "@sorrell/docs-skills": "Skills",
    "@sorrell/docs-ui": "Ui"
};
const dependencySections = [
    "dependencies",
    "devDependencies",
    "optionalDependencies",
    "peerDependencies"
];
const localDependency = (name, value, prefix) => typeof value === "string" && localPackageDirectories[name] !== undefined
    ? `file:${prefix}${localPackageDirectories[name]}`
    : value;
const rewritePackageManifest = (text, prefix) => {
    const manifest = JSON.parse(text);
    for (const section of dependencySections) {
        const dependencies = manifest[section];
        if (typeof dependencies !== "object" || dependencies === null) {
            continue;
        }
        const rewritten = Object.fromEntries(Object.entries(dependencies).map(([name, value]) => [
            name,
            localDependency(name, value, prefix)
        ]));
        manifest[section] = rewritten;
    }
    return `${JSON.stringify(manifest, null, 2)}\n`;
};
const rewriteStagedTsconfig = (text) => text
    .replaceAll("../../Configuration/", "./Configuration/")
    .replaceAll("../../Package/", "./Package/");
const prepareVercelDirectory = (website, directory, fileSystem, path, staticContent) => Effect.gen(function* () {
    const source = path.resolve(directory);
    const repositoryRoot = path.resolve(website.target, "..");
    const packageSource = path.join(repositoryRoot, "Package");
    const configurationSource = path.join(repositoryRoot, "Configuration");
    if (!(yield* fileSystem.exists(source)) ||
        !(yield* fileSystem.exists(path.join(packageSource, "Core", "package.json")))) {
        return source;
    }
    const staging = yield* fileSystem.makeTempDirectoryScoped({
        prefix: "sorrell-vercel-"
    });
    yield* fileSystem.copy(source, staging, { overwrite: true });
    if (staticContent !== undefined) {
        const destination = path.join(staging, staticContent.destination);
        yield* fileSystem.makeDirectory(destination);
        yield* fileSystem.copy(staticContent.source, destination, { overwrite: true });
    }
    const stagedPackages = path.join(staging, "Package");
    yield* fileSystem.copy(packageSource, stagedPackages, {
        overwrite: true
    });
    if (yield* fileSystem.exists(configurationSource)) {
        yield* fileSystem.copy(configurationSource, path.join(staging, "Configuration"), { overwrite: true });
    }
    const siteManifest = path.join(staging, "package.json");
    if (yield* fileSystem.exists(siteManifest)) {
        yield* fileSystem.writeText(siteManifest, rewritePackageManifest(yield* fileSystem.readText(siteManifest), "./Package/"));
    }
    const siteTsconfig = path.join(staging, "tsconfig.json");
    if (yield* fileSystem.exists(siteTsconfig)) {
        yield* fileSystem.writeText(siteTsconfig, rewriteStagedTsconfig(yield* fileSystem.readText(siteTsconfig)));
    }
    for (const packageDirectory of Object.values(localPackageDirectories)) {
        const packageManifest = path.join(stagedPackages, packageDirectory, "package.json");
        if (yield* fileSystem.exists(packageManifest)) {
            yield* fileSystem.writeText(packageManifest, rewritePackageManifest(yield* fileSystem.readText(packageManifest), "../"));
        }
    }
    return staging;
});
export /** @internal */ const deployWebsite = (website, options = {}) => Effect.scoped(Effect.gen(function* () {
    const vercel = yield* VercelService;
    const writer = yield* AtomicWriter;
    const fileSystem = yield* DocsFileSystem;
    const path = yield* DocsPath;
    // Publish every package as a preview artifact first. Production promotion
    // happens only after the Landing routes have been verified.
    const deployOptions = { production: false };
    const documentationProject = website.config.vercel.projects.documentation;
    const documentationDirectory = yield* prepareVercelDirectory(website, path.join(website.target, documentationProject.directory), fileSystem, path);
    const documentationOutput = yield* vercel.deploy(documentationDirectory, projectOptions({
        project: documentationProject.project,
        team: documentationProject.team
    }, deployOptions.production));
    const documentation = targetFrom(documentationProject.project ?? "documentation", documentationOutput, options.revision);
    const storybookDirectory = website.config.storybook.enabled
        ? yield* prepareVercelDirectory(website, path.join(website.target, website.config.vercel.projects.storybook?.directory ??
            "Storybook"), fileSystem, path)
        : undefined;
    const storybookOutput = storybookDirectory !== undefined
        ? yield* vercel
            .deploy(storybookDirectory, projectOptions({
            project: website.config.vercel.projects.storybook
                ?.project,
            team: website.config.vercel.projects.storybook
                ?.team
        }, deployOptions.production))
            .pipe(Effect.result)
        : Result.succeed(undefined);
    if (Result.isFailure(storybookOutput)) {
        yield* vercel
            .remove(documentationOutput.deploymentId)
            .pipe(Effect.ignore);
        return yield* Effect.fail(storybookOutput.failure);
    }
    const storybook = storybookOutput.success === undefined
        ? undefined
        : targetFrom(website.config.vercel.projects.storybook?.project ??
            "storybook", storybookOutput.success, options.revision);
    const mcpDirectory = website.config.agent.mcp.enabled
        ? yield* prepareVercelDirectory(website, path.join(website.target, website.config.vercel.projects.mcp?.directory ?? "Mcp"), fileSystem, path)
        : undefined;
    const mcpOutput = mcpDirectory !== undefined
        ? yield* vercel
            .deploy(mcpDirectory, projectOptions({
            project: website.config.vercel.projects.mcp?.project,
            team: website.config.vercel.projects.mcp?.team
        }, deployOptions.production))
            .pipe(Effect.result)
        : Result.succeed(undefined);
    if (Result.isFailure(mcpOutput)) {
        yield* vercel
            .remove(documentationOutput.deploymentId)
            .pipe(Effect.ignore);
        if (storybookOutput.success !== undefined) {
            yield* vercel
                .remove(storybookOutput.success.deploymentId)
                .pipe(Effect.ignore);
        }
        return yield* Effect.fail(mcpOutput.failure);
    }
    const mcp = mcpOutput.success === undefined
        ? undefined
        : targetFrom(website.config.vercel.projects.mcp?.project ?? "mcp", mcpOutput.success, options.revision);
    const childDeployments = {
        documentation,
        landing: {
            deploymentId: "pending",
            url: "https://landing.pending"
        },
        ...(storybook === undefined ? {} : { storybook }),
        ...(mcp === undefined ? {} : { mcp })
    };
    const landingConfig = createLandingRewrites(website.config.routing, childDeployments, website.config.redirects);
    yield* writer.writeText(path.join(website.target, "Landing", "vercel.json"), `${JSON.stringify(landingConfig, null, 2)}\n`);
    const landingProject = website.config.vercel.projects.landing;
    const documentationDistribution = path.join(website.target, website.config.vercel.projects.documentation.directory, "dist");
    const landingDirectory = yield* prepareVercelDirectory(website, path.join(website.target, landingProject.directory), fileSystem, path, {
        destination: path.join("public", website.config.routing.documentationPrefix.replace(/^\/+/, "")),
        source: documentationDistribution
    });
    const landingResult = yield* vercel
        .deploy(landingDirectory, projectOptions({
        project: landingProject.project,
        team: landingProject.team
    }, deployOptions.production))
        .pipe(Effect.result);
    if (Result.isFailure(landingResult)) {
        yield* vercel
            .remove(documentationOutput.deploymentId)
            .pipe(Effect.ignore);
        if (storybookOutput.success !== undefined) {
            yield* vercel
                .remove(storybookOutput.success.deploymentId)
                .pipe(Effect.ignore);
        }
        if (mcpOutput.success !== undefined) {
            yield* vercel
                .remove(mcpOutput.success.deploymentId)
                .pipe(Effect.ignore);
        }
        return yield* Effect.fail(landingResult.failure);
    }
    const landingOutput = landingResult.success;
    const landing = targetFrom(landingProject.project ?? "landing", landingOutput, options.revision);
    const revision = (options.revision ?? website.revision).replace(/[^A-Za-z0-9_.-]/g, "-");
    const generatedAt = (options.generatedAt ?? website.generatedAt).replace(/[^A-Za-z0-9_.-]/g, "-");
    const releaseId = options.releaseId ?? `${revision}-${generatedAt}`;
    return {
        generatedAt: options.generatedAt ?? website.generatedAt,
        mode: options.production === true
            ? "production"
            : "preview",
        publicUrl: website.config.metadata.url || landing.url,
        releaseId,
        revision: options.revision ?? website.revision,
        routes: website.config.routing,
        version: 2,
        ...(mcp === undefined
            ? {}
            : { mcpEndpoint: website.config.mcpEndpoint }),
        deployments: {
            ...childDeployments,
            landing,
            ...(storybook === undefined ? {} : { storybook }),
            ...(mcp === undefined ? {} : { mcp })
        },
        landingConfig,
        ...(options.apiSnapshot === undefined
            ? {}
            : { apiSnapshot: options.apiSnapshot })
    };
}).pipe(Effect.provide(Layer.mergeAll(AtomicWriter.layer, DocsFileSystem.layer, DocsPath.layer))));
export /** @internal */ const cleanupWebsiteDeployments = (manifest) => Effect.gen(function* () {
    const vercel = yield* VercelService;
    const deployments = [
        manifest.deployments.documentation,
        manifest.deployments.storybook,
        manifest.deployments.mcp,
        manifest.deployments.landing
    ].filter((value) => value !== undefined);
    yield* Effect.forEach(deployments, (deployment) => vercel.remove(deployment.deploymentId).pipe(Effect.ignore), { concurrency: 1 });
});
export /** @internal */ const promoteWebsite = (manifest) => Effect.gen(function* () {
    const vercel = yield* VercelService;
    yield* vercel.promote(manifest.deployments.documentation.deploymentId);
    if (manifest.deployments.storybook !== undefined) {
        yield* vercel.promote(manifest.deployments.storybook.deploymentId);
    }
    if (manifest.deployments.mcp !== undefined) {
        if (manifest.mcpEndpoint !== undefined) {
            yield* vercel.alias(manifest.deployments.mcp.deploymentId, new URL(manifest.mcpEndpoint).host);
        }
        yield* vercel.promote(manifest.deployments.mcp.deploymentId);
    }
    yield* vercel.promote(manifest.deployments.landing.deploymentId);
});
const readManifest = (fileSystem, path) => fileSystem.readText(path).pipe(Effect.mapError((cause) => new ReleaseManifestError({ cause, path })), Effect.flatMap((text) => Effect.try({
    catch: (cause) => new ReleaseManifestError({ cause, path }),
    try: () => JSON.parse(text)
})));
export /** @internal */ const writeReleaseManifest = (target, manifest) => Effect.gen(function* () {
    const writer = yield* AtomicWriter;
    const path = yield* DocsPath;
    const fileSystem = yield* DocsFileSystem;
    const activePath = path.join(target, "ReleaseManifest.json");
    const previous = yield* fileSystem
        .exists(activePath)
        .pipe(Effect.flatMap((exists) => exists
        ? readManifest(fileSystem, activePath).pipe(Effect.catch(() => Effect.succeed(undefined)))
        : Effect.succeed(undefined)));
    const persisted = previous === undefined
        ? manifest
        : { ...manifest, previousReleaseId: previous.releaseId };
    const archiveDirectory = path.join(target, "Releases");
    yield* fileSystem.makeDirectory(archiveDirectory);
    yield* writer.writeText(activePath, `${JSON.stringify(persisted, null, 2)}\n`);
    yield* writer.writeText(path.join(archiveDirectory, `${persisted.releaseId}.json`), `${JSON.stringify(persisted, null, 2)}\n`);
}).pipe(Effect.provide(Layer.mergeAll(AtomicWriter.layer, DocsFileSystem.layer, DocsPath.layer)));
export /** @internal */ const rollbackWebsite = (target, releaseId) => Effect.gen(function* () {
    const writer = yield* AtomicWriter;
    const fileSystem = yield* DocsFileSystem;
    const path = yield* DocsPath;
    const activePath = path.join(target, "ReleaseManifest.json");
    const active = yield* readManifest(fileSystem, activePath);
    const selectedId = releaseId ?? active.previousReleaseId;
    if (selectedId === undefined) {
        return yield* Effect.fail(new ReleaseManifestError({
            cause: new Error("no previous release is recorded"),
            path: activePath
        }));
    }
    const selectedPath = path.join(target, "Releases", `${selectedId}.json`);
    const selected = yield* readManifest(fileSystem, selectedPath);
    yield* promoteWebsite(selected);
    yield* writer.writeText(activePath, `${JSON.stringify(selected, null, 2)}\n`);
    return selected;
});
export /** @internal */ const verifyWebsiteDeployment = (manifest, options = {}) => Effect.gen(function* () {
    const retry = yield* NetworkRetry;
    const verifyUrl = (url) => {
        const request = Effect.tryPromise({
            catch: (cause) => new DeploymentVerificationError({ cause, url }),
            try: () => fetch(url)
        }).pipe(Effect.flatMap((response) => response.ok
            ? Effect.void
            : Effect.fail(new DeploymentVerificationError({
                cause: new Error(`unexpected HTTP status ${response.status}`),
                status: response.status,
                url
            }))));
        return retry.run(request, (cause) => cause.status === undefined || cause.status >= 500, { delay: "100 millis", maxRetries: 3 });
    };
    const paths = options.paths ?? [
        "/",
        manifest.routes.documentationPrefix,
        `${manifest.routes.documentationPrefix}/`,
        ...(manifest.deployments.storybook === undefined
            ? []
            : [
                manifest.routes.storybookPrefix,
                `${manifest.routes.storybookPrefix}/`
            ])
    ];
    for (const route of paths) {
        const url = new URL(route, `${manifest.deployments.landing.url.replace(/\/+$/, "")}/`).toString();
        yield* verifyUrl(url);
    }
    const documentationUrl = `${manifest.deployments.documentation.url.replace(/\/+$/u, "")}` +
        `${manifest.routes.documentationPrefix}/`;
    yield* verifyUrl(documentationUrl);
    if (manifest.deployments.storybook !== undefined) {
        const storybookUrl = `${manifest.deployments.storybook.url.replace(/\/+$/u, "")}` +
            `${manifest.routes.storybookPrefix}/`;
        yield* verifyUrl(storybookUrl);
    }
    if (manifest.deployments.mcp !== undefined) {
        const url = `${manifest.deployments.mcp.url.replace(/\/+$/u, "")}/health`;
        const response = yield* Effect.tryPromise({
            catch: (cause) => new DeploymentVerificationError({ cause, url }),
            try: () => fetch(url)
        });
        if (!response.ok) {
            return yield* Effect.fail(new DeploymentVerificationError({
                status: response.status,
                url
            }));
        }
        if (response.headers.get("cache-control") !== "no-store") {
            return yield* Effect.fail(new DeploymentVerificationError({
                cause: new Error("MCP health response must be no-store"),
                url
            }));
        }
    }
});
//# sourceMappingURL=Deployment.js.map