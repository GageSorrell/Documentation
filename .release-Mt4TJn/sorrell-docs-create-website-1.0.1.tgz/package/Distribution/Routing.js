/**
 * Public route and Vercel rewrite generation.
 *
 * @module @sorrell/docs-create-website/Routing
 *
 * @file      Routing.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
const normalizedUrl = (url) => url.replace(/\/+$/, "");
const rewriteFor = (prefix, deployment) => {
    const destination = `${normalizedUrl(deployment.url)}${prefix}`;
    return [
        { destination, source: prefix },
        { destination: `${destination}/:path*`, source: `${prefix}/:path*` }
    ];
};
export /** @internal */ const createLandingRewrites = (routing, deployments, redirects = []) => ({
    buildCommand: "npm run build",
    headers: [
        {
            headers: [{ key: "X-Robots-Tag", value: "noindex" }],
            source: "/llms.txt"
        },
        {
            headers: [{ key: "X-Robots-Tag", value: "noindex" }],
            source: `${routing.documentationPrefix}/agent/:path*`
        },
        {
            headers: [{ key: "X-Robots-Tag", value: "noindex" }],
            source: `${routing.documentationPrefix}/:path*.md`
        },
        ...(deployments.storybook === undefined
            ? []
            : [
                {
                    headers: [{ key: "X-Robots-Tag", value: "noindex" }],
                    source: `${routing.storybookPrefix}/agent/:path*`
                }
            ])
    ],
    installCommand: "npm install",
    outputDirectory: "Distribution",
    redirects: redirects.map((redirect) => ({
        destination: redirect.to,
        source: redirect.from,
        statusCode: redirect.status
    })),
    rewrites: [
        ...(deployments.storybook === undefined
            ? []
            : rewriteFor(routing.storybookPrefix, deployments.storybook))
    ],
    version: 2
});
export /** @internal */ const createPlaceholderDeployments = (config, snapshot = false) => ({
    documentation: {
        deploymentId: snapshot
            ? "snapshot-documentation"
            : "pending-documentation",
        url: snapshot
            ? "https://documentation-snapshot.invalid"
            : "https://documentation.invalid"
    },
    landing: {
        deploymentId: "pending-landing",
        url: config.metadata.url || "https://landing.invalid"
    },
    ...(config.storybook.enabled
        ? {
            storybook: {
                deploymentId: snapshot
                    ? "snapshot-storybook"
                    : "pending-storybook",
                url: snapshot
                    ? "https://storybook-snapshot.invalid"
                    : "https://storybook.invalid"
            }
        }
        : {}),
    ...(config.agent.mcp.enabled
        ? {
            mcp: {
                deploymentId: snapshot ? "snapshot-mcp" : "pending-mcp",
                url: snapshot
                    ? "https://mcp-snapshot.invalid"
                    : "https://mcp.invalid"
            }
        }
        : {})
});
export /** @internal */ const createSnapshotProjects = (config) => {
    const suffix = (project, fallback) => `${project ?? fallback}-snapshot`;
    return {
        documentation: {
            ...config.vercel.projects.documentation,
            project: suffix(config.vercel.projects.documentation.project, "documentation")
        },
        landing: {
            ...config.vercel.projects.landing,
            project: suffix(config.vercel.projects.landing.project, "landing")
        },
        ...(config.vercel.projects.storybook === undefined
            ? {}
            : {
                storybook: {
                    ...config.vercel.projects.storybook,
                    project: suffix(config.vercel.projects.storybook.project, "storybook")
                }
            }),
        ...(config.vercel.projects.mcp === undefined
            ? {}
            : {
                mcp: {
                    ...config.vercel.projects.mcp,
                    project: suffix(config.vercel.projects.mcp.project, "mcp")
                }
            })
    };
};
export /** @internal */ const publicUrl = (siteUrl, prefix, path = "") => {
    const normalizedSite = normalizedUrl(siteUrl);
    const normalizedPath = path.replace(/^\/+/, "");
    return `${normalizedSite}${prefix}${normalizedPath === "" ? "" : `/${normalizedPath}`}`;
};
//# sourceMappingURL=Routing.js.map