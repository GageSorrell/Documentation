/**
 * Executable entrypoint for `sorrell-docs`.
 *
 * @module @sorrell/docs-create-website/bin
 *
 * @file      bin.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
export {};
//# sourceMappingURL=bin.d.ts.map