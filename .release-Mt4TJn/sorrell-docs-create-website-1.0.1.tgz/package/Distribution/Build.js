/**
 * Build and verify the generated application graph.
 *
 * @module @sorrell/docs-create-website/Build
 *
 * @file      Build.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { CommandRunner, DocsFileSystem, DocsPath, PackageManagerSelection } from "@sorrell/docs-cli";
import { decodeDocsConfigSync } from "@sorrell/docs-core";
import { Effect, Layer, Stream } from "effect";
import { buildAgentOutput, verifyAgentOutput } from "./AgentOutput.js";
import { createGeneratedWebsiteFromConfig } from "./Generator.js";
const readConfig = (target) => Effect.gen(function* () {
    const fileSystem = yield* DocsFileSystem;
    const path = yield* DocsPath;
    const text = yield* fileSystem.readText(path.join(target, "docs.config.json"));
    return yield* Effect.try({
        catch: (cause) => cause,
        try: () => decodeDocsConfigSync(JSON.parse(text))
    });
});
export /** @internal */ const readGeneratedWebsite = (target) => readConfig(target).pipe(Effect.map((config) => createGeneratedWebsiteFromConfig(target, config)), Effect.provide(Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer)));
const runPackageScript = (target, directory, script, manager) => Effect.gen(function* () {
    const runner = yield* CommandRunner;
    yield* runner.run(manager.executable, manager.runArguments(script), {
        cwd: `${target}/${directory}`
    });
});
const startPackageDev = (target, directory, manager) => Effect.gen(function* () {
    const runner = yield* CommandRunner;
    yield* runner
        .streamLines(manager.executable, manager.runArguments("dev"), {
        cwd: `${target}/${directory}`
    })
        .pipe(Stream.runDrain, Effect.forkScoped);
});
export /** @internal */ const buildWebsite = (target) => Effect.gen(function* () {
    const config = yield* readConfig(target);
    const manager = yield* PackageManagerSelection;
    const packageManager = yield* manager.select(target);
    yield* runPackageScript(target, "Documentation", "build", packageManager);
    if (config.storybook.enabled) {
        yield* runPackageScript(target, "Storybook", "build", packageManager);
    }
    if (config.agent.mcp.enabled) {
        yield* runPackageScript(target, "Mcp", "build", packageManager);
    }
    yield* runPackageScript(target, "Landing", "build", packageManager);
    yield* buildAgentOutput(target, { revision: "working-tree" });
}).pipe(Effect.provide(Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer, CommandRunner.layer, PackageManagerSelection.layer)));
export /** @internal */ const verifyWebsite = (target) => Effect.gen(function* () {
    const config = yield* readConfig(target);
    const manager = yield* PackageManagerSelection;
    const packageManager = yield* manager.select(target);
    yield* runPackageScript(target, "Documentation", "verify", packageManager);
    if (config.storybook.enabled) {
        yield* runPackageScript(target, "Storybook", "verify", packageManager);
    }
    if (config.agent.mcp.enabled) {
        yield* runPackageScript(target, "Mcp", "verify", packageManager);
    }
    yield* runPackageScript(target, "Landing", "verify", packageManager);
    // Child verification builds may recreate the Documentation dist
    // directory, so regenerate the agent corpus before validating it.
    yield* buildAgentOutput(target, { revision: "working-tree" });
    yield* verifyAgentOutput(target);
}).pipe(Effect.provide(Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer, CommandRunner.layer, PackageManagerSelection.layer)));
export /** @internal */ const devWebsite = (target) => Effect.scoped(Effect.gen(function* () {
    const config = yield* readConfig(target);
    const manager = yield* PackageManagerSelection;
    const packageManager = yield* manager.select(target);
    yield* startPackageDev(target, "Documentation", packageManager);
    if (config.storybook.enabled) {
        yield* startPackageDev(target, "Storybook", packageManager);
    }
    if (config.agent.mcp.enabled) {
        yield* startPackageDev(target, "Mcp", packageManager);
    }
    yield* startPackageDev(target, "Landing", packageManager);
    return yield* Effect.never;
})).pipe(Effect.provide(Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer, CommandRunner.layer, PackageManagerSelection.layer)));
//# sourceMappingURL=Build.js.map