/**
 *
 *
 * @module @sorrell/docs-create-website/NativeBuild
 *
 * @file      NativeBuild.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { CommandRunner, DocsFileSystem, DocsPath, PackageManagerSelection } from "@sorrell/docs-cli";
import { Effect, Layer, Stream } from "effect";
const runScript = (target, script, manager, args = []) => Effect.gen(function* () {
    const runner = yield* CommandRunner;
    yield* runner.run(manager.executable, manager.runArguments(script, args), { cwd: target });
});
export /** @internal */ const generateNativeApp = (target, platform = "all") => Effect.gen(function* () {
    const manager = yield* PackageManagerSelection;
    const packageManager = yield* manager.select(target);
    if (platform !== "web") {
        yield* runScript(target, "prebuild", packageManager, platform === "all" ? [] : ["--platform", platform]);
    }
    yield* runScript(target, "export", packageManager, [
        "--platform",
        platform
    ]);
}).pipe(Effect.provide(Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer, CommandRunner.layer, PackageManagerSelection.layer)));
export /** @internal */ const verifyNativeApp = (target) => Effect.gen(function* () {
    const manager = yield* PackageManagerSelection;
    const packageManager = yield* manager.select(target);
    yield* runScript(target, "typecheck", packageManager);
    yield* runScript(target, "export", packageManager);
}).pipe(Effect.provide(Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer, CommandRunner.layer, PackageManagerSelection.layer)));
export /** @internal */ const devNativeApp = (target) => Effect.scoped(Effect.gen(function* () {
    const manager = yield* PackageManagerSelection;
    const packageManager = yield* manager.select(target);
    const runner = yield* CommandRunner;
    yield* runner
        .streamLines(packageManager.executable, packageManager.runArguments("dev"), { cwd: target })
        .pipe(Stream.runDrain, Effect.forkScoped);
    return yield* Effect.never;
})).pipe(Effect.provide(Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer, CommandRunner.layer, PackageManagerSelection.layer)));
//# sourceMappingURL=NativeBuild.js.map