/**
 * The public `sorrell-docs` command tree for generated websites.
 *
 * @module @sorrell/docs-create-website/Cli
 *
 * @file      Cli.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Command } from "effect/unstable/cli";
import { Effect } from "effect";
import { SkillInstaller } from "@sorrell/docs-skills";
export declare const docsCommand: Command.Command<"sorrell-docs", {}, {}, unknown, SkillInstaller>;
export declare const runDocsCli: (args: ReadonlyArray<string>) => Effect.Effect<void, unknown, never>;
//# sourceMappingURL=Cli.d.ts.map