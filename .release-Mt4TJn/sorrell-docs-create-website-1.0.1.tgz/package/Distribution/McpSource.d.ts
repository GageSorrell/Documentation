/**
 *
 *
 * @module @sorrell/docs-create-website/McpSource
 *
 * @file      McpSource.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Effect } from "effect";
export declare const runMcpSource: (source: string) => Effect.Effect<void, unknown>;
//# sourceMappingURL=McpSource.d.ts.map