/**
 * Loads the checked-in Astro landing templates and applies site configuration.
 *
 * @module @sorrell/docs-create-website/LandingTemplate
 *
 * @file      LandingTemplate.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { DocsConfig } from "@sorrell/docs-core";
import type { GeneratedWebsiteFile } from "./Types.js";
export declare const landingTemplateFiles: (config: DocsConfig) => ReadonlyArray<GeneratedWebsiteFile>;
//# sourceMappingURL=LandingTemplate.d.ts.map