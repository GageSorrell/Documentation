/**
 * Generate installable product skills from the agent corpus.
 *
 * @module @sorrell/docs-create-website/ProductSkill
 *
 * @file      ProductSkill.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { type AgentCorpus, type AgentDocument, type AgentManifest, type AgentSkillArtifact, type DocsConfig } from "@sorrell/docs-core";
import { ArchiveService, AtomicWriter, DocsFileSystem, DocsPath } from "@sorrell/docs-cli";
import { Effect } from "effect";
/** @internal */
export declare class ProductSkillError extends Error {
    readonly path: string;
    readonly _tag: "ProductSkillError";
    constructor(path: string, message: string);
}
/** @internal */
export interface ProductSkillOptions {
    readonly config: DocsConfig;
    readonly corpus: AgentCorpus;
    readonly manifest: AgentManifest;
    readonly outputDirectory: string;
    readonly siteUrl?: string;
    readonly packageId?: string;
}
/** @internal */
export interface ProductSkillResult {
    readonly artifact: AgentSkillArtifact;
    readonly documents: ReadonlyArray<AgentDocument>;
}
export declare const buildProductSkill: (options: ProductSkillOptions) => Effect.Effect<ProductSkillResult, unknown, DocsFileSystem | DocsPath | AtomicWriter | ArchiveService>;
export declare const buildPackageProductSkill: (target: string, packageId: string, outputDirectory: string) => Effect.Effect<ProductSkillResult, unknown>;
//# sourceMappingURL=ProductSkill.d.ts.map