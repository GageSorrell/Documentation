/**
 * Child-first deployment and release-manifest orchestration.
 *
 * @module @sorrell/docs-create-website/Deployment
 *
 * @file      Deployment.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { AtomicWriter, DocsFileSystem, DocsPath, NetworkRetry, VercelService } from "@sorrell/docs-cli";
import { Effect } from "effect";
import type { GeneratedWebsite, WebsiteDeployments } from "./Types.js";
import { type LandingVercelConfig } from "./Routing.js";
/** @internal */
export interface WebsiteDeploymentOptions {
    readonly production?: boolean;
    readonly revision?: string;
    readonly generatedAt?: string;
    readonly releaseId?: string;
    readonly apiSnapshot?: string;
    readonly snapshot?: boolean;
}
/** @internal */
export interface WebsiteReleaseManifest {
    readonly version: 2;
    readonly releaseId: string;
    readonly generatedAt: string;
    readonly revision: string;
    readonly mode: "preview" | "production";
    readonly publicUrl: string;
    readonly routes: GeneratedWebsite["config"]["routing"];
    readonly mcpEndpoint?: string;
    readonly deployments: WebsiteDeployments;
    readonly landingConfig: LandingVercelConfig;
    readonly apiSnapshot?: string;
    readonly previousReleaseId?: string;
}
declare const DeploymentVerificationError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DeploymentVerificationError";
} & Readonly<A>;
/** @internal */
export declare class DeploymentVerificationError extends DeploymentVerificationError_base<{
    readonly url: string;
    readonly status?: number;
    readonly cause?: unknown;
}> {
}
declare const ReleaseManifestError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "ReleaseManifestError";
} & Readonly<A>;
/** @internal */
export declare class ReleaseManifestError extends ReleaseManifestError_base<{
    readonly path: string;
    readonly cause: unknown;
}> {
}
export declare const deployWebsite: (website: GeneratedWebsite, options?: WebsiteDeploymentOptions) => Effect.Effect<WebsiteReleaseManifest, unknown, VercelService | AtomicWriter | DocsFileSystem | DocsPath>;
export declare const cleanupWebsiteDeployments: (manifest: WebsiteReleaseManifest) => Effect.Effect<void, unknown, VercelService>;
export declare const promoteWebsite: (manifest: WebsiteReleaseManifest) => Effect.Effect<void, unknown, VercelService>;
export declare const writeReleaseManifest: (target: string, manifest: WebsiteReleaseManifest) => Effect.Effect<void, unknown>;
export declare const rollbackWebsite: (target: string, releaseId?: string) => Effect.Effect<WebsiteReleaseManifest, unknown, VercelService | AtomicWriter | DocsFileSystem | DocsPath>;
/** @internal */
export interface DeploymentVerificationOptions {
    readonly paths?: ReadonlyArray<string>;
}
export declare const verifyWebsiteDeployment: (manifest: WebsiteReleaseManifest, options?: DeploymentVerificationOptions) => Effect.Effect<void, DeploymentVerificationError, NetworkRetry>;
export {};
//# sourceMappingURL=Deployment.d.ts.map