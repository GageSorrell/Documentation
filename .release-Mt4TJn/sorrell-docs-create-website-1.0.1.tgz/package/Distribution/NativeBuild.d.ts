/**
 *
 *
 * @module @sorrell/docs-create-website/NativeBuild
 *
 * @file      NativeBuild.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Effect } from "effect";
import type { NativePlatform } from "./NativeTypes.js";
export declare const generateNativeApp: (target: string, platform?: NativePlatform) => Effect.Effect<void, unknown>;
export declare const verifyNativeApp: (target: string) => Effect.Effect<void, unknown>;
export declare const devNativeApp: (target: string) => Effect.Effect<never, unknown>;
//# sourceMappingURL=NativeBuild.d.ts.map