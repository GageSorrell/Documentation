/**
 * Deterministic agent-readable output for generated documentation sites.
 *
 * @module @sorrell/docs-create-website/AgentOutput
 *
 * @file      AgentOutput.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { type AgentCorpus, type AgentManifest } from "@sorrell/docs-core";
import { Effect } from "effect";
declare const AgentOutputError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "AgentOutputError";
} & Readonly<A>;
/** @internal */
export declare class AgentOutputError extends AgentOutputError_base<{
    readonly path: string;
    readonly message: string;
}> {
}
/** @internal */
export interface AgentOutputOptions {
    readonly generatedAt?: string;
    readonly revision?: string;
}
/** @internal */
export interface AgentOutputResult {
    readonly manifest: AgentManifest;
    readonly corpus: AgentCorpus;
}
export declare const buildAgentOutput: (target: string, options?: AgentOutputOptions) => Effect.Effect<AgentOutputResult, unknown>;
export declare const verifyAgentOutput: (target: string) => Effect.Effect<void, unknown>;
export {};
//# sourceMappingURL=AgentOutput.d.ts.map