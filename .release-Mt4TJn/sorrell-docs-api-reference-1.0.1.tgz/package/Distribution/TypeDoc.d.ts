/**
 * Programmatic TypeDoc discovery and normalization.
 *
 * @module @sorrell/docs-api-reference/TypeDoc
 *
 * @file      TypeDoc.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { ApiReferenceDataset, ApiReferenceGenerationOptions } from "./Types.js";
export declare const generateApiDataset: (options: ApiReferenceGenerationOptions) => Promise<ApiReferenceDataset>;
//# sourceMappingURL=TypeDoc.d.ts.map