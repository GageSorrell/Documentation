/**
 * Typed errors for API-reference generation and snapshot operations.
 *
 * @module @sorrell/docs-api-reference/Errors
 *
 * @file      Errors.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
/** @internal */
export class ApiReferenceError extends Error {
    _tag = "ApiReferenceError";
    constructor(message, options) {
        super(message, options);
        this.name = "ApiReferenceError";
    }
}
/** @internal */
export class ApiReferenceValidationError extends ApiReferenceError {
    errors;
    _tag = "ApiReferenceValidationError";
    constructor(errors) {
        super(`Invalid API-reference dataset: ${errors.join("; ")}`);
        this.errors = errors;
        this.name = "ApiReferenceValidationError";
    }
}
/** @internal */
export class ApiReferenceSnapshotError extends ApiReferenceError {
    path;
    _tag = "ApiReferenceSnapshotError";
    constructor(path, cause) {
        super(`API-reference snapshot operation failed for ${path}`, { cause });
        this.path = path;
        this.name = "ApiReferenceSnapshotError";
    }
}
//# sourceMappingURL=Errors.js.map