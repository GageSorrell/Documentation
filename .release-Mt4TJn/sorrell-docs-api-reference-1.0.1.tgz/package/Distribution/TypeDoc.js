/**
 * Programmatic TypeDoc discovery and normalization.
 *
 * @module @sorrell/docs-api-reference/TypeDoc
 *
 * @file      TypeDoc.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Application, ReflectionKind, TSConfigReader, TypeDocReader } from "typedoc";
import { createApiDataset, validateApiRecords } from "./Serialization.js";
import { ApiReferenceError } from "./Errors.js";
const textOf = (reflection) => reflection?.comment?.summary
    ?.map((part) => part.text ?? "")
    .join("")
    .trim() ?? "";
const sourceOf = (reflection, repositoryUrl, revision, sourceRoot) => {
    const source = reflection?.sources?.[0];
    if (source?.fileName === undefined ||
        repositoryUrl === undefined ||
        revision === undefined) {
        return undefined;
    }
    const rawFile = source.fileName.replaceAll("\\", "/");
    const normalizedRoot = sourceRoot?.replaceAll("\\", "/").replace(/\/$/, "");
    const file = normalizedRoot !== undefined && rawFile.startsWith(`${normalizedRoot}/`)
        ? rawFile.slice(normalizedRoot.length + 1)
        : rawFile;
    return {
        file,
        repositoryUrl,
        revision,
        ...(source.line === undefined ? {} : { line: source.line })
    };
};
const categoryFor = (reflection) => {
    const kind = reflection.kind;
    if (kind === ReflectionKind.Function) {
        return {
            collapsed: false,
            id: "functions",
            label: "Functions",
            order: 0
        };
    }
    if (kind === ReflectionKind.Class) {
        return { collapsed: false, id: "classes", label: "Classes", order: 1 };
    }
    if (kind === ReflectionKind.Interface) {
        return {
            collapsed: false,
            id: "interfaces",
            label: "Interfaces",
            order: 2
        };
    }
    if (kind === ReflectionKind.TypeAlias) {
        return { collapsed: false, id: "types", label: "Types", order: 3 };
    }
    if (kind === ReflectionKind.Variable || kind === ReflectionKind.Enum) {
        return {
            collapsed: false,
            id: "constants",
            label: "Constants",
            order: 4
        };
    }
    if (kind === ReflectionKind.Namespace) {
        return {
            collapsed: false,
            id: "namespaces",
            label: "Namespaces",
            order: 5
        };
    }
    return {
        collapsed: false,
        id: "other",
        label: "Other",
        order: 6
    };
};
const declarationKind = (reflection) => {
    if (reflection.kind === ReflectionKind.Function) {
        return "function";
    }
    if (reflection.kind === ReflectionKind.Class) {
        return "class";
    }
    if (reflection.kind === ReflectionKind.Interface) {
        return "interface";
    }
    if (reflection.kind === ReflectionKind.TypeAlias) {
        return "type";
    }
    if (reflection.kind === ReflectionKind.Namespace) {
        return "namespace";
    }
    return "variable";
};
const signatureFor = (reflection) => {
    const signature = reflection.signatures?.[0];
    const signatureText = signature?.type?.toString?.() ?? signature?.name;
    if (signatureText !== undefined && signatureText !== "") {
        return signatureText;
    }
    const kind = declarationKind(reflection);
    return `export declare ${kind} ${reflection.name ?? "unknown"}`;
};
const declarationId = (name) => {
    const normalized = name
        .replace(/[^A-Za-z0-9_$.-]+/g, "-")
        .replace(/^-+|-+$/g, "");
    return normalized === "" ? "declaration" : normalized;
};
const declarationFrom = (reflection, packageInput, categoryId, options) => {
    const name = reflection.name ?? "unknown";
    const source = sourceOf(reflection, options.repositoryUrl, options.revision, options.sourceRoot);
    return {
        categoryId,
        description: textOf(reflection) || `${name} exported by ${packageInput.name}.`,
        id: declarationId(name),
        kind: declarationKind(reflection),
        name,
        signature: signatureFor(reflection),
        ...(source === undefined ? {} : { source })
    };
};
const recordFrom = (reflection, packageInput, options) => {
    const children = [...(reflection.children ?? [])]
        .filter((child) => child.name !== undefined)
        .sort((left, right) => (left.name ?? "").localeCompare(right.name ?? ""));
    const categories = [
        ...new Map(children.map((child) => {
            const category = categoryFor(child);
            return [category.id, category];
        })).values()
    ].sort((left, right) => left.order - right.order);
    const declarations = children.map((child) => declarationFrom(child, packageInput, categoryFor(child).id, options));
    const moduleName = packageInput.id;
    const displayName = reflection.name ?? packageInput.name;
    const moduleSource = sourceOf(reflection, options.repositoryUrl, options.revision, options.sourceRoot);
    return {
        breadcrumbs: [
            {
                current: false,
                href: `${options.referencePrefix ?? "/docs/api"}/`,
                label: "API Reference"
            },
            {
                current: false,
                href: `${options.referencePrefix ?? "/docs/api"}/${packageInput.version}`,
                label: packageInput.version
            },
            {
                current: false,
                href: `${options.referencePrefix ?? "/docs/api"}/${packageInput.id}`,
                label: packageInput.name
            },
            {
                current: true,
                label: displayName
            }
        ],
        categories,
        declarations,
        displayName,
        exportCount: declarations.length,
        introductionVersion: packageInput.version,
        module: moduleName,
        packageId: packageInput.id,
        packageName: packageInput.name,
        summary: textOf(reflection) || `API reference for ${packageInput.name}.`,
        version: packageInput.version,
        ...(moduleSource === undefined ? {} : { source: moduleSource }),
        link: {
            external: false,
            href: `${options.referencePrefix ?? "/docs/api"}/${moduleName}`,
            label: displayName
        }
    };
};
const moduleReflection = (project) => {
    return project;
};
const typedocOptionsFor = (options) => {
    const repositoryUrl = options.repositoryUrl
        ?.replace(/\/+$/u, "")
        .replace(/\.git$/u, "");
    return {
        ...(repositoryUrl === undefined
            ? {}
            : {
                sourceLinkTemplate: `${repositoryUrl}/blob/{gitRevision}/{path}#L{line}`
            }),
        ...(options.typedoc ?? {})
    };
};
export /** @internal */ const generateApiDataset = async (options) => {
    if (options.packages.length === 0) {
        throw new ApiReferenceError("at least one package must be configured");
    }
    const records = [];
    for (const packageInput of options.packages) {
        const app = await Application.bootstrapWithPlugins({
            entryPoints: packageInput.entryPoints.map((entryPoint) => entryPoint.replaceAll("\\", "/")),
            skipErrorChecking: true,
            ...(packageInput.tsconfig === undefined
                ? {}
                : { tsconfig: packageInput.tsconfig }),
            ...typedocOptionsFor(options)
        }, [new TSConfigReader(), new TypeDocReader()]);
        const project = await app.convert();
        if (project === undefined) {
            throw new ApiReferenceError(`TypeDoc could not convert ${packageInput.name}`);
        }
        records.push(recordFrom(moduleReflection(project), packageInput, options));
    }
    const validation = validateApiRecords(records);
    if (!validation.valid) {
        throw new ApiReferenceError(validation.errors.join("; "));
    }
    const datasetOptions = {
        generatedAt: options.generatedAt ?? new Date().toISOString(),
        ...(options.revision === undefined
            ? {}
            : { sourceRevision: options.revision })
    };
    return createApiDataset(records.sort((left, right) => `${left.packageId}:${left.module}`.localeCompare(`${right.packageId}:${right.module}`)), datasetOptions);
};
//# sourceMappingURL=TypeDoc.js.map