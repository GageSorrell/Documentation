/**
 * Effect-managed API-reference snapshot persistence.
 *
 * @module @sorrell/docs-api-reference/Snapshot
 *
 * @file      Snapshot.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import type { ApiReferenceDataset } from "./Types.js";
import { ApiReferenceSnapshotError } from "./Errors.js";
declare const ApiReferenceSnapshotStore_base: Context.ServiceClass<ApiReferenceSnapshotStore, "sorrell/docs-api-reference/ApiReferenceSnapshotStore", {
    readonly write: (path: string, dataset: ApiReferenceDataset) => Effect.Effect<void, ApiReferenceSnapshotError>;
    readonly read: (path: string) => Effect.Effect<ApiReferenceDataset, ApiReferenceSnapshotError>;
    readonly publish: (source: string, target: string) => Effect.Effect<void, ApiReferenceSnapshotError>;
    readonly restore: (source: string, target: string) => Effect.Effect<void, ApiReferenceSnapshotError>;
}>;
/** @internal */
export declare class ApiReferenceSnapshotStore extends ApiReferenceSnapshotStore_base {
    static readonly layer: Layer.Layer<ApiReferenceSnapshotStore, never, never>;
}
export declare const writeApiSnapshot: (path: string, dataset: ApiReferenceDataset) => Effect.Effect<void, ApiReferenceSnapshotError, ApiReferenceSnapshotStore>;
export declare const readApiSnapshot: (path: string) => Effect.Effect<ApiReferenceDataset, ApiReferenceSnapshotError, ApiReferenceSnapshotStore>;
export {};
//# sourceMappingURL=Snapshot.d.ts.map