/**
 * Deterministic serialization, checksums, and dataset validation.
 *
 * @module @sorrell/docs-api-reference/Serialization
 *
 * @file      Serialization.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { ApiReferenceValidationError } from "./Errors.js";
import { apiReferenceRecordToAgentDocument } from "@sorrell/docs-core";
import { createHash } from "node:crypto";
const sortValue = (value) => {
    if (Array.isArray(value)) {
        return value.map(sortValue);
    }
    if (value !== null && typeof value === "object") {
        return Object.fromEntries(Object.entries(value)
            .sort(([left], [right]) => left.localeCompare(right))
            .map(([key, entry]) => [
            key,
            sortValue(entry)
        ]));
    }
    return value;
};
export /** @internal */ const stableStringify = (value) => JSON.stringify(sortValue(value));
export /** @internal */ const checksumValue = (value) => createHash("sha256").update(stableStringify(value)).digest("hex");
const recordKey = (record) => `${record.packageId}:${record.module}`;
export /** @internal */ const validateApiRecords = (records) => {
    const errors = [];
    const recordKeys = new Set();
    for (const record of records) {
        const key = recordKey(record);
        if (recordKeys.has(key)) {
            errors.push(`duplicate record ${key}`);
        }
        recordKeys.add(key);
        if (record.exportCount !== record.declarations.length) {
            errors.push(`${key} exportCount does not match declarations`);
        }
        const declarationIds = new Set();
        for (const declaration of record.declarations) {
            if (declarationIds.has(declaration.id)) {
                errors.push(`${key} has duplicate declaration ${declaration.id}`);
            }
            declarationIds.add(declaration.id);
            if (!/^[A-Za-z0-9_$.-]+$/.test(declaration.id)) {
                errors.push(`${key} has unsafe declaration id ${declaration.id}`);
            }
            if (declaration.signature.trim() === "") {
                errors.push(`${key}/${declaration.id} has an empty signature`);
            }
        }
    }
    return {
        errors,
        valid: errors.length === 0
    };
};
export /** @internal */ const validateApiDataset = (dataset) => {
    const recordsResult = validateApiRecords(dataset.records);
    const expected = checksumValue({
        records: dataset.records,
        sourceRevision: dataset.sourceRevision
    });
    const errors = [
        ...recordsResult.errors,
        ...(dataset.checksum === expected
            ? []
            : ["checksum does not match dataset contents"])
    ];
    return {
        errors,
        valid: errors.length === 0
    };
};
export /** @internal */ const assertValidApiDataset = (dataset) => {
    const result = validateApiDataset(dataset);
    if (!result.valid) {
        throw new ApiReferenceValidationError(result.errors);
    }
    return dataset;
};
export /** @internal */ const createApiDataset = (records, options) => ({
    checksum: checksumValue({
        records,
        sourceRevision: options.sourceRevision
    }),
    generatedAt: options.generatedAt,
    version: 1,
    ...(options.sourceRevision === undefined
        ? {}
        : { sourceRevision: options.sourceRevision }),
    records
});
export /** @internal */ const recordToAgentDocument = (record) => apiReferenceRecordToAgentDocument(record);
export /** @internal */ const recordToLlmDocument = (record) => recordToAgentDocument(record);
//# sourceMappingURL=Serialization.js.map