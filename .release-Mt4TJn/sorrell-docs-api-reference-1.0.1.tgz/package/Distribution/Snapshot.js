/**
 * Effect-managed API-reference snapshot persistence.
 *
 * @module @sorrell/docs-api-reference/Snapshot
 *
 * @file      Snapshot.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import { copyFile, mkdir, readFile, writeFile } from "node:fs/promises";
import { ApiReferenceSnapshotError } from "./Errors.js";
import { assertValidApiDataset } from "./Serialization.js";
import { dirname } from "node:path";
/** @internal */
export class ApiReferenceSnapshotStore extends Context.Service()("sorrell/docs-api-reference/ApiReferenceSnapshotStore") {
    static layer = Layer.succeed(ApiReferenceSnapshotStore, ApiReferenceSnapshotStore.of({
        publish: (source, target) => Effect.tryPromise({
            catch: (cause) => new ApiReferenceSnapshotError(`${source} -> ${target}`, cause),
            try: async () => {
                await mkdir(dirname(target), { recursive: true });
                await copyFile(source, target);
            }
        }),
        read: (path) => Effect.tryPromise({
            catch: (cause) => cause instanceof ApiReferenceSnapshotError
                ? cause
                : new ApiReferenceSnapshotError(path, cause),
            try: async () => {
                const dataset = JSON.parse(await readFile(path, "utf8"));
                return assertValidApiDataset(dataset);
            }
        }),
        restore: (source, target) => Effect.tryPromise({
            catch: (cause) => new ApiReferenceSnapshotError(`${source} -> ${target}`, cause),
            try: async () => {
                await mkdir(dirname(target), { recursive: true });
                await copyFile(source, target);
            }
        }),
        write: (path, dataset) => Effect.tryPromise({
            catch: (cause) => new ApiReferenceSnapshotError(path, cause),
            try: async () => {
                assertValidApiDataset(dataset);
                await mkdir(dirname(path), { recursive: true });
                await writeFile(path, `${JSON.stringify(dataset, null, 2)}\n`, "utf8");
            }
        })
    }));
}
export /** @internal */ const writeApiSnapshot = (path, dataset) => Effect.gen(function* () {
    const store = yield* ApiReferenceSnapshotStore;
    return yield* store.write(path, dataset);
});
export /** @internal */ const readApiSnapshot = (path) => Effect.gen(function* () {
    const store = yield* ApiReferenceSnapshotStore;
    return yield* store.read(path);
});
//# sourceMappingURL=Snapshot.js.map