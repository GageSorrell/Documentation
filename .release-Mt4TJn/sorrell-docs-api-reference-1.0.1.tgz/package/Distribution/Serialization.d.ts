/**
 * Deterministic serialization, checksums, and dataset validation.
 *
 * @module @sorrell/docs-api-reference/Serialization
 *
 * @file      Serialization.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { ApiReferenceAgentDocument, ApiReferenceDataset, ApiReferenceLlmDocument, ApiReferenceValidationResult } from "./Types.js";
import type { ApiReferenceRecord } from "@sorrell/docs-core";
export declare const stableStringify: (value: unknown) => string;
export declare const checksumValue: (value: unknown) => string;
export declare const validateApiRecords: (records: ReadonlyArray<ApiReferenceRecord>) => ApiReferenceValidationResult;
export declare const validateApiDataset: (dataset: ApiReferenceDataset) => ApiReferenceValidationResult;
export declare const assertValidApiDataset: (dataset: ApiReferenceDataset) => ApiReferenceDataset;
export declare const createApiDataset: (records: ReadonlyArray<ApiReferenceRecord>, options: Pick<ApiReferenceDataset, "generatedAt" | "sourceRevision">) => ApiReferenceDataset;
export declare const recordToAgentDocument: (record: ApiReferenceRecord) => ApiReferenceAgentDocument;
export declare const recordToLlmDocument: (record: ApiReferenceRecord) => ApiReferenceLlmDocument;
//# sourceMappingURL=Serialization.d.ts.map