/**
 * Typed errors for API-reference generation and snapshot operations.
 *
 * @module @sorrell/docs-api-reference/Errors
 *
 * @file      Errors.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
/** @internal */
export declare class ApiReferenceError extends Error {
    readonly _tag: string;
    constructor(message: string, options?: ErrorOptions);
}
/** @internal */
export declare class ApiReferenceValidationError extends ApiReferenceError {
    readonly errors: ReadonlyArray<string>;
    readonly _tag: "ApiReferenceValidationError";
    constructor(errors: ReadonlyArray<string>);
}
/** @internal */
export declare class ApiReferenceSnapshotError extends ApiReferenceError {
    readonly path: string;
    readonly _tag: "ApiReferenceSnapshotError";
    constructor(path: string, cause: unknown);
}
//# sourceMappingURL=Errors.d.ts.map