/**
 * Public models for the API-reference generation pipeline.
 *
 * @module @sorrell/docs-api-reference/Types
 *
 * @file      Types.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
export {};
//# sourceMappingURL=Types.js.map