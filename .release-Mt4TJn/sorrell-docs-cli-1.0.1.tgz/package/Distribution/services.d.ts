/**
 *
 *
 * @module @sorrell/docs-cli/Services
 *
 * @file      services.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { ChildProcess } from "effect/unstable/process";
import { Context, Effect, Layer, Stream } from "effect";
import { DocsAtomicWriteError, DocsFileSystemError, DocsProcessError, DocsTerminalError } from "./errors.js";
import type { Scope } from "effect";
declare const DocsFileSystem_base: Context.ServiceClass<DocsFileSystem, "sorrell/docs-cli/DocsFileSystem", {
    readonly exists: (path: string) => Effect.Effect<boolean, DocsFileSystemError>;
    readonly isDirectory: (path: string) => Effect.Effect<boolean, DocsFileSystemError>;
    readonly makeDirectory: (path: string) => Effect.Effect<void, DocsFileSystemError>;
    readonly makeTempDirectoryScoped: (options?: {
        readonly directory?: string;
        readonly prefix?: string;
    }) => Effect.Effect<string, DocsFileSystemError, Scope.Scope>;
    readonly makeTempFileScoped: (options?: {
        readonly directory?: string;
        readonly prefix?: string;
        readonly suffix?: string;
    }) => Effect.Effect<string, DocsFileSystemError, Scope.Scope>;
    readonly copy: (from: string, to: string, options?: {
        readonly overwrite?: boolean;
        readonly preserveTimestamps?: boolean;
    }) => Effect.Effect<void, DocsFileSystemError>;
    readonly readDirectory: (path: string) => Effect.Effect<ReadonlyArray<string>, DocsFileSystemError>;
    readonly writeBytes: (path: string, content: Uint8Array) => Effect.Effect<void, DocsFileSystemError>;
    readonly readText: (path: string) => Effect.Effect<string, DocsFileSystemError>;
    readonly remove: (path: string, options?: {
        readonly recursive?: boolean;
    }) => Effect.Effect<void, DocsFileSystemError>;
    readonly rename: (from: string, to: string) => Effect.Effect<void, DocsFileSystemError>;
    readonly writeText: (path: string, content: string) => Effect.Effect<void, DocsFileSystemError>;
}>;
/** @internal */
export declare class DocsFileSystem extends DocsFileSystem_base {
    static readonly layer: Layer.Layer<DocsFileSystem, never, never>;
}
declare const DocsPath_base: Context.ServiceClass<DocsPath, "sorrell/docs-cli/DocsPath", {
    readonly basename: (path: string) => string;
    readonly dirname: (path: string) => string;
    readonly join: (...paths: ReadonlyArray<string>) => string;
    readonly resolve: (...paths: ReadonlyArray<string>) => string;
}>;
/** @internal */
export declare class DocsPath extends DocsPath_base {
    static readonly layer: Layer.Layer<DocsPath, never, never>;
}
declare const DocsTerminal_base: Context.ServiceClass<DocsTerminal, "sorrell/docs-cli/DocsTerminal", {
    readonly columns: Effect.Effect<number>;
    readonly display: (text: string) => Effect.Effect<void, DocsTerminalError>;
    readonly readLine: Effect.Effect<string, DocsTerminalError>;
    readonly rows: Effect.Effect<number>;
}>;
/** @internal */
export declare class DocsTerminal extends DocsTerminal_base {
    static readonly layer: Layer.Layer<DocsTerminal, never, never>;
}
declare const TempDirectory_base: Context.ServiceClass<TempDirectory, "sorrell/docs-cli/TempDirectory", {
    readonly makeScoped: (options?: {
        readonly directory?: string;
        readonly prefix?: string;
    }) => Effect.Effect<string, DocsFileSystemError, Scope.Scope>;
}>;
/** @internal */
export declare class TempDirectory extends TempDirectory_base {
    static readonly layer: Layer.Layer<TempDirectory, never, never>;
}
declare const AtomicWriter_base: Context.ServiceClass<AtomicWriter, "sorrell/docs-cli/AtomicWriter", {
    readonly writeText: (path: string, content: string) => Effect.Effect<void, DocsAtomicWriteError>;
}>;
/** @internal */
export declare class AtomicWriter extends AtomicWriter_base {
    static readonly layer: Layer.Layer<AtomicWriter, never, never>;
}
/** @internal */
export type CommandOptions = Omit<ChildProcess.CommandOptions, "additionalFds" | "shell" | "stderr" | "stdin" | "stdout">;
/** @internal */
export interface CommandResult {
    readonly args: ReadonlyArray<string>;
    readonly command: string;
    readonly exitCode: number;
    readonly stderr: string;
    readonly stdout: string;
}
declare const CommandRunner_base: Context.ServiceClass<CommandRunner, "sorrell/docs-cli/CommandRunner", {
    readonly run: (command: string, args?: ReadonlyArray<string>, options?: CommandOptions) => Effect.Effect<CommandResult, DocsProcessError>;
    readonly streamLines: (command: string, args?: ReadonlyArray<string>, options?: CommandOptions) => Stream.Stream<string, DocsProcessError, Scope.Scope>;
}>;
/** @internal */
export declare class CommandRunner extends CommandRunner_base {
    static readonly layer: Layer.Layer<CommandRunner, never, never>;
}
export declare const docsCliLayer: Layer.Layer<DocsFileSystem | DocsPath | DocsTerminal | TempDirectory | AtomicWriter | CommandRunner, never, never>;
export {};
//# sourceMappingURL=services.d.ts.map