/**
 *
 *
 * @module @sorrell/docs-cli/Workspace
 *
 * @file      Workspace.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import { DocsFileSystem, DocsPath } from "./services.js";
import { DocsWorkspaceError } from "./errors.js";
const packagePatterns = (workspaces) => {
    if (Array.isArray(workspaces)) {
        return workspaces.filter((value) => typeof value === "string");
    }
    if (typeof workspaces === "object" &&
        workspaces !== null &&
        "packages" in workspaces) {
        const packages = workspaces.packages;
        return Array.isArray(packages)
            ? packages.filter((value) => typeof value === "string")
            : [];
    }
    return [];
};
const readManifest = (fileSystem, path) => fileSystem.readText(path).pipe(Effect.flatMap((text) => Effect.try({
    catch: (cause) => new DocsWorkspaceError({
        cause,
        operation: "parseManifest",
        path
    }),
    try: () => JSON.parse(text)
})), Effect.mapError((cause) => cause instanceof DocsWorkspaceError
    ? cause
    : new DocsWorkspaceError({
        cause,
        operation: "readManifest",
        path
    })));
const packageFromManifest = (directory, manifest) => {
    if (typeof manifest.name !== "string") {
        return undefined;
    }
    return {
        directory,
        manifest: manifest,
        name: manifest.name,
        private: manifest.private === true,
        version: typeof manifest.version === "string" ? manifest.version : undefined
    };
};
/** @internal */
export class WorkspaceDiscovery extends Context.Service()("sorrell/docs-cli/WorkspaceDiscovery") {
    static layer = Layer.effect(WorkspaceDiscovery, Effect.gen(function* () {
        const fileSystem = yield* DocsFileSystem;
        const path = yield* DocsPath;
        const discover = (root) => Effect.gen(function* () {
            const resolvedRoot = path.resolve(root);
            const rootManifestPath = path.join(resolvedRoot, "package.json");
            const rootManifest = yield* readManifest(fileSystem, rootManifestPath);
            const packages = [];
            for (const pattern of packagePatterns(rootManifest.workspaces)) {
                if (!pattern.endsWith("/*")) {
                    continue;
                }
                const parent = path.join(resolvedRoot, pattern.slice(0, -2));
                const entries = yield* fileSystem
                    .readDirectory(parent)
                    .pipe(Effect.mapError((cause) => new DocsWorkspaceError({
                    cause,
                    operation: "readWorkspace",
                    path: parent
                })));
                for (const entry of [...entries].sort()) {
                    const directory = path.join(parent, entry);
                    const manifestPath = path.join(directory, "package.json");
                    if (!(yield* fileSystem.exists(manifestPath))) {
                        continue;
                    }
                    const manifest = yield* readManifest(fileSystem, manifestPath);
                    const packageValue = packageFromManifest(directory, manifest);
                    if (packageValue !== undefined) {
                        packages.push(packageValue);
                    }
                }
            }
            return {
                packageManager: typeof rootManifest.packageManager === "string"
                    ? rootManifest.packageManager
                    : undefined,
                packages: packages.sort((left, right) => left.name.localeCompare(right.name)),
                root: resolvedRoot
            };
        }).pipe(Effect.mapError((cause) => cause instanceof DocsWorkspaceError
            ? cause
            : new DocsWorkspaceError({
                cause,
                operation: "discover",
                path: root
            })));
        return WorkspaceDiscovery.of({ discover });
    })).pipe(Layer.provide(Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer)));
}
//# sourceMappingURL=Workspace.js.map