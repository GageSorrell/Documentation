/**
 *
 *
 * @module @sorrell/docs-cli/Runtime
 *
 * @file      runtime.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { NodeServices } from "@effect/platform-node";
import { Effect } from "effect";
export declare const nodeServicesLayer: import("effect/Layer").Layer<NodeServices.NodeServices, never, never>;
export declare const provideNodeServices: <A, E, R>(program: Effect.Effect<A, E, R>) => Effect.Effect<A, E, Exclude<R, NodeServices.NodeServices>>;
export declare const runMain: {
    (options?: {
        readonly disableErrorReporting?: boolean | undefined;
        readonly teardown?: import("effect/Runtime").Teardown | undefined;
    }): <E, A>(effect: Effect.Effect<A, E>) => void;
    <E, A>(effect: Effect.Effect<A, E>, options?: {
        readonly disableErrorReporting?: boolean | undefined;
        readonly teardown?: import("effect/Runtime").Teardown | undefined;
    }): void;
};
//# sourceMappingURL=runtime.d.ts.map