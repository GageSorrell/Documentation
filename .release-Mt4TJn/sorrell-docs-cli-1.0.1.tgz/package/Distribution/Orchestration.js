/**
 *
 *
 * @module @sorrell/docs-cli/Orchestration
 *
 * @file      Orchestration.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import { DocsStageError } from "./errors.js";
/** @internal */
export class AutomationOrchestrator extends Context.Service()("sorrell/docs-cli/AutomationOrchestrator") {
    static layer = Layer.succeed(AutomationOrchestrator, AutomationOrchestrator.of({
        parallel: (effects, concurrency = 4) => Effect.all(effects, { concurrency }),
        sequential: (stages) => stages.reduce((program, stage) => program.pipe(Effect.flatMap((values) => stage.run.pipe(Effect.map((value) => [
            ...values,
            value
        ]), Effect.mapError((cause) => new DocsStageError({
            cause,
            stage: stage.name
        }))))), Effect.succeed([]))
    }));
}
//# sourceMappingURL=Orchestration.js.map