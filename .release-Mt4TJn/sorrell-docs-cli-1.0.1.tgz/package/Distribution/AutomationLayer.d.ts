/**
 *
 *
 * @module @sorrell/docs-cli/AutomationLayer
 *
 * @file      AutomationLayer.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { ArchiveService, GitHubService, GitService, NetworkRetry, VercelService } from "./Integrations.js";
import { AtomicDirectoryPromotion, ManifestTracker, SafeTargetValidation, TemplateRenderer } from "./Generation.js";
import { AutomationOrchestrator } from "./Orchestration.js";
import { ChecksumService } from "./Checksum.js";
import { DeploymentEnvironment } from "./Environment.js";
import { Layer } from "effect";
import { PackageManagerSelection } from "./PackageManager.js";
import { WorkspaceDiscovery } from "./Workspace.js";
export declare const docsAutomationLayer: Layer.Layer<import("./services.js").DocsFileSystem | import("./services.js").DocsPath | import("./services.js").DocsTerminal | import("./services.js").TempDirectory | import("./services.js").AtomicWriter | import("./services.js").CommandRunner | DeploymentEnvironment | GitService | GitHubService | VercelService | ArchiveService | NetworkRetry | TemplateRenderer | SafeTargetValidation | AtomicDirectoryPromotion | ManifestTracker | AutomationOrchestrator | ChecksumService | PackageManagerSelection | WorkspaceDiscovery, never, never>;
//# sourceMappingURL=AutomationLayer.d.ts.map