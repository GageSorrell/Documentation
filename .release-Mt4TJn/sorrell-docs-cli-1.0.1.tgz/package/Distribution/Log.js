/**
 *
 *
 * @module @sorrell/docs-cli/Logging
 *
 * @file      Log.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Effect } from "effect";
export /** @internal */ const logEvent = (event, fields = {}) => Effect.logInfo(event).pipe(Effect.annotateLogs(fields));
//# sourceMappingURL=Log.js.map