/**
 *
 *
 * @module @sorrell/docs-cli/Errors
 *
 * @file      errors.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
declare const DocsFileSystemError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsFileSystemError";
} & Readonly<A>;
/** @internal */
export declare class DocsFileSystemError extends DocsFileSystemError_base<{
    readonly operation: string;
    readonly path: string;
    readonly cause: unknown;
}> {
}
declare const DocsAtomicWriteError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsAtomicWriteError";
} & Readonly<A>;
/** @internal */
export declare class DocsAtomicWriteError extends DocsAtomicWriteError_base<{
    readonly path: string;
    readonly cause: unknown;
}> {
}
declare const DocsTerminalError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsTerminalError";
} & Readonly<A>;
/** @internal */
export declare class DocsTerminalError extends DocsTerminalError_base<{
    readonly operation: string;
    readonly cause: unknown;
}> {
}
declare const DocsProcessError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsProcessError";
} & Readonly<A>;
/** @internal */
export declare class DocsProcessError extends DocsProcessError_base<{
    readonly command: string;
    readonly args: ReadonlyArray<string>;
    readonly exitCode: number | undefined;
    readonly stdout: string;
    readonly stderr: string;
    readonly cause: unknown;
}> {
}
declare const DocsWorkspaceError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsWorkspaceError";
} & Readonly<A>;
/** @internal */
export declare class DocsWorkspaceError extends DocsWorkspaceError_base<{
    readonly operation: string;
    readonly path: string;
    readonly cause: unknown;
}> {
}
declare const DocsTargetError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsTargetError";
} & Readonly<A>;
/** @internal */
export declare class DocsTargetError extends DocsTargetError_base<{
    readonly target: string;
    readonly reason: string;
}> {
}
declare const DocsTemplateError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsTemplateError";
} & Readonly<A>;
/** @internal */
export declare class DocsTemplateError extends DocsTemplateError_base<{
    readonly path: string;
    readonly cause: unknown;
}> {
}
declare const DocsManifestError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsManifestError";
} & Readonly<A>;
/** @internal */
export declare class DocsManifestError extends DocsManifestError_base<{
    readonly path: string;
    readonly cause: unknown;
}> {
}
declare const DocsIntegrationError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsIntegrationError";
} & Readonly<A>;
/** @internal */
export declare class DocsIntegrationError extends DocsIntegrationError_base<{
    readonly provider: "git" | "github" | "vercel";
    readonly operation: string;
    readonly cause: unknown;
}> {
}
declare const DocsEnvironmentError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsEnvironmentError";
} & Readonly<A>;
/** @internal */
export declare class DocsEnvironmentError extends DocsEnvironmentError_base<{
    readonly provider: "github" | "vercel";
    readonly missing: ReadonlyArray<string>;
}> {
}
declare const DocsArchiveError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsArchiveError";
} & Readonly<A>;
/** @internal */
export declare class DocsArchiveError extends DocsArchiveError_base<{
    readonly operation: string;
    readonly path: string;
    readonly cause: unknown;
}> {
}
declare const DocsStageError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsStageError";
} & Readonly<A>;
/** @internal */
export declare class DocsStageError extends DocsStageError_base<{
    readonly stage: string;
    readonly cause: unknown;
}> {
}
export {};
//# sourceMappingURL=errors.d.ts.map