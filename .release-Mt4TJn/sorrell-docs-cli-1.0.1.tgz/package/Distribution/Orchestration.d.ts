/**
 *
 *
 * @module @sorrell/docs-cli/Orchestration
 *
 * @file      Orchestration.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import { DocsStageError } from "./errors.js";
/** @internal */
export interface Stage<Value> {
    readonly name: string;
    readonly run: Effect.Effect<Value, unknown>;
}
declare const AutomationOrchestrator_base: Context.ServiceClass<AutomationOrchestrator, "sorrell/docs-cli/AutomationOrchestrator", {
    readonly parallel: <Value>(effects: ReadonlyArray<Effect.Effect<Value, unknown>>, concurrency?: number) => Effect.Effect<ReadonlyArray<Value>, unknown>;
    readonly sequential: <Value>(stages: ReadonlyArray<Stage<Value>>) => Effect.Effect<ReadonlyArray<Value>, DocsStageError>;
}>;
/** @internal */
export declare class AutomationOrchestrator extends AutomationOrchestrator_base {
    static readonly layer: Layer.Layer<AutomationOrchestrator, never, never>;
}
export {};
//# sourceMappingURL=Orchestration.d.ts.map