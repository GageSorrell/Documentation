/**
 * @module @sorrell/docs-cli/Integrations
 *
 * @file      Integrations.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import { DocsArchiveError, DocsIntegrationError } from "./errors.js";
/** @internal */
export interface GitStatus {
    readonly clean: boolean;
    readonly output: string;
}
/** @internal */
export interface VercelDeploymentResult {
    readonly deploymentId: string;
    readonly url: string;
    readonly raw: string;
}
/** @internal */
export interface VercelDeploymentInspection {
    readonly deploymentId: string;
    readonly url: string;
    readonly state: "BUILDING" | "ERROR" | "INITIALIZING" | "QUEUED" | "READY" | "UNKNOWN";
    readonly raw: string;
}
declare const GitService_base: Context.ServiceClass<GitService, "sorrell/docs-cli/GitService", {
    readonly revision: (directory: string) => Effect.Effect<string, DocsIntegrationError>;
    readonly remote: (directory: string, remote?: string) => Effect.Effect<string, DocsIntegrationError>;
    readonly status: (directory: string) => Effect.Effect<GitStatus, DocsIntegrationError>;
}>;
/** @internal */
export declare class GitService extends GitService_base {
    static readonly layer: Layer.Layer<GitService, never, never>;
}
declare const GitHubService_base: Context.ServiceClass<GitHubService, "sorrell/docs-cli/GitHubService", {
    readonly createRepository: (name: string, directory: string, options?: {
        readonly visibility?: "public" | "private";
        readonly description?: string;
    }) => Effect.Effect<string, DocsIntegrationError>;
    readonly viewRepository: (repository: string) => Effect.Effect<string, DocsIntegrationError>;
}>;
/** @internal */
export declare class GitHubService extends GitHubService_base {
    static readonly layer: Layer.Layer<GitHubService, never, never>;
}
declare const VercelService_base: Context.ServiceClass<VercelService, "sorrell/docs-cli/VercelService", {
    readonly deploy: (directory: string, options?: {
        readonly production?: boolean;
        readonly name?: string;
        readonly team?: string;
    }) => Effect.Effect<VercelDeploymentResult, DocsIntegrationError>;
    readonly inspect: (deployment: string) => Effect.Effect<VercelDeploymentInspection, DocsIntegrationError>;
    readonly promote: (deployment: string) => Effect.Effect<void, DocsIntegrationError>;
    readonly alias: (deployment: string, alias: string) => Effect.Effect<void, DocsIntegrationError>;
    readonly rollback: (deployment?: string) => Effect.Effect<void, DocsIntegrationError>;
    readonly remove: (deployment: string) => Effect.Effect<void, DocsIntegrationError>;
}>;
/** @internal */
export declare class VercelService extends VercelService_base {
    static readonly layer: Layer.Layer<VercelService, never, never>;
}
declare const ArchiveService_base: Context.ServiceClass<ArchiveService, "sorrell/docs-cli/ArchiveService", {
    readonly createTar: (sourceDirectory: string, destination: string) => Effect.Effect<void, DocsArchiveError>;
    readonly createZip: (sourceDirectory: string, destination: string) => Effect.Effect<void, DocsArchiveError>;
    readonly extractZip: (archive: string, destination: string) => Effect.Effect<void, DocsArchiveError>;
}>;
/** @internal */
export declare class ArchiveService extends ArchiveService_base {
    static readonly layer: Layer.Layer<ArchiveService, never, never>;
}
/** @internal */
export interface RetryOptions {
    readonly maxRetries?: number;
    readonly delay?: `${number} ${"millis" | "seconds"}`;
}
declare const NetworkRetry_base: Context.ServiceClass<NetworkRetry, "sorrell/docs-cli/NetworkRetry", {
    readonly run: <Value, Error, Requirements>(effect: Effect.Effect<Value, Error, Requirements>, isRetryable: (error: Error) => boolean, options?: RetryOptions) => Effect.Effect<Value, Error, Requirements>;
}>;
/** @internal */
export declare class NetworkRetry extends NetworkRetry_base {
    static readonly layer: Layer.Layer<NetworkRetry, never, never>;
}
export {};
//# sourceMappingURL=Integrations.d.ts.map