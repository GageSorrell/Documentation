/**
 *
 *
 * @module @sorrell/docs-cli/Errors
 *
 * @file      errors.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Data } from "effect";
/** @internal */
export class DocsFileSystemError extends Data.TaggedError("DocsFileSystemError") {
}
/** @internal */
export class DocsAtomicWriteError extends Data.TaggedError("DocsAtomicWriteError") {
}
/** @internal */
export class DocsTerminalError extends Data.TaggedError("DocsTerminalError") {
}
/** @internal */
export class DocsProcessError extends Data.TaggedError("DocsProcessError") {
}
/** @internal */
export class DocsWorkspaceError extends Data.TaggedError("DocsWorkspaceError") {
}
/** @internal */
export class DocsTargetError extends Data.TaggedError("DocsTargetError") {
}
/** @internal */
export class DocsTemplateError extends Data.TaggedError("DocsTemplateError") {
}
/** @internal */
export class DocsManifestError extends Data.TaggedError("DocsManifestError") {
}
/** @internal */
export class DocsIntegrationError extends Data.TaggedError("DocsIntegrationError") {
}
/** @internal */
export class DocsEnvironmentError extends Data.TaggedError("DocsEnvironmentError") {
}
/** @internal */
export class DocsArchiveError extends Data.TaggedError("DocsArchiveError") {
}
/** @internal */
export class DocsStageError extends Data.TaggedError("DocsStageError") {
}
//# sourceMappingURL=errors.js.map