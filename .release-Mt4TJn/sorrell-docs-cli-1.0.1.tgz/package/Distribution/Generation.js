/**
 *
 *
 * @module @sorrell/docs-cli/Generation
 *
 * @file      Generation.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { AtomicWriter, DocsFileSystem, DocsPath } from "./services.js";
import { Context, Effect, Layer } from "effect";
import { DocsManifestError, DocsTargetError, DocsTemplateError } from "./errors.js";
export /** @internal */ const renderTemplate = (template, values) => template.replace(/\{\{\s*([A-Za-z0-9_.-]+)\s*\}\}/g, (match, key) => {
    const value = values[key];
    return value === undefined ? match : String(value);
});
const unresolvedPlaceholders = (content) => [...content.matchAll(/\{\{\s*([A-Za-z0-9_.-]+)\s*\}\}/g)].map((match) => match[1] ?? "");
/** @internal */
export class TemplateRenderer extends Context.Service()("sorrell/docs-cli/TemplateRenderer") {
    static layer = Layer.effect(TemplateRenderer, Effect.gen(function* () {
        const fileSystem = yield* DocsFileSystem;
        const atomicWriter = yield* AtomicWriter;
        const render = (template, values) => Effect.try({
            catch: (cause) => new DocsTemplateError({
                cause,
                path: "<template>"
            }),
            try: () => {
                const result = renderTemplate(template, values);
                const missing = unresolvedPlaceholders(result);
                if (missing.length > 0) {
                    throw new Error(`unresolved placeholders: ${missing.join(", ")}`);
                }
                return result;
            }
        });
        return TemplateRenderer.of({
            render,
            renderFile: (source, target, values) => fileSystem.readText(source).pipe(Effect.flatMap((template) => render(template, values)), Effect.flatMap((content) => atomicWriter.writeText(target, content)), Effect.mapError((cause) => cause instanceof DocsTemplateError
                ? new DocsTemplateError({
                    cause,
                    path: source
                })
                : new DocsTemplateError({
                    cause,
                    path: target
                })))
        });
    })).pipe(Layer.provide(Layer.mergeAll(DocsFileSystem.layer, AtomicWriter.layer)));
}
/** @internal */
export class SafeTargetValidation extends Context.Service()("sorrell/docs-cli/SafeTargetValidation") {
    static layer = Layer.effect(SafeTargetValidation, Effect.gen(function* () {
        const fileSystem = yield* DocsFileSystem;
        const path = yield* DocsPath;
        return SafeTargetValidation.of({
            validateEmpty: (target, parent) => Effect.gen(function* () {
                const resolvedTarget = path.resolve(target);
                const root = path.resolve(parent ?? path.dirname(resolvedTarget));
                if (resolvedTarget === root) {
                    return yield* Effect.fail(new DocsTargetError({
                        reason: "target cannot be the containing directory",
                        target: resolvedTarget
                    }));
                }
                const relativeTarget = resolvedTarget.slice(root.length);
                if (parent !== undefined &&
                    relativeTarget.length > 0 &&
                    !/^[\\/]/.test(relativeTarget)) {
                    return yield* Effect.fail(new DocsTargetError({
                        reason: "target must remain inside the requested parent",
                        target: resolvedTarget
                    }));
                }
                if (yield* fileSystem.exists(resolvedTarget)) {
                    const entries = yield* fileSystem.readDirectory(resolvedTarget);
                    if (entries.length > 0) {
                        return yield* Effect.fail(new DocsTargetError({
                            reason: "target must be empty",
                            target: resolvedTarget
                        }));
                    }
                }
                return resolvedTarget;
            }).pipe(Effect.mapError((cause) => cause instanceof DocsTargetError
                ? cause
                : new DocsTargetError({
                    reason: String(cause),
                    target
                })))
        });
    })).pipe(Layer.provide(Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer)));
}
/** @internal */
export class AtomicDirectoryPromotion extends Context.Service()("sorrell/docs-cli/AtomicDirectoryPromotion") {
    static layer = Layer.effect(AtomicDirectoryPromotion, Effect.gen(function* () {
        const fileSystem = yield* DocsFileSystem;
        return AtomicDirectoryPromotion.of({
            promote: (staging, target) => Effect.gen(function* () {
                if (yield* fileSystem.exists(target)) {
                    return yield* Effect.fail(new DocsTargetError({
                        reason: "promotion target already exists",
                        target
                    }));
                }
                yield* fileSystem.rename(staging, target).pipe(Effect.mapError((cause) => new DocsTargetError({
                    reason: `atomic promotion failed: ${String(cause)}`,
                    target
                })));
            }).pipe(Effect.mapError((cause) => cause instanceof DocsTargetError
                ? cause
                : new DocsTargetError({
                    reason: String(cause),
                    target
                })))
        });
    })).pipe(Layer.provide(DocsFileSystem.layer));
}
/** @internal */
export class ManifestTracker extends Context.Service()("sorrell/docs-cli/ManifestTracker") {
    static layer = Layer.effect(ManifestTracker, Effect.gen(function* () {
        const fileSystem = yield* DocsFileSystem;
        const atomicWriter = yield* AtomicWriter;
        const read = (path) => fileSystem.readText(path).pipe(Effect.flatMap((text) => Effect.try({
            catch: (cause) => new DocsManifestError({ cause, path }),
            try: () => JSON.parse(text)
        })), Effect.mapError((cause) => cause instanceof DocsManifestError
            ? cause
            : new DocsManifestError({ cause, path })));
        return ManifestTracker.of({
            read,
            write: (path, manifest) => atomicWriter
                .writeText(path, JSON.stringify(manifest, null, 2))
                .pipe(Effect.mapError((cause) => new DocsManifestError({ cause, path })))
        });
    })).pipe(Layer.provide(Layer.mergeAll(DocsFileSystem.layer, AtomicWriter.layer)));
}
//# sourceMappingURL=Generation.js.map