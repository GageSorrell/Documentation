/**
 * @module @sorrell/docs-cli/Integrations
 *
 * @file      Integrations.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { CommandRunner } from "./services.js";
import { Context, Effect, Layer, Redacted, Schedule } from "effect";
import { createRequire } from "node:module";
import { DeploymentEnvironment } from "./Environment.js";
import { DocsArchiveError, DocsIntegrationError } from "./errors.js";
const ansiEscape = String.fromCharCode(27);
const ansiPattern = new RegExp(`${ansiEscape}\\[[0-?]*[ -/]*[@-~]`, "g");
const stripAnsi = (value) => value.replace(ansiPattern, "");
const require = createRequire(import.meta.url);
const vercelExecutable = process.execPath;
const vercelScript = require.resolve("vercel/dist/vc.js");
const vercelCommand = (args) => [
    vercelScript,
    ...args
];
const parseDeployment = (raw) => {
    const cleaned = stripAnsi(raw).trim();
    try {
        const value = JSON.parse(cleaned);
        if (typeof value.url === "string") {
            return {
                deploymentId: typeof value.id === "string"
                    ? value.id
                    : typeof value.deploymentId === "string"
                        ? value.deploymentId
                        : value.url,
                raw: cleaned,
                url: value.url.startsWith("http")
                    ? value.url
                    : `https://${value.url}`
            };
        }
    }
    catch {
        // The CLI may emit human-readable output when an older version is used.
    }
    const urls = [...cleaned.matchAll(/https?:\/\/[^\s)]+/g)]
        .map((match) => match[0]?.replace(/[.,]$/, ""))
        .filter((value) => value !== undefined);
    const url = urls.at(-1) ?? cleaned.split(/\s+/).at(-1) ?? cleaned;
    return { deploymentId: url, raw: cleaned, url };
};
const parseInspection = (raw, deployment) => {
    const cleaned = stripAnsi(raw).trim();
    try {
        const value = JSON.parse(cleaned);
        const state = value.readyState ?? value.state;
        return {
            deploymentId: typeof value.id === "string" ? value.id : deployment,
            raw: cleaned,
            state: state === "BUILDING" ||
                state === "ERROR" ||
                state === "INITIALIZING" ||
                state === "QUEUED" ||
                state === "READY"
                ? state
                : "UNKNOWN",
            url: typeof value.url === "string" ? value.url : deployment
        };
    }
    catch {
        return {
            deploymentId: deployment,
            raw: cleaned,
            state: "UNKNOWN",
            url: deployment
        };
    }
};
/** @internal */
export class GitService extends Context.Service()("sorrell/docs-cli/GitService") {
    static layer = Layer.effect(GitService, Effect.gen(function* () {
        const runner = yield* CommandRunner;
        const run = (directory, args, operation) => runner.run("git", args, { cwd: directory }).pipe(Effect.mapError((cause) => new DocsIntegrationError({
            cause,
            operation,
            provider: "git"
        })));
        return GitService.of({
            remote: (directory, remote = "origin") => run(directory, ["remote", "get-url", remote], "remote").pipe(Effect.map((result) => result.stdout.trim())),
            revision: (directory) => run(directory, ["rev-parse", "HEAD"], "revision").pipe(Effect.map((result) => result.stdout.trim())),
            status: (directory) => run(directory, ["status", "--porcelain"], "status").pipe(Effect.map((result) => ({
                clean: result.stdout.trim() === "",
                output: result.stdout
            })))
        });
    })).pipe(Layer.provide(CommandRunner.layer));
}
/** @internal */
export class GitHubService extends Context.Service()("sorrell/docs-cli/GitHubService") {
    static layer = Layer.effect(GitHubService, Effect.gen(function* () {
        const runner = yield* CommandRunner;
        const run = (args, operation, cwd) => runner
            .run("gh", args, cwd === undefined ? undefined : { cwd })
            .pipe(Effect.mapError((cause) => new DocsIntegrationError({
            cause,
            operation,
            provider: "github"
        })));
        return GitHubService.of({
            createRepository: (name, directory, options) => run([
                "repo",
                "create",
                name,
                options?.visibility === "private"
                    ? "--private"
                    : "--public",
                ...(options?.description === undefined
                    ? []
                    : ["--description", options.description]),
                "--source",
                directory,
                "--push"
            ], "createRepository", directory).pipe(Effect.map((result) => result.stdout.trim())),
            viewRepository: (repository) => run([
                "repo",
                "view",
                repository,
                "--json",
                "url",
                "--jq",
                ".url"
            ], "viewRepository").pipe(Effect.map((result) => result.stdout.trim()))
        });
    })).pipe(Layer.provide(CommandRunner.layer));
}
/** @internal */
export class VercelService extends Context.Service()("sorrell/docs-cli/VercelService") {
    static layer = Layer.effect(VercelService, Effect.gen(function* () {
        const runner = yield* CommandRunner;
        const environment = yield* DeploymentEnvironment;
        const withAuth = (args) => environment.requireVercel.pipe(Effect.map((credentials) => [
            ...args,
            "--token",
            Redacted.value(credentials.token),
            "--scope",
            credentials.orgId
        ]), Effect.mapError((cause) => new DocsIntegrationError({
            cause,
            operation: "authentication",
            provider: "vercel"
        })));
        const run = (args, operation, cwd) => runner
            .run(vercelExecutable, vercelCommand(args), cwd === undefined ? undefined : { cwd })
            .pipe(Effect.mapError((cause) => new DocsIntegrationError({
            cause,
            operation,
            provider: "vercel"
        })));
        return VercelService.of({
            alias: (deployment, alias) => withAuth(["alias", "set", deployment, alias]).pipe(Effect.flatMap((args) => run([...args, "--yes"], "alias")), Effect.asVoid),
            deploy: (directory, options) => withAuth([
                "deploy",
                ...(options?.production === true
                    ? ["--prod"]
                    : []),
                ...(options?.name === undefined
                    ? []
                    : ["--project", options.name]),
                ...(options?.team === undefined
                    ? []
                    : ["--scope", options.team]),
                "--yes",
                "--json"
            ]).pipe(Effect.flatMap((args) => run(args, "deploy", directory)), Effect.map((result) => parseDeployment(result.stdout))),
            inspect: (deployment) => withAuth(["inspect", deployment, "--json"]).pipe(Effect.flatMap((args) => run(args, "inspect")), Effect.map((result) => parseInspection(result.stdout, deployment))),
            promote: (deployment) => withAuth(["promote", deployment]).pipe(Effect.flatMap((args) => run([...args, "--yes"], "promote")), Effect.asVoid),
            remove: (deployment) => withAuth(["remove", deployment]).pipe(Effect.flatMap((args) => run([...args, "--yes"], "remove")), Effect.asVoid),
            rollback: (deployment) => withAuth([
                "rollback",
                ...(deployment === undefined
                    ? []
                    : [deployment])
            ]).pipe(Effect.flatMap((args) => run([...args, "--yes"], "rollback")), Effect.asVoid)
        });
    })).pipe(Layer.provide(CommandRunner.layer), Layer.provide(DeploymentEnvironment.layer));
}
/** @internal */
export class ArchiveService extends Context.Service()("sorrell/docs-cli/ArchiveService") {
    static layer = Layer.effect(ArchiveService, Effect.gen(function* () {
        const runner = yield* CommandRunner;
        return ArchiveService.of({
            createTar: (sourceDirectory, destination) => runner
                .run("tar", [
                "-cf",
                destination,
                "-C",
                sourceDirectory,
                "."
            ])
                .pipe(Effect.mapError((cause) => new DocsArchiveError({
                cause,
                operation: "createTar",
                path: destination
            })), Effect.asVoid),
            createZip: (sourceDirectory, destination) => runner
                .run("tar", [
                "-a",
                "-cf",
                destination,
                "-C",
                sourceDirectory,
                "."
            ])
                .pipe(Effect.mapError((cause) => new DocsArchiveError({
                cause,
                operation: "createZip",
                path: destination
            })), Effect.asVoid),
            extractZip: (archive, destination) => runner
                .run("tar", ["-xf", archive, "-C", destination])
                .pipe(Effect.mapError((cause) => new DocsArchiveError({
                cause,
                operation: "extractZip",
                path: archive
            })), Effect.asVoid)
        });
    })).pipe(Layer.provide(CommandRunner.layer));
}
/** @internal */
export class NetworkRetry extends Context.Service()("sorrell/docs-cli/NetworkRetry") {
    static layer = Layer.succeed(NetworkRetry, NetworkRetry.of({
        run: (effect, isRetryable, options) => options?.delay === undefined
            ? Effect.retry(effect, {
                times: options?.maxRetries ?? 3,
                while: isRetryable
            })
            : Effect.retry(effect, {
                schedule: Schedule.exponential(options.delay).pipe(Schedule.upTo({
                    times: options.maxRetries ?? 3
                })),
                while: isRetryable
            })
    }));
}
//# sourceMappingURL=Integrations.js.map