/**
 *
 *
 * @module @sorrell/docs-cli/Workspace
 *
 * @file      Workspace.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import { DocsWorkspaceError } from "./errors.js";
/** @internal */
export interface WorkspacePackage {
    readonly name: string;
    readonly version: string | undefined;
    readonly directory: string;
    readonly private: boolean;
    readonly manifest: Readonly<Record<string, unknown>>;
}
/** @internal */
export interface WorkspaceDescription {
    readonly root: string;
    readonly packageManager: string | undefined;
    readonly packages: ReadonlyArray<WorkspacePackage>;
}
declare const WorkspaceDiscovery_base: Context.ServiceClass<WorkspaceDiscovery, "sorrell/docs-cli/WorkspaceDiscovery", {
    readonly discover: (root: string) => Effect.Effect<WorkspaceDescription, DocsWorkspaceError>;
}>;
/** @internal */
export declare class WorkspaceDiscovery extends WorkspaceDiscovery_base {
    static readonly layer: Layer.Layer<WorkspaceDiscovery, never, never>;
}
export {};
//# sourceMappingURL=Workspace.d.ts.map