/**
 *
 *
 * @module @sorrell/docs-cli/FixtureCommand
 *
 * @file      FixtureCommand.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Command } from "effect/unstable/cli";
import { Effect } from "effect";
/** @internal */
export interface FixtureInput {
    readonly count: number;
    readonly name: string;
}
export declare const makeFixtureCommand: (onRun: (input: FixtureInput) => Effect.Effect<void>) => Command.Command<"runtime-fixture", {
    readonly count: number;
    readonly name: string;
}, {}, never, never>;
export declare const runFixtureCommand: (args: ReadonlyArray<string>, onRun: (input: FixtureInput) => Effect.Effect<void>) => Effect.Effect<void, import("effect/unstable/cli/CliError").CliError, never>;
//# sourceMappingURL=FixtureCommand.d.ts.map