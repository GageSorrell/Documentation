/**
 *
 *
 * @module @sorrell/docs-cli/Checksum
 *
 * @file      Checksum.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import { DocsFileSystem } from "./services.js";
import { createHash } from "node:crypto";
export /** @internal */ const checksumText = (value) => createHash("sha256").update(value, "utf8").digest("hex");
/** @internal */
export class ChecksumService extends Context.Service()("sorrell/docs-cli/ChecksumService") {
    static layer = Layer.effect(ChecksumService, Effect.gen(function* () {
        const fileSystem = yield* DocsFileSystem;
        return ChecksumService.of({
            file: (path) => fileSystem
                .readText(path)
                .pipe(Effect.map(checksumText)),
            text: (value) => Effect.sync(() => checksumText(value))
        });
    })).pipe(Layer.provide(DocsFileSystem.layer));
}
//# sourceMappingURL=Checksum.js.map