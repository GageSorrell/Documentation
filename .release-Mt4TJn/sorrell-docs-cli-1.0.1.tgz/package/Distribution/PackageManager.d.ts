/**
 *
 *
 * @module @sorrell/docs-cli/PackageManager
 *
 * @file      PackageManager.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import type { DocsFileSystemError } from "./errors.js";
/** @internal */
export type PackageManagerName = "npm" | "pnpm" | "yarn" | "bun";
/** @internal */
export interface PackageManagerInfo {
    readonly name: PackageManagerName;
    readonly executable: string;
    readonly installArguments: ReadonlyArray<string>;
    readonly runArguments: (script: string, args?: ReadonlyArray<string>) => ReadonlyArray<string>;
}
export declare const packageManagerInfo: (name: PackageManagerName) => PackageManagerInfo;
export declare const selectPackageManager: (packageManager: string | undefined, lockfiles: ReadonlyArray<string>) => PackageManagerInfo;
declare const PackageManagerSelection_base: Context.ServiceClass<PackageManagerSelection, "sorrell/docs-cli/PackageManagerSelection", {
    readonly select: (root: string, packageManager?: string) => Effect.Effect<PackageManagerInfo, DocsFileSystemError>;
}>;
/** @internal */
export declare class PackageManagerSelection extends PackageManagerSelection_base {
    static readonly layer: Layer.Layer<PackageManagerSelection, never, never>;
}
export {};
//# sourceMappingURL=PackageManager.d.ts.map