/**
 * Minimal NodeRuntime-backed entrypoint used by CLI fixtures and examples.
 *
 * @module @sorrell/docs-cli/FixtureEntrypoint
 *
 * @file      FixtureEntrypoint.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
export {};
//# sourceMappingURL=FixtureEntrypoint.d.ts.map