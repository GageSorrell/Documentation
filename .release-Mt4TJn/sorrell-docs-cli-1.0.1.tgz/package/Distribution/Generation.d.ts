/**
 *
 *
 * @module @sorrell/docs-cli/Generation
 *
 * @file      Generation.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import { DocsManifestError, DocsTargetError, DocsTemplateError } from "./errors.js";
/** @internal */
export type TemplateValue = string | number | boolean;
/** @internal */
export interface GeneratedManifestEntry {
    readonly path: string;
    readonly checksum: string;
}
/** @internal */
export interface GeneratedManifest {
    readonly version: 1;
    readonly generatedAt: string;
    readonly entries: ReadonlyArray<GeneratedManifestEntry>;
}
export declare const renderTemplate: (template: string, values: Readonly<Record<string, TemplateValue>>) => string;
declare const TemplateRenderer_base: Context.ServiceClass<TemplateRenderer, "sorrell/docs-cli/TemplateRenderer", {
    readonly render: (template: string, values: Readonly<Record<string, TemplateValue>>) => Effect.Effect<string, DocsTemplateError>;
    readonly renderFile: (source: string, target: string, values: Readonly<Record<string, TemplateValue>>) => Effect.Effect<void, DocsTemplateError>;
}>;
/** @internal */
export declare class TemplateRenderer extends TemplateRenderer_base {
    static readonly layer: Layer.Layer<TemplateRenderer, never, never>;
}
declare const SafeTargetValidation_base: Context.ServiceClass<SafeTargetValidation, "sorrell/docs-cli/SafeTargetValidation", {
    readonly validateEmpty: (target: string, parent?: string) => Effect.Effect<string, DocsTargetError>;
}>;
/** @internal */
export declare class SafeTargetValidation extends SafeTargetValidation_base {
    static readonly layer: Layer.Layer<SafeTargetValidation, never, never>;
}
declare const AtomicDirectoryPromotion_base: Context.ServiceClass<AtomicDirectoryPromotion, "sorrell/docs-cli/AtomicDirectoryPromotion", {
    readonly promote: (staging: string, target: string) => Effect.Effect<void, DocsTargetError>;
}>;
/** @internal */
export declare class AtomicDirectoryPromotion extends AtomicDirectoryPromotion_base {
    static readonly layer: Layer.Layer<AtomicDirectoryPromotion, never, never>;
}
declare const ManifestTracker_base: Context.ServiceClass<ManifestTracker, "sorrell/docs-cli/ManifestTracker", {
    readonly read: (path: string) => Effect.Effect<GeneratedManifest, DocsManifestError>;
    readonly write: (path: string, manifest: GeneratedManifest) => Effect.Effect<void, DocsManifestError>;
}>;
/** @internal */
export declare class ManifestTracker extends ManifestTracker_base {
    static readonly layer: Layer.Layer<ManifestTracker, never, never>;
}
export {};
//# sourceMappingURL=Generation.d.ts.map