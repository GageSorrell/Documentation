/**
 *
 *
 * @module @sorrell/docs-cli/Framework
 *
 * @file      Framework.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { ManagedRuntime } from "effect";
export /** @internal */ const makePromiseHook = (layer) => {
    const runtime = ManagedRuntime.make(layer);
    return {
        dispose: runtime.dispose,
        run: runtime.runPromise
    };
};
//# sourceMappingURL=Framework.js.map