/**
 *
 *
 * @module @sorrell/docs-cli/Services
 *
 * @file      services.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { ChildProcess, ChildProcessSpawner } from "effect/unstable/process";
import { Context, Effect, FileSystem, Layer, Path, Stream, Terminal } from "effect";
import { DocsAtomicWriteError, DocsFileSystemError, DocsProcessError, DocsTerminalError } from "./errors.js";
import { NodeServices } from "@effect/platform-node";
const fileSystemFailure = (operation, path, cause) => new DocsFileSystemError({ cause, operation, path });
/** @internal */
export class DocsFileSystem extends Context.Service()("sorrell/docs-cli/DocsFileSystem") {
    static layer = Layer.effect(DocsFileSystem, Effect.gen(function* () {
        const fileSystem = yield* FileSystem.FileSystem;
        return DocsFileSystem.of({
            exists: (path) => fileSystem
                .exists(path)
                .pipe(Effect.mapError((cause) => fileSystemFailure("exists", path, cause))),
            isDirectory: (path) => fileSystem.stat(path).pipe(Effect.map((info) => info.type === "Directory"), Effect.mapError((cause) => fileSystemFailure("isDirectory", path, cause))),
            makeDirectory: (path) => fileSystem
                .makeDirectory(path, { recursive: true })
                .pipe(Effect.mapError((cause) => fileSystemFailure("makeDirectory", path, cause))),
            makeTempDirectoryScoped: (options) => fileSystem
                .makeTempDirectoryScoped(options)
                .pipe(Effect.mapError((cause) => fileSystemFailure("makeTempDirectoryScoped" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "" +
                "", options?.directory ?? "", cause))),
            makeTempFileScoped: (options) => fileSystem
                .makeTempFileScoped(options)
                .pipe(Effect.mapError((cause) => fileSystemFailure("makeTempFileScoped", options?.directory ?? "", cause))),
            copy: (from, to, options) => fileSystem
                .copy(from, to, options)
                .pipe(Effect.mapError((cause) => fileSystemFailure("copy", `${from} -> ${to}`, cause))),
            readDirectory: (path) => fileSystem
                .readDirectory(path)
                .pipe(Effect.mapError((cause) => fileSystemFailure("readDirectory", path, cause))),
            readText: (path) => fileSystem
                .readFileString(path)
                .pipe(Effect.mapError((cause) => fileSystemFailure("readText", path, cause))),
            remove: (path, options) => fileSystem
                .remove(path, {
                force: true,
                recursive: options?.recursive === true
            })
                .pipe(Effect.mapError((cause) => fileSystemFailure("remove", path, cause))),
            rename: (from, to) => fileSystem
                .rename(from, to)
                .pipe(Effect.mapError((cause) => fileSystemFailure("rename", `${from} -> ${to}`, cause))),
            writeBytes: (path, content) => fileSystem
                .writeFile(path, content)
                .pipe(Effect.mapError((cause) => fileSystemFailure("writeBytes", path, cause))),
            writeText: (path, content) => fileSystem
                .writeFileString(path, content)
                .pipe(Effect.mapError((cause) => fileSystemFailure("writeText", path, cause)))
        });
    })).pipe(Layer.provide(NodeServices.layer));
}
/** @internal */
export class DocsPath extends Context.Service()("sorrell/docs-cli/DocsPath") {
    static layer = Layer.effect(DocsPath, Effect.gen(function* () {
        const path = yield* Path.Path;
        return DocsPath.of({
            basename: path.basename,
            dirname: path.dirname,
            join: path.join,
            resolve: path.resolve
        });
    })).pipe(Layer.provide(NodeServices.layer));
}
/** @internal */
export class DocsTerminal extends Context.Service()("sorrell/docs-cli/DocsTerminal") {
    static layer = Layer.effect(DocsTerminal, Effect.gen(function* () {
        const terminal = yield* Terminal.Terminal;
        return DocsTerminal.of({
            columns: terminal.columns,
            display: (text) => terminal.display(text).pipe(Effect.mapError((cause) => new DocsTerminalError({
                cause,
                operation: "display"
            }))),
            readLine: terminal.readLine.pipe(Effect.mapError((cause) => new DocsTerminalError({
                cause,
                operation: "readLine"
            }))),
            rows: terminal.rows
        });
    })).pipe(Layer.provide(NodeServices.layer));
}
/** @internal */
export class TempDirectory extends Context.Service()("sorrell/docs-cli/TempDirectory") {
    static layer = Layer.effect(TempDirectory, Effect.gen(function* () {
        const fileSystem = yield* DocsFileSystem;
        return TempDirectory.of({
            makeScoped: fileSystem.makeTempDirectoryScoped
        });
    })).pipe(Layer.provide(DocsFileSystem.layer));
}
/** @internal */
export class AtomicWriter extends Context.Service()("sorrell/docs-cli/AtomicWriter") {
    static layer = Layer.effect(AtomicWriter, Effect.gen(function* () {
        const fileSystem = yield* DocsFileSystem;
        const path = yield* DocsPath;
        return AtomicWriter.of({
            writeText: (target, content) => Effect.scoped(Effect.gen(function* () {
                const temporary = yield* fileSystem.makeTempFileScoped({
                    directory: path.dirname(target),
                    prefix: `.${path.basename(target)}.`,
                    suffix: ".tmp"
                });
                yield* fileSystem.writeText(temporary, content);
                yield* fileSystem.rename(temporary, target);
            })).pipe(Effect.mapError((cause) => new DocsAtomicWriteError({
                cause,
                path: target
            })))
        });
    })).pipe(Layer.provide(Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer)));
}
const processFailure = (command, args, cause, exitCode = undefined, stdout = "", stderr = "") => new DocsProcessError({ args, cause, command, exitCode, stderr, stdout });
/** @internal */
export class CommandRunner extends Context.Service()("sorrell/docs-cli/CommandRunner") {
    static layer = Layer.effect(CommandRunner, Effect.gen(function* () {
        const spawner = yield* ChildProcessSpawner.ChildProcessSpawner;
        const makeCommand = (command, args, options) => ChildProcess.make(command, args, {
            ...options,
            shell: false
        });
        const run = (command, args = [], options) => Effect.scoped(Effect.gen(function* () {
            const handle = yield* spawner
                .spawn(makeCommand(command, args, options))
                .pipe(Effect.mapError((cause) => processFailure(command, args, cause)));
            const result = yield* Effect.all({
                exitCode: handle.exitCode,
                stderr: Stream.mkString(Stream.decodeText(handle.stderr)),
                stdout: Stream.mkString(Stream.decodeText(handle.stdout))
            }, { concurrency: "unbounded" }).pipe(Effect.mapError((cause) => processFailure(command, args, cause)), Effect.ensuring(handle
                .kill({ forceKillAfter: "100 millis" })
                .pipe(Effect.ignore)));
            const exitCode = Number(result.exitCode);
            if (exitCode !== 0) {
                const output = [
                    result.stderr.trim(),
                    result.stdout.trim()
                ]
                    .filter((value) => value !== "")
                    .join("\n");
                return yield* Effect.fail(processFailure(command, args, new Error("Child process " +
                    "exited " +
                    "unsuccessfully" +
                    (output === ""
                        ? ""
                        : `:\n${output}`)), exitCode, result.stdout, result.stderr));
            }
            return {
                args,
                command,
                exitCode,
                stderr: result.stderr,
                stdout: result.stdout
            };
        }));
        const streamLines = (command, args = [], options) => Stream.scoped(Stream.unwrap(spawner
            .spawn(makeCommand(command, args, options))
            .pipe(Effect.map((handle) => {
            const output = handle.all.pipe(Stream.decodeText, Stream.splitLines, Stream.mapError((cause) => processFailure(command, args, cause)));
            const completion = Stream.fromEffect(handle.exitCode).pipe(Stream.mapError((cause) => processFailure(command, args, cause)), Stream.flatMap((exitCode) => Number(exitCode) ===
                0
                ? Stream.empty
                : Stream.fail(processFailure(command, args, new Error("Child process " +
                    "exited " +
                    "unsuccessfully"), Number(exitCode)))));
            return output.pipe(Stream.concat(completion));
        }), Effect.mapError((cause) => processFailure(command, args, cause)))));
        return CommandRunner.of({ run, streamLines });
    })).pipe(Layer.provide(NodeServices.layer));
}
export /** @internal */ const docsCliLayer = Layer.mergeAll(DocsFileSystem.layer, DocsPath.layer, DocsTerminal.layer, TempDirectory.layer, AtomicWriter.layer, CommandRunner.layer);
//# sourceMappingURL=services.js.map