/**
 *
 *
 * @module @sorrell/docs-cli/Checksum
 *
 * @file      Checksum.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import type { DocsFileSystemError } from "./errors.js";
export declare const checksumText: (value: string) => string;
declare const ChecksumService_base: Context.ServiceClass<ChecksumService, "sorrell/docs-cli/ChecksumService", {
    readonly text: (value: string) => Effect.Effect<string>;
    readonly file: (path: string) => Effect.Effect<string, DocsFileSystemError>;
}>;
/** @internal */
export declare class ChecksumService extends ChecksumService_base {
    static readonly layer: Layer.Layer<ChecksumService, never, never>;
}
export {};
//# sourceMappingURL=Checksum.d.ts.map