/**
 * Validated CI and deployment environment configuration.
 *
 * @module @sorrell/docs-cli/Environment
 *
 * @file      Environment.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer, type Redacted } from "effect";
import { DocsEnvironmentError } from "./errors.js";
/** @internal */
export interface VercelEnvironment {
    readonly token: Redacted.Redacted;
    readonly orgId: string;
    readonly projectId: string | undefined;
}
/** @internal */
export interface GitHubEnvironment {
    readonly token: Redacted.Redacted;
    readonly repository: string;
}
/** @internal */
export interface DeploymentEnvironmentSnapshot {
    readonly vercelTokenConfigured: boolean;
    readonly vercelOrgConfigured: boolean;
    readonly githubTokenConfigured: boolean;
    readonly githubRepositoryConfigured: boolean;
}
declare const DeploymentEnvironment_base: Context.ServiceClass<DeploymentEnvironment, "sorrell/docs-cli/DeploymentEnvironment", {
    readonly snapshot: Effect.Effect<DeploymentEnvironmentSnapshot>;
    readonly requireVercel: Effect.Effect<VercelEnvironment, DocsEnvironmentError>;
    readonly requireGitHub: Effect.Effect<GitHubEnvironment, DocsEnvironmentError>;
}>;
/** @internal */
export declare class DeploymentEnvironment extends DeploymentEnvironment_base {
    static readonly layer: Layer.Layer<DeploymentEnvironment, never, never>;
}
export {};
//# sourceMappingURL=Environment.d.ts.map