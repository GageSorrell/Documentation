import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { useNativeTheme } from "./Theme.js";
const styles = StyleSheet.create({
    article: { flex: 1 },
    callout: {
        borderLeftWidth: 3,
        borderRadius: 6,
        marginTop: 16,
        padding: 14
    },
    calloutTitle: { fontSize: 15, fontWeight: "700", marginBottom: 5 },
    code: {
        borderRadius: 8,
        fontFamily: "monospace",
        fontSize: 14,
        lineHeight: 21,
        padding: 14
    },
    codeLanguage: {
        fontSize: 11,
        fontWeight: "700",
        marginBottom: 6,
        textTransform: "uppercase"
    },
    content: { padding: 20, paddingBottom: 48 },
    example: { borderRadius: 10, marginTop: 16, padding: 16 },
    exampleTitle: { fontSize: 14, fontWeight: "700", marginBottom: 10 },
    prose: { fontSize: 16, lineHeight: 25 },
    section: { marginTop: 24 },
    sectionTitle: { fontSize: 22, fontWeight: "700", marginBottom: 10 },
    title: { fontSize: 30, fontWeight: "800", marginBottom: 20 }
});
export /** @internal */ const Article = ({ children, title, scroll = true }) => {
    const { theme } = useNativeTheme();
    const content = (_jsxs(View, { style: [
            styles.content,
            { backgroundColor: theme.colors.background }
        ], children: [title === undefined ? null : (_jsx(Text, { style: [styles.title, { color: theme.colors.foreground }], children: title })), children] }));
    return scroll ? (_jsx(ScrollView, { contentContainerStyle: styles.content, style: styles.article, children: content })) : (_jsx(View, { style: styles.article, children: content }));
};
export /** @internal */ const ArticleSection = ({ children, title }) => {
    const { theme } = useNativeTheme();
    return (_jsxs(View, { style: styles.section, children: [title === undefined ? null : (_jsx(Text, { style: [
                    styles.sectionTitle,
                    { color: theme.colors.foreground }
                ], children: title })), _jsx(View, { children: children })] }));
};
export /** @internal */ const ArticleCode = ({ children, language = "text" }) => {
    const { theme } = useNativeTheme();
    return (_jsxs(View, { style: [
            styles.code,
            { backgroundColor: theme.colors.codeBackground }
        ], children: [_jsx(Text, { style: [styles.codeLanguage, { color: theme.colors.muted }], children: language }), _jsx(Text, { style: { color: theme.colors.foreground }, children: children })] }));
};
export /** @internal */ const ArticleCallout = ({ children, title, tone = "note" }) => {
    const { theme } = useNativeTheme();
    const accent = tone === "warning"
        ? "#d97706"
        : tone === "tip"
            ? "#059669"
            : theme.colors.accent;
    return (_jsxs(View, { style: [
            styles.callout,
            {
                backgroundColor: theme.colors.surface,
                borderLeftColor: accent
            }
        ], children: [title === undefined ? null : (_jsx(Text, { style: [
                    styles.calloutTitle,
                    { color: theme.colors.foreground }
                ], children: title })), _jsx(Text, { style: { color: theme.colors.foreground }, children: children })] }));
};
export /** @internal */ const ArticleExample = ({ children, title }) => {
    const { theme } = useNativeTheme();
    return (_jsxs(View, { style: [
            styles.example,
            {
                backgroundColor: theme.colors.surface,
                borderColor: theme.colors.border,
                borderWidth: 1
            }
        ], children: [title === undefined ? null : (_jsx(Text, { style: [
                    styles.exampleTitle,
                    { color: theme.colors.foreground }
                ], children: title })), children] }));
};
export /** @internal */ const ArticleText = ({ children }) => {
    const { theme } = useNativeTheme();
    return (_jsx(Text, { style: [styles.prose, { color: theme.colors.foreground }], children: children }));
};
//# sourceMappingURL=Articles.js.map