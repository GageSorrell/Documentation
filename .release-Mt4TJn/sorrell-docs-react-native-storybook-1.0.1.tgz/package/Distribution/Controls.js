/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Controls
 *
 * @file      Controls.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
export /** @internal */ const defaultControls = {
    exclude: [],
    expanded: true,
    hideNoControlsWarning: true,
    sort: "requiredFirst"
};
export /** @internal */ const createControlsDefaults = (overrides = {}) => {
    if (overrides.exclude === undefined) {
        return { ...defaultControls, ...overrides };
    }
    return { ...defaultControls, ...overrides, exclude: overrides.exclude };
};
//# sourceMappingURL=Controls.js.map