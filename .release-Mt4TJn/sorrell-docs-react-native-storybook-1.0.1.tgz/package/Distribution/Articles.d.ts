/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Articles
 *
 * @file      Articles.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { ArticleCalloutProps, ArticleCodeProps, ArticleExampleProps, ArticleProps, ArticleSectionProps } from "./Types.js";
import type { ReactNode } from "react";
export declare const Article: ({ children, title, scroll }: ArticleProps) => import("react").JSX.Element;
export declare const ArticleSection: ({ children, title }: ArticleSectionProps) => import("react").JSX.Element;
export declare const ArticleCode: ({ children, language }: ArticleCodeProps) => import("react").JSX.Element;
export declare const ArticleCallout: ({ children, title, tone }: ArticleCalloutProps) => import("react").JSX.Element;
export declare const ArticleExample: ({ children, title }: ArticleExampleProps) => import("react").JSX.Element;
export declare const ArticleText: ({ children }: {
    readonly children: ReactNode;
}) => import("react").JSX.Element;
//# sourceMappingURL=Articles.d.ts.map