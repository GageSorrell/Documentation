/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Metro
 *
 * @file      Metro.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { MetroConfig, MetroStorybookOptions } from "./Types.js";
export declare const createMetroConfig: (config?: MetroConfig, options?: MetroStorybookOptions) => MetroConfig;
export declare const withStorybookMetro: (config: MetroConfig, options?: MetroStorybookOptions) => MetroConfig;
//# sourceMappingURL=Metro.d.ts.map