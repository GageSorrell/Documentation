/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Decorators
 *
 * @file      Decorators.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { NativeStoryRenderer, StoryHeaderProps } from "./Types.js";
import type { ReactNode } from "react";
export declare const StoryHeader: ({ title, subtitle }: StoryHeaderProps) => import("react").JSX.Element;
export declare const StoryHeaderDecorator: (Story: NativeStoryRenderer, title: string, subtitle?: string) => import("react").JSX.Element;
export declare const ThemeDecorator: (Story: NativeStoryRenderer) => import("react").JSX.Element;
export declare const KeyboardDecorator: (Story: NativeStoryRenderer) => import("react").JSX.Element;
export declare const createNativeDecorators: (title?: string) => ((Story: NativeStoryRenderer) => ReactNode)[];
//# sourceMappingURL=Decorators.d.ts.map