import { jsx as _jsx } from "react/jsx-runtime";
/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Theme
 *
 * @file      Theme.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Appearance, useColorScheme } from "react-native";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { readSelection, writeSelection } from "./Persistence.js";
const lightColors = {
    accent: "#6d4aff",
    background: "#ffffff",
    border: "#dddddd",
    codeBackground: "#f0f0f0",
    foreground: "#111111",
    muted: "#666666",
    surface: "#f5f5f5"
};
const darkColors = {
    accent: "#a78bfa",
    background: "#09090b",
    border: "#3f3f46",
    codeBackground: "#18181b",
    foreground: "#fafafa",
    muted: "#a1a1aa",
    surface: "#18181b"
};
export /** @internal */ const resolveNativeThemeMode = (mode, systemMode) => (mode === "system" ? (systemMode ?? "light") : mode);
export /** @internal */ const createNativeTheme = (mode, systemMode) => {
    const resolvedMode = resolveNativeThemeMode(mode, systemMode);
    return {
        colors: resolvedMode === "dark" ? darkColors : lightColors,
        mode,
        resolvedMode
    };
};
const ThemeContext = createContext(undefined);
export /** @internal */ const NativeThemeProvider = ({ children, initialMode = "system", storage, storageKey = "sorrell-storybook-selection" }) => {
    const systemMode = useColorScheme();
    const [mode, setMode] = useState(initialMode);
    useEffect(() => {
        let active = true;
        if (storage !== undefined) {
            void readSelection(storage, storageKey).then((selection) => {
                if (active && selection.themeMode !== undefined) {
                    setMode(selection.themeMode);
                }
            });
        }
        return () => {
            active = false;
        };
    }, [storage, storageKey]);
    useEffect(() => {
        if (storage !== undefined) {
            void writeSelection(storage, storageKey, { themeMode: mode });
        }
    }, [mode, storage, storageKey]);
    useEffect(() => {
        const subscription = Appearance.addChangeListener(() => undefined);
        return () => subscription.remove();
    }, []);
    const theme = useMemo(() => createNativeTheme(mode, systemMode), [mode, systemMode]);
    return (_jsx(ThemeContext.Provider, { value: { setThemeMode: setMode, theme }, children: children }));
};
export /** @internal */ const useNativeTheme = () => useContext(ThemeContext) ?? {
    setThemeMode: () => undefined,
    theme: createNativeTheme("system", "light")
};
//# sourceMappingURL=Theme.js.map