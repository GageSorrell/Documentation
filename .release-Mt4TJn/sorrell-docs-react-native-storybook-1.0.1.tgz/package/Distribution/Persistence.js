/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Persistence
 *
 * @file      Persistence.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
export /** @internal */ const createMemorySelectionStorage = (initial = {}) => {
    const values = new Map(Object.entries(initial));
    return {
        getItem: (key) => values.get(key) ?? null,
        removeItem: (key) => {
            values.delete(key);
        },
        setItem: (key, value) => {
            values.set(key, value);
        }
    };
};
export /** @internal */ const createAsyncStorageSelectionStorage = (storage) => ({
    getItem: storage.getItem,
    setItem: storage.setItem,
    ...(storage.removeItem === undefined
        ? {}
        : { removeItem: storage.removeItem })
});
export /** @internal */ const encodeSelection = (selection) => JSON.stringify(selection);
export /** @internal */ const decodeSelection = (value) => {
    if (value === null) {
        return {};
    }
    try {
        const decoded = JSON.parse(value);
        if (typeof decoded !== "object" ||
            decoded === null ||
            Array.isArray(decoded)) {
            return {};
        }
        const candidate = decoded;
        return {
            ...(typeof candidate.storyId === "string"
                ? { storyId: candidate.storyId }
                : {}),
            ...(candidate.themeMode === "light" ||
                candidate.themeMode === "dark" ||
                candidate.themeMode === "system"
                ? { themeMode: candidate.themeMode }
                : {})
        };
    }
    catch {
        return {};
    }
};
export /** @internal */ const readSelection = async (storage, key) => decodeSelection(await storage.getItem(key));
export /** @internal */ const writeSelection = async (storage, key, selection) => {
    await storage.setItem(key, encodeSelection(selection));
};
//# sourceMappingURL=Persistence.js.map