/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Controls
 *
 * @file      Controls.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { ControlsDefaults } from "./Types.js";
export declare const defaultControls: Required<Pick<ControlsDefaults, "expanded" | "sort" | "hideNoControlsWarning">> & Pick<ControlsDefaults, "exclude">;
export declare const createControlsDefaults: (overrides?: ControlsDefaults) => ControlsDefaults;
//# sourceMappingURL=Controls.d.ts.map