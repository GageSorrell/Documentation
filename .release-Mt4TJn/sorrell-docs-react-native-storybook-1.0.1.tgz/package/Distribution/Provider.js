import { jsx as _jsx, Fragment as _Fragment } from "react/jsx-runtime";
/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Provider
 *
 * @file      Provider.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { NativeThemeProvider, useNativeTheme } from "./Theme.js";
import { readSelection, writeSelection } from "./Persistence.js";
const SelectionContext = createContext(undefined);
const SelectionState = ({ children, initialSelection = {}, storage, storageKey = "sorrell-storybook-selection" }) => {
    const themeContext = useNativeTheme();
    const { setThemeMode } = themeContext;
    const [selection, setSelectionState] = useState(initialSelection);
    useEffect(() => {
        let active = true;
        if (storage !== undefined) {
            void readSelection(storage, storageKey).then((next) => {
                if (active && Object.keys(next).length > 0) {
                    setSelectionState(next);
                }
            });
        }
        return () => {
            active = false;
        };
    }, [storage, storageKey]);
    const setSelection = useCallback((next) => {
        setSelectionState(next);
        if (storage !== undefined) {
            void writeSelection(storage, storageKey, next);
        }
        if (next.themeMode !== undefined) {
            setThemeMode(next.themeMode);
        }
    }, [setThemeMode, storage, storageKey]);
    const value = useMemo(() => ({
        selection,
        setSelection,
        setThemeMode,
        theme: themeContext.theme
    }), [selection, setSelection, setThemeMode, themeContext.theme]);
    return (_jsx(SelectionContext.Provider, { value: value, children: children }));
};
const ProviderBoundary = ({ children, component: Component }) => Component === undefined ? (_jsx(_Fragment, { children: children })) : (_jsx(Component, { style: { flex: 1 }, children: children }));
export /** @internal */ const NativeStorybookProvider = ({ children, initialMode = "system", initialSelection, storage, storageKey, providers }) => (_jsx(ProviderBoundary, { component: providers?.GestureHandlerRootView, children: _jsx(ProviderBoundary, { component: providers?.SafeAreaProvider, children: _jsx(ProviderBoundary, { component: providers?.KeyboardProvider, children: _jsx(NativeThemeProvider, { initialMode: initialMode, ...(storage === undefined ? {} : { storage }), ...(storageKey === undefined ? {} : { storageKey }), children: _jsx(SelectionState, { ...(initialSelection === undefined
                        ? {}
                        : { initialSelection }), ...(storage === undefined ? {} : { storage }), ...(storageKey === undefined ? {} : { storageKey }), children: children }) }) }) }) }));
export /** @internal */ const useNativeStorybook = () => {
    const fallbackTheme = useNativeTheme();
    const context = useContext(SelectionContext);
    return (context ?? {
        selection: {},
        setSelection: () => undefined,
        setThemeMode: fallbackTheme.setThemeMode,
        theme: fallbackTheme.theme
    });
};
//# sourceMappingURL=Provider.js.map