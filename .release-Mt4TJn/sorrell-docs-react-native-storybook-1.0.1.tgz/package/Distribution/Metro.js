/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Metro
 *
 * @file      Metro.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
const appendUnique = (values, additions) => Array.from(new Set([...(values ?? []), ...additions]));
export /** @internal */ const createMetroConfig = (config = {}, options = {}) => {
    const next = {
        ...config,
        resolver: {
            ...(config.resolver ?? {}),
            sourceExts: appendUnique(config.resolver?.sourceExts, ["ts", "tsx"])
        },
        storybook: {
            configPath: options.configPath ?? ".storybook",
            enabled: options.enabled ?? true,
            storybookEntrypoint: options.storybookEntrypoint ?? "storybook.requires"
        },
        transformer: {
            ...(config.transformer ?? {}),
            unstable_allowRequireContext: true
        }
    };
    return options.withStorybook === undefined
        ? next
        : options.withStorybook(next, options);
};
export /** @internal */ const withStorybookMetro = (config, options = {}) => createMetroConfig(config, options);
//# sourceMappingURL=Metro.js.map