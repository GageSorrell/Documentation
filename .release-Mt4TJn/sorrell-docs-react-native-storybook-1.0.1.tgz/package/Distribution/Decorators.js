import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Decorators
 *
 * @file      Decorators.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { KeyboardAvoidingView, Platform, StyleSheet, Text, View } from "react-native";
import { NativeStorybookProvider } from "./Provider.js";
import { useNativeTheme } from "./Theme.js";
const styles = StyleSheet.create({
    decorator: { flex: 1 },
    header: {
        borderBottomWidth: 1,
        paddingHorizontal: 16,
        paddingVertical: 12
    },
    subtitle: { fontSize: 13, marginTop: 3 },
    title: { fontSize: 18, fontWeight: "700" }
});
export /** @internal */ const StoryHeader = ({ title, subtitle }) => {
    const { theme } = useNativeTheme();
    return (_jsxs(View, { style: [
            styles.header,
            {
                backgroundColor: theme.colors.surface,
                borderBottomColor: theme.colors.border
            }
        ], children: [_jsx(Text, { style: [styles.title, { color: theme.colors.foreground }], children: title }), subtitle === undefined ? null : (_jsx(Text, { style: [styles.subtitle, { color: theme.colors.muted }], children: subtitle }))] }));
};
export /** @internal */ const StoryHeaderDecorator = (Story, title, subtitle) => (_jsx(NativeStorybookProvider, { children: _jsxs(View, { style: styles.decorator, children: [_jsx(StoryHeader, { title: title, ...(subtitle === undefined ? {} : { subtitle }) }), _jsx(Story, {})] }) }));
export /** @internal */ const ThemeDecorator = (Story) => (_jsx(NativeStorybookProvider, { children: _jsx(View, { style: [
            styles.decorator,
            {
                backgroundColor: useNativeTheme().theme.colors.background
            }
        ], children: _jsx(Story, {}) }) }));
export /** @internal */ const KeyboardDecorator = (Story) => (_jsx(KeyboardAvoidingView, { behavior: Platform.OS === "ios" ? "padding" : undefined, style: styles.decorator, children: _jsx(Story, {}) }));
export /** @internal */ const createNativeDecorators = (title = "Storybook") => [
    (Story) => StoryHeaderDecorator(Story, title),
    (Story) => ThemeDecorator(Story),
    (Story) => KeyboardDecorator(Story)
];
//# sourceMappingURL=Decorators.js.map