/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Provider
 *
 * @file      Provider.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { NativeStorybookContextValue, NativeStorybookProviderProps } from "./Types.js";
export declare const NativeStorybookProvider: ({ children, initialMode, initialSelection, storage, storageKey, providers }: NativeStorybookProviderProps) => import("react").JSX.Element;
export declare const useNativeStorybook: () => NativeStorybookContextValue;
//# sourceMappingURL=Provider.d.ts.map