/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Persistence
 *
 * @file      Persistence.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { SelectionStorage, StorySelection } from "./Types.js";
export declare const createMemorySelectionStorage: (initial?: Readonly<Record<string, string>>) => SelectionStorage;
export declare const createAsyncStorageSelectionStorage: (storage: {
    readonly getItem: (key: string) => Promise<string | null>;
    readonly setItem: (key: string, value: string) => Promise<void>;
    readonly removeItem?: (key: string) => Promise<void>;
}) => SelectionStorage;
export declare const encodeSelection: (selection: StorySelection) => string;
export declare const decodeSelection: (value: string | null) => StorySelection;
export declare const readSelection: (storage: SelectionStorage, key: string) => Promise<StorySelection>;
export declare const writeSelection: (storage: SelectionStorage, key: string, selection: StorySelection) => Promise<void>;
//# sourceMappingURL=Persistence.d.ts.map