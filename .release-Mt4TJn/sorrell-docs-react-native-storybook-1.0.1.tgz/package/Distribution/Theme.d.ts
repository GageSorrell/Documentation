/**
 *
 *
 * @module @sorrell/docs-react-native-storybook/Theme
 *
 * @file      Theme.tsx
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { NativeTheme, NativeThemeMode, SelectionStorage } from "./Types.js";
import { type ReactNode } from "react";
export declare const resolveNativeThemeMode: (mode: NativeThemeMode, systemMode: "light" | "dark" | null | undefined) => "light" | "dark";
export declare const createNativeTheme: (mode: NativeThemeMode, systemMode: "light" | "dark" | null | undefined) => NativeTheme;
interface ThemeContextValue {
    readonly theme: NativeTheme;
    readonly setThemeMode: (mode: NativeThemeMode) => void;
}
/** @internal */
export interface NativeThemeProviderProps {
    readonly children: ReactNode;
    readonly initialMode?: NativeThemeMode;
    readonly storage?: SelectionStorage;
    readonly storageKey?: string;
}
export declare const NativeThemeProvider: ({ children, initialMode, storage, storageKey }: NativeThemeProviderProps) => import("react").JSX.Element;
export declare const useNativeTheme: () => ThemeContextValue;
export {};
//# sourceMappingURL=Theme.d.ts.map