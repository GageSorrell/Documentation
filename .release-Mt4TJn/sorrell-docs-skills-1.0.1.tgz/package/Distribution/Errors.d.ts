/**
 * Errors raised by the managed skill installer.
 *
 * @module @sorrell/docs-skills/Errors
 *
 * @file      Errors.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
declare const SkillError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "SkillError";
} & Readonly<A>;
/** @internal */
export declare class SkillError extends SkillError_base<{
    readonly operation: string;
    readonly path: string;
    readonly cause?: unknown;
}> {
}
declare const SkillNotFoundError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "SkillNotFoundError";
} & Readonly<A>;
/** @internal */
export declare class SkillNotFoundError extends SkillNotFoundError_base<{
    readonly name: string;
}> {
}
declare const SkillCollisionError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "SkillCollisionError";
} & Readonly<A>;
/** @internal */
export declare class SkillCollisionError extends SkillCollisionError_base<{
    readonly name: string;
    readonly directory: string;
}> {
}
declare const SkillNotManagedError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "SkillNotManagedError";
} & Readonly<A>;
/** @internal */
export declare class SkillNotManagedError extends SkillNotManagedError_base<{
    readonly name: string;
    readonly directory: string;
}> {
}
declare const SkillValidationError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "SkillValidationError";
} & Readonly<A>;
/** @internal */
export declare class SkillValidationError extends SkillValidationError_base<{
    readonly directory: string;
    readonly diagnostics: ReadonlyArray<string>;
}> {
}
export {};
//# sourceMappingURL=Errors.d.ts.map