/**
 * Effect-based managed installer for bundled Sorrell workflow skills.
 *
 * @module @sorrell/docs-skills/Installer
 *
 * @file      Installer.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { ArchiveService, AtomicWriter, ChecksumService, DocsFileSystem, DocsPath, checksumText } from "@sorrell/docs-cli";
import { Context, Effect, Layer } from "effect";
import { SkillCollisionError, SkillError, SkillNotFoundError, SkillNotManagedError, SkillValidationError } from "./Errors.js";
import { SkillCatalog } from "./Catalog.js";
const registryFileName = ".sorrell-skill-registry.json";
const markerFileName = ".sorrell-skill.json";
const managedBy = "@sorrell/docs-skills";
const error = (operation, path, cause) => new SkillError({ cause, operation, path });
const parse = (text, path, operation) => Effect.try({
    catch: (cause) => error(operation, path, cause),
    try: () => JSON.parse(text)
});
const readText = (fileSystem, path, operation) => fileSystem
    .readText(path)
    .pipe(Effect.mapError((cause) => error(operation, path, cause)));
const ensureDirectory = (fileSystem, path) => fileSystem
    .makeDirectory(path)
    .pipe(Effect.mapError((cause) => error("makeDirectory", path, cause)));
const relativeFiles = (fileSystem, path, directory, prefix = "") => Effect.gen(function* () {
    const entries = yield* fileSystem
        .readDirectory(directory)
        .pipe(Effect.mapError((cause) => error("readDirectory", directory, cause)));
    const files = [];
    for (const entry of [...entries].sort()) {
        const fullPath = path.join(directory, entry);
        const relative = prefix === "" ? entry : path.join(prefix, entry);
        const directoryEntry = yield* fileSystem
            .isDirectory(fullPath)
            .pipe(Effect.mapError((cause) => error("isDirectory", fullPath, cause)));
        if (directoryEntry) {
            files.push(...(yield* relativeFiles(fileSystem, path, fullPath, relative)));
        }
        else {
            files.push(relative);
        }
    }
    return files;
});
const contentChecksum = (fileSystem, path, checksum, directory) => Effect.gen(function* () {
    const files = (yield* relativeFiles(fileSystem, path, directory)).filter((file) => file !== ".sorrell-product-skill.json");
    const parts = [];
    for (const file of files) {
        const content = yield* readText(fileSystem, path.join(directory, file), "readSkillFile");
        parts.push(`${file}\0${content}`);
    }
    return yield* checksum.text(parts.join("\0"));
});
const validateDirectory = (fileSystem, path, definition, directory) => Effect.gen(function* () {
    const skillReadMe = path.join(directory, "SKILL.md");
    const metadata = path.join(directory, "agents", "openai.yaml");
    const readMeExists = yield* fileSystem
        .exists(skillReadMe)
        .pipe(Effect.mapError((cause) => error("exists", skillReadMe, cause)));
    if (!readMeExists) {
        return yield* Effect.fail(new SkillValidationError({
            diagnostics: ["SKILL.md is missing"],
            directory
        }));
    }
    const metadataExists = yield* fileSystem
        .exists(metadata)
        .pipe(Effect.mapError((cause) => error("exists", metadata, cause)));
    if (!metadataExists) {
        return yield* Effect.fail(new SkillValidationError({
            diagnostics: ["agents/openai.yaml is missing"],
            directory
        }));
    }
    const content = yield* readText(fileSystem, skillReadMe, "validateSkill");
    const diagnostics = [];
    if (!content.startsWith("---\n") ||
        !content.includes(`name: ${definition.name}`)) {
        diagnostics.push(`SKILL.md frontmatter name must be ${definition.name}`);
    }
    if (/\b(?:TODO|TBD|FIXME)\b|\{\{[^}]+\}\}|<PLACEHOLDER>/i.test(content)) {
        diagnostics.push("SKILL.md contains an unfinished placeholder");
    }
    if (diagnostics.length > 0) {
        return yield* Effect.fail(new SkillValidationError({ diagnostics, directory }));
    }
    const productMetadata = path.join(directory, ".sorrell-product-skill.json");
    if (yield* fileSystem
        .exists(productMetadata)
        .pipe(Effect.mapError((cause) => error("exists", productMetadata, cause)))) {
        const metadataValue = yield* readText(fileSystem, productMetadata, "readProductSkillMetadata").pipe(Effect.flatMap((text) => parse(text, productMetadata, "parseProductSkillMetadata")));
        if (metadataValue.name !== definition.name) {
            return yield* Effect.fail(new SkillValidationError({
                diagnostics: [
                    `product skill name must be ${definition.name}`
                ],
                directory
            }));
        }
        const actual = yield* contentChecksum(fileSystem, path, {
            text: (value) => Effect.succeed(checksumText(value))
        }, directory);
        if (metadataValue.checksum !== undefined &&
            metadataValue.checksum !== actual) {
            return yield* Effect.fail(new SkillValidationError({
                diagnostics: [
                    "product skill checksum does not match its manifest"
                ],
                directory
            }));
        }
    }
});
/** @internal */
export class SkillInstaller extends Context.Service()("sorrell/docs-skills/SkillInstaller") {
    static layer = Layer.effect(SkillInstaller, Effect.gen(function* () {
        const catalog = yield* SkillCatalog;
        const fileSystem = yield* DocsFileSystem;
        const path = yield* DocsPath;
        const atomicWriter = yield* AtomicWriter;
        const checksum = yield* ChecksumService;
        const archive = yield* ArchiveService;
        const defaultHome = process.env.USERPROFILE ??
            process.env.HOME ??
            process.cwd();
        const resolveRoot = (options) => {
            const agent = options?.agent ?? "codex";
            const scope = options?.scope ?? "project";
            if (scope === "project") {
                return path.join(path.resolve(options?.projectDirectory ?? "."), agent === "codex" ? ".codex" : ".claude", "skills");
            }
            const home = options?.homeDirectory ?? defaultHome;
            const base = agent === "codex"
                ? (options?.codexHome ??
                    process.env.CODEX_HOME ??
                    home)
                : path.join(home, ".claude");
            return path.join(base, "skills");
        };
        const normalized = (options) => ({
            agent: options?.agent ?? "codex",
            scope: options?.scope ?? "project"
        });
        const readRegistry = (root) => Effect.gen(function* () {
            const file = path.join(root, registryFileName);
            const exists = yield* fileSystem
                .exists(file)
                .pipe(Effect.mapError((cause) => error("exists", file, cause)));
            if (!exists) {
                return { installations: [], version: 1 };
            }
            return yield* readText(fileSystem, file, "readRegistry").pipe(Effect.flatMap((text) => parse(text, file, "parseRegistry")));
        });
        const writeRegistry = (root, registry) => ensureDirectory(fileSystem, root).pipe(Effect.flatMap(() => atomicWriter
            .writeText(path.join(root, registryFileName), `${JSON.stringify(registry, null, 2)}\n`)
            .pipe(Effect.mapError((cause) => error("writeRegistry", path.join(root, registryFileName), cause)))));
        const marker = (directory) => {
            const file = path.join(directory, markerFileName);
            return fileSystem.exists(file).pipe(Effect.mapError((cause) => error("exists", file, cause)), Effect.flatMap((exists) => exists
                ? readText(fileSystem, file, "readMarker").pipe(Effect.flatMap((text) => parse(text, file, "parseMarker")))
                : Effect.succeed(undefined)));
        };
        const managed = (directory, name) => marker(directory).pipe(Effect.flatMap((value) => value?.managedBy === managedBy &&
            value.name === name
            ? Effect.succeed(value)
            : Effect.fail(new SkillNotManagedError({
                directory,
                name
            }))));
        const writeFiles = (source, target) => Effect.gen(function* () {
            const files = yield* relativeFiles(fileSystem, path, source);
            for (const file of files) {
                const sourceFile = path.join(source, file);
                const targetFile = path.join(target, file);
                yield* ensureDirectory(fileSystem, path.dirname(targetFile));
                const content = yield* readText(fileSystem, sourceFile, "readSkillFile");
                yield* fileSystem
                    .writeText(targetFile, content)
                    .pipe(Effect.mapError((cause) => error("writeSkillFile", targetFile, cause)));
            }
        });
        const installDirectory = (definition, source, options) => Effect.gen(function* () {
            yield* validateDirectory(fileSystem, path, definition, source);
            const root = resolveRoot(options);
            const target = path.join(root, definition.name);
            const targetExists = yield* fileSystem
                .exists(target)
                .pipe(Effect.mapError((cause) => error("exists", target, cause)));
            if (targetExists) {
                yield* managed(target, definition.name).pipe(Effect.mapError((cause) => cause instanceof SkillNotManagedError
                    ? new SkillCollisionError({
                        directory: target,
                        name: definition.name
                    })
                    : cause));
                yield* fileSystem
                    .remove(target, { recursive: true })
                    .pipe(Effect.mapError((cause) => error("removeManagedSkill", target, cause)));
            }
            yield* ensureDirectory(fileSystem, root);
            yield* writeFiles(source, target);
            const installedAt = new Date().toISOString();
            const value = yield* contentChecksum(fileSystem, path, checksum, source);
            const installMarker = {
                checksum: value,
                installedAt,
                managedBy,
                name: definition.name,
                version: 1
            };
            yield* atomicWriter
                .writeText(path.join(target, markerFileName), `${JSON.stringify(installMarker, null, 2)}\n`)
                .pipe(Effect.mapError((cause) => error("writeMarker", target, cause)));
            const registry = yield* readRegistry(root);
            const installations = [
                ...registry.installations.filter((entry) => entry.name !== definition.name),
                {
                    checksum: value,
                    installedAt,
                    name: definition.name
                }
            ];
            yield* writeRegistry(root, {
                installations: installations.sort((left, right) => left.name.localeCompare(right.name)),
                version: 1
            });
            const selection = normalized(options);
            return {
                ...definition,
                agent: selection.agent,
                checksum: value,
                directory: target,
                installedAt,
                scope: selection.scope
            };
        });
        const install = (name, options) => Effect.gen(function* () {
            const definition = catalog.find(name);
            if (definition === undefined) {
                return yield* Effect.fail(new SkillNotFoundError({ name }));
            }
            return yield* installDirectory(definition, path.join(catalog.root, definition.directory), options);
        });
        const installFrom = (source, options) => Effect.scoped(Effect.gen(function* () {
            const external = /^https?:\/\//u.test(source);
            const temporaryDirectory = external
                ? yield* fileSystem
                    .makeTempDirectoryScoped({
                    prefix: "sorrell-product-skill-"
                })
                    .pipe(Effect.mapError((cause) => error("makeTempDirectory", source, cause)))
                : source;
            let directory = source;
            if (external) {
                const response = yield* Effect.tryPromise({
                    catch: (cause) => error("downloadSkill", source, cause),
                    try: async () => {
                        const value = await fetch(source);
                        if (!value.ok) {
                            throw new Error(`skill archive request failed with ${value.status}`);
                        }
                        return new Uint8Array(await value.arrayBuffer());
                    }
                });
                const archivePath = yield* fileSystem
                    .makeTempFileScoped({
                    prefix: "sorrell-product-skill-",
                    suffix: ".zip"
                })
                    .pipe(Effect.mapError((cause) => error("makeTempFile", source, cause)));
                yield* fileSystem
                    .writeBytes(archivePath, response)
                    .pipe(Effect.mapError((cause) => error("writeSkillArchive", archivePath, cause)));
                yield* archive
                    .extractZip(archivePath, temporaryDirectory)
                    .pipe(Effect.mapError((cause) => error("extractSkillArchive", archivePath, cause)));
                directory = temporaryDirectory;
            }
            const content = yield* readText(fileSystem, path.join(directory, "SKILL.md"), "readProductSkill");
            const name = content
                .match(/^name:\s*([^\r\n]+)$/mu)?.[1]
                ?.trim();
            const description = content
                .match(/^description:\s*([^\r\n]+)$/mu)?.[1]
                ?.trim() ??
                "Generated product documentation skill.";
            if (name === undefined ||
                !/^[a-z0-9]+(?:-[a-z0-9]+)*$/u.test(name)) {
                return yield* Effect.fail(new SkillValidationError({
                    diagnostics: [
                        "product skill name must be kebab-case"
                    ],
                    directory
                }));
            }
            const definition = {
                description,
                directory,
                name
            };
            return yield* installDirectory(definition, directory, options);
        }));
        const listInstalled = (options) => Effect.gen(function* () {
            const root = resolveRoot(options);
            const rootExists = yield* fileSystem
                .exists(root)
                .pipe(Effect.mapError((cause) => error("exists", root, cause)));
            if (!rootExists) {
                return [];
            }
            const entries = yield* fileSystem
                .readDirectory(root)
                .pipe(Effect.mapError((cause) => error("readInstalled", root, cause)));
            const selection = normalized(options);
            const result = [];
            for (const entry of [...entries].sort()) {
                const definition = catalog.find(entry);
                if (definition === undefined) {
                    continue;
                }
                const directory = path.join(root, entry);
                const value = yield* marker(directory);
                if (value?.managedBy === managedBy &&
                    value.name === entry) {
                    result.push({
                        ...definition,
                        agent: selection.agent,
                        checksum: value.checksum,
                        directory,
                        installedAt: value.installedAt,
                        scope: selection.scope
                    });
                }
            }
            return result;
        });
        const update = (name, options) => Effect.gen(function* () {
            const root = resolveRoot(options);
            yield* managed(path.join(root, name), name);
            return yield* install(name, options);
        });
        const uninstall = (name, options) => Effect.gen(function* () {
            const root = resolveRoot(options);
            const target = path.join(root, name);
            yield* managed(target, name);
            yield* fileSystem
                .remove(target, { recursive: true })
                .pipe(Effect.mapError((cause) => error("uninstall", target, cause)));
            const registry = yield* readRegistry(root);
            yield* writeRegistry(root, {
                installations: registry.installations.filter((entry) => entry.name !== name),
                version: 1
            });
        });
        return SkillInstaller.of({
            install,
            installFrom,
            listAvailable: catalog.list,
            listInstalled,
            uninstall,
            update
        });
    })).pipe(Layer.provide(Layer.mergeAll(SkillCatalog.layer, DocsFileSystem.layer, DocsPath.layer, AtomicWriter.layer, ChecksumService.layer, ArchiveService.layer)));
}
export /** @internal */ const skillsLayer = SkillInstaller.layer;
//# sourceMappingURL=Installer.js.map