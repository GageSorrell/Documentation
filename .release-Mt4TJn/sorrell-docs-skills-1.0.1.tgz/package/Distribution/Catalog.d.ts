/**
 * Catalog of the six workflow skills shipped by Sorrell Documentation.
 *
 * @module @sorrell/docs-skills/Catalog
 *
 * @file      Catalog.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import type { SkillDefinition } from "./Types.js";
export declare const skillDefinitions: ReadonlyArray<SkillDefinition>;
declare const SkillCatalog_base: Context.ServiceClass<SkillCatalog, "sorrell/docs-skills/SkillCatalog", {
    readonly root: string;
    readonly list: () => ReadonlyArray<SkillDefinition>;
    readonly find: (name: string) => SkillDefinition | undefined;
}>;
/** @internal */
export declare class SkillCatalog extends SkillCatalog_base {
    static readonly layer: Layer.Layer<SkillCatalog, never, never>;
}
export declare const availableSkills: Effect.Effect<readonly SkillDefinition[], never, never>;
export {};
//# sourceMappingURL=Catalog.d.ts.map