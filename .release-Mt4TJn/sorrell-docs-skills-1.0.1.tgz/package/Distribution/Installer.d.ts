/**
 * Effect-based managed installer for bundled Sorrell workflow skills.
 *
 * @module @sorrell/docs-skills/Installer
 *
 * @file      Installer.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Context, Effect, Layer } from "effect";
import type { InstalledSkill, SkillDefinition, SkillInstallOptions } from "./Types.js";
import { SkillCollisionError, SkillError, SkillNotFoundError, SkillNotManagedError, SkillValidationError } from "./Errors.js";
declare const SkillInstaller_base: Context.ServiceClass<SkillInstaller, "sorrell/docs-skills/SkillInstaller", {
    readonly listAvailable: () => ReadonlyArray<SkillDefinition>;
    readonly listInstalled: (options?: SkillInstallOptions) => Effect.Effect<ReadonlyArray<InstalledSkill>, SkillError>;
    readonly install: (name: string, options?: SkillInstallOptions) => Effect.Effect<InstalledSkill, SkillError | SkillNotFoundError | SkillCollisionError | SkillValidationError>;
    readonly installFrom: (source: string, options?: SkillInstallOptions) => Effect.Effect<InstalledSkill, SkillError | SkillCollisionError | SkillValidationError>;
    readonly update: (name: string, options?: SkillInstallOptions) => Effect.Effect<InstalledSkill, SkillError | SkillNotFoundError | SkillNotManagedError | SkillCollisionError | SkillValidationError>;
    readonly uninstall: (name: string, options?: SkillInstallOptions) => Effect.Effect<void, SkillError | SkillNotManagedError>;
}>;
/** @internal */
export declare class SkillInstaller extends SkillInstaller_base {
    static readonly layer: Layer.Layer<SkillInstaller, never, never>;
}
export declare const skillsLayer: Layer.Layer<SkillInstaller, never, never>;
export {};
//# sourceMappingURL=Installer.d.ts.map