/**
 * Errors raised by the managed skill installer.
 *
 * @module @sorrell/docs-skills/Errors
 *
 * @file      Errors.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Data } from "effect";
/** @internal */
export class SkillError extends Data.TaggedError("SkillError") {
}
/** @internal */
export class SkillNotFoundError extends Data.TaggedError("SkillNotFoundError") {
}
/** @internal */
export class SkillCollisionError extends Data.TaggedError("SkillCollisionError") {
}
/** @internal */
export class SkillNotManagedError extends Data.TaggedError("SkillNotManagedError") {
}
/** @internal */
export class SkillValidationError extends Data.TaggedError("SkillValidationError") {
}
//# sourceMappingURL=Errors.js.map