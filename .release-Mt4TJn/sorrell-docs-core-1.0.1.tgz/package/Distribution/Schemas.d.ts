/**
 *
 *
 * @module @sorrell/docs-core/Schemas
 *
 * @file      Schemas.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Schema } from "effect";
export declare const RepositorySchema: Schema.Struct<{
    readonly branch: Schema.optionalKey<Schema.String>;
    readonly directory: Schema.optionalKey<Schema.String>;
    readonly url: Schema.String;
}>;
export declare const SiteMetadataSchema: Schema.Struct<{
    readonly description: Schema.String;
    readonly logo: Schema.optionalKey<Schema.String>;
    readonly name: Schema.String;
    readonly repository: Schema.optionalKey<Schema.Struct<{
        readonly branch: Schema.optionalKey<Schema.String>;
        readonly directory: Schema.optionalKey<Schema.String>;
        readonly url: Schema.String;
    }>>;
    readonly title: Schema.String;
    readonly url: Schema.String;
}>;
export declare const ColorTokensSchema: Schema.Struct<{
    readonly accent: Schema.String;
    readonly background: Schema.String;
    readonly border: Schema.String;
    readonly codeBackground: Schema.String;
    readonly foreground: Schema.String;
    readonly muted: Schema.String;
}>;
export declare const DesignTokensSchema: Schema.Struct<{
    readonly dark: Schema.Struct<{
        readonly accent: Schema.String;
        readonly background: Schema.String;
        readonly border: Schema.String;
        readonly codeBackground: Schema.String;
        readonly foreground: Schema.String;
        readonly muted: Schema.String;
    }>;
    readonly light: Schema.Struct<{
        readonly accent: Schema.String;
        readonly background: Schema.String;
        readonly border: Schema.String;
        readonly codeBackground: Schema.String;
        readonly foreground: Schema.String;
        readonly muted: Schema.String;
    }>;
}>;
/** @internal */
export interface NavigationItem {
    readonly id: string;
    readonly label: string;
    readonly href: string;
    readonly kind: "page" | "section" | "external";
    readonly children?: ReadonlyArray<NavigationItem>;
}
/** @internal */
export interface NavigationGroup {
    readonly id: string;
    readonly label: string;
    readonly items: ReadonlyArray<NavigationItem>;
}
/** @internal */
export interface Navigation {
    readonly groups: ReadonlyArray<NavigationGroup>;
}
/** @internal */
export interface NavigationItemInput {
    readonly id: string;
    readonly label: string;
    readonly href: string;
    readonly kind?: "page" | "section" | "external";
    readonly children?: ReadonlyArray<NavigationItemInput>;
}
export declare const NavigationItemSchema: Schema.Schema<NavigationItem>;
export declare const NavigationGroupSchema: Schema.Struct<{
    readonly id: Schema.String;
    readonly items: Schema.$Array<Schema.Schema<NavigationItem>>;
    readonly label: Schema.String;
}>;
export declare const NavigationSchema: Schema.Schema<Navigation>;
export declare const DocumentationVersionSchema: Schema.Struct<{
    readonly current: Schema.Boolean;
    readonly directory: Schema.String;
    readonly href: Schema.optionalKey<Schema.String>;
    readonly id: Schema.String;
    readonly label: Schema.String;
    readonly order: Schema.Number;
    readonly version: Schema.optionalKey<Schema.String>;
}>;
export declare const PackageReferenceSchema: Schema.Struct<{
    readonly description: Schema.optionalKey<Schema.String>;
    readonly directory: Schema.optionalKey<Schema.String>;
    readonly id: Schema.String;
    readonly name: Schema.String;
    readonly source: Schema.optionalKey<Schema.Struct<{
        readonly branch: Schema.optionalKey<Schema.String>;
        readonly directory: Schema.optionalKey<Schema.String>;
        readonly url: Schema.String;
    }>>;
    readonly version: Schema.optionalKey<Schema.String>;
}>;
export declare const LandingSectionSchema: Schema.Struct<{
    readonly body: Schema.String;
    readonly href: Schema.optionalKey<Schema.String>;
    readonly id: Schema.String;
    readonly title: Schema.String;
}>;
export declare const LandingContentSchema: Schema.Struct<{
    readonly description: Schema.String;
    readonly primaryAction: Schema.optionalKey<Schema.Struct<{
        readonly href: Schema.String;
        readonly label: Schema.String;
    }>>;
    readonly sections: Schema.$Array<Schema.Struct<{
        readonly body: Schema.String;
        readonly href: Schema.optionalKey<Schema.String>;
        readonly id: Schema.String;
        readonly title: Schema.String;
    }>>;
    readonly title: Schema.String;
}>;
export declare const RedirectSchema: Schema.Struct<{
    readonly from: Schema.String;
    readonly status: Schema.Literals<readonly [301, 302]>;
    readonly to: Schema.String;
}>;
export declare const StorybookConfigSchema: Schema.Struct<{
    readonly command: Schema.optionalKey<Schema.String>;
    readonly directory: Schema.optionalKey<Schema.String>;
    readonly enabled: Schema.Boolean;
    readonly stories: Schema.$Array<Schema.String>;
    readonly url: Schema.optionalKey<Schema.String>;
}>;
export declare const ApiGenerationConfigSchema: Schema.Struct<{
    readonly enabled: Schema.Boolean;
    readonly entryPoints: Schema.$Array<Schema.String>;
    readonly outputDirectory: Schema.String;
    readonly packages: Schema.$Array<Schema.String>;
    readonly sourceRepository: Schema.optionalKey<Schema.Struct<{
        readonly branch: Schema.optionalKey<Schema.String>;
        readonly directory: Schema.optionalKey<Schema.String>;
        readonly url: Schema.String;
    }>>;
    readonly typedoc: Schema.$Record<Schema.String, Schema.Unknown>;
}>;
export declare const SiteRoutingSchema: Schema.Struct<{
    readonly documentationPrefix: Schema.String;
    readonly storybookPrefix: Schema.String;
}>;
export declare const VercelProjectSchema: Schema.Struct<{
    readonly directory: Schema.String;
    readonly id: Schema.optionalKey<Schema.String>;
    readonly origin: Schema.optionalKey<Schema.String>;
    readonly productionBranch: Schema.optionalKey<Schema.String>;
    readonly project: Schema.optionalKey<Schema.String>;
    readonly routePrefix: Schema.String;
    readonly team: Schema.optionalKey<Schema.String>;
}>;
export declare const VercelProjectsSchema: Schema.Struct<{
    readonly documentation: Schema.Struct<{
        readonly directory: Schema.String;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly origin: Schema.optionalKey<Schema.String>;
        readonly productionBranch: Schema.optionalKey<Schema.String>;
        readonly project: Schema.optionalKey<Schema.String>;
        readonly routePrefix: Schema.String;
        readonly team: Schema.optionalKey<Schema.String>;
    }>;
    readonly landing: Schema.Struct<{
        readonly directory: Schema.String;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly origin: Schema.optionalKey<Schema.String>;
        readonly productionBranch: Schema.optionalKey<Schema.String>;
        readonly project: Schema.optionalKey<Schema.String>;
        readonly routePrefix: Schema.String;
        readonly team: Schema.optionalKey<Schema.String>;
    }>;
    readonly mcp: Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.String;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly origin: Schema.optionalKey<Schema.String>;
        readonly productionBranch: Schema.optionalKey<Schema.String>;
        readonly project: Schema.optionalKey<Schema.String>;
        readonly routePrefix: Schema.String;
        readonly team: Schema.optionalKey<Schema.String>;
    }>>;
    readonly storybook: Schema.optionalKey<Schema.Struct<{
        readonly directory: Schema.String;
        readonly id: Schema.optionalKey<Schema.String>;
        readonly origin: Schema.optionalKey<Schema.String>;
        readonly productionBranch: Schema.optionalKey<Schema.String>;
        readonly project: Schema.optionalKey<Schema.String>;
        readonly routePrefix: Schema.String;
        readonly team: Schema.optionalKey<Schema.String>;
    }>>;
}>;
export declare const VercelDeploymentSchema: Schema.Struct<{
    readonly deploymentId: Schema.String;
    readonly project: Schema.String;
    readonly revision: Schema.optionalKey<Schema.String>;
    readonly url: Schema.String;
}>;
export declare const VercelDeploymentsSchema: Schema.Struct<{
    readonly documentation: Schema.Struct<{
        readonly deploymentId: Schema.String;
        readonly project: Schema.String;
        readonly revision: Schema.optionalKey<Schema.String>;
        readonly url: Schema.String;
    }>;
    readonly landing: Schema.Struct<{
        readonly deploymentId: Schema.String;
        readonly project: Schema.String;
        readonly revision: Schema.optionalKey<Schema.String>;
        readonly url: Schema.String;
    }>;
    readonly mcp: Schema.optionalKey<Schema.Struct<{
        readonly deploymentId: Schema.String;
        readonly project: Schema.String;
        readonly revision: Schema.optionalKey<Schema.String>;
        readonly url: Schema.String;
    }>>;
    readonly storybook: Schema.optionalKey<Schema.Struct<{
        readonly deploymentId: Schema.String;
        readonly project: Schema.String;
        readonly revision: Schema.optionalKey<Schema.String>;
        readonly url: Schema.String;
    }>>;
}>;
export declare const AgentSearchIndexEntrySchema: Schema.Struct<{
    readonly id: Schema.String;
    readonly terms: Schema.$Array<Schema.String>;
    readonly version: Schema.optionalKey<Schema.String>;
}>;
export declare const AgentSearchIndexSchema: Schema.Struct<{
    readonly checksum: Schema.String;
    readonly entries: Schema.$Array<Schema.Struct<{
        readonly id: Schema.String;
        readonly terms: Schema.$Array<Schema.String>;
        readonly version: Schema.optionalKey<Schema.String>;
    }>>;
    readonly version: Schema.Literals<readonly [1]>;
}>;
export declare const VercelReleaseManifestSchema: Schema.Struct<{
    readonly apiSnapshot: Schema.optionalKey<Schema.String>;
    readonly deployments: Schema.Struct<{
        readonly documentation: Schema.Struct<{
            readonly deploymentId: Schema.String;
            readonly project: Schema.String;
            readonly revision: Schema.optionalKey<Schema.String>;
            readonly url: Schema.String;
        }>;
        readonly landing: Schema.Struct<{
            readonly deploymentId: Schema.String;
            readonly project: Schema.String;
            readonly revision: Schema.optionalKey<Schema.String>;
            readonly url: Schema.String;
        }>;
        readonly mcp: Schema.optionalKey<Schema.Struct<{
            readonly deploymentId: Schema.String;
            readonly project: Schema.String;
            readonly revision: Schema.optionalKey<Schema.String>;
            readonly url: Schema.String;
        }>>;
        readonly storybook: Schema.optionalKey<Schema.Struct<{
            readonly deploymentId: Schema.String;
            readonly project: Schema.String;
            readonly revision: Schema.optionalKey<Schema.String>;
            readonly url: Schema.String;
        }>>;
    }>;
    readonly generatedAt: Schema.String;
    readonly landingConfig: Schema.Unknown;
    readonly mcpEndpoint: Schema.optionalKey<Schema.String>;
    readonly mode: Schema.Literals<readonly ["preview", "production"]>;
    readonly previousReleaseId: Schema.optionalKey<Schema.String>;
    readonly publicUrl: Schema.String;
    readonly releaseId: Schema.String;
    readonly revision: Schema.String;
    readonly routes: Schema.Struct<{
        readonly documentationPrefix: Schema.String;
        readonly storybookPrefix: Schema.String;
    }>;
    readonly version: Schema.Literals<readonly [2]>;
}>;
export declare const VercelConfigSchema: Schema.Struct<{
    readonly domains: Schema.$Array<Schema.String>;
    readonly enabled: Schema.Boolean;
    readonly outputDirectory: Schema.String;
    readonly productionBranch: Schema.String;
    readonly project: Schema.optionalKey<Schema.String>;
    readonly projects: Schema.Struct<{
        readonly documentation: Schema.Struct<{
            readonly directory: Schema.String;
            readonly id: Schema.optionalKey<Schema.String>;
            readonly origin: Schema.optionalKey<Schema.String>;
            readonly productionBranch: Schema.optionalKey<Schema.String>;
            readonly project: Schema.optionalKey<Schema.String>;
            readonly routePrefix: Schema.String;
            readonly team: Schema.optionalKey<Schema.String>;
        }>;
        readonly landing: Schema.Struct<{
            readonly directory: Schema.String;
            readonly id: Schema.optionalKey<Schema.String>;
            readonly origin: Schema.optionalKey<Schema.String>;
            readonly productionBranch: Schema.optionalKey<Schema.String>;
            readonly project: Schema.optionalKey<Schema.String>;
            readonly routePrefix: Schema.String;
            readonly team: Schema.optionalKey<Schema.String>;
        }>;
        readonly mcp: Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.String;
            readonly id: Schema.optionalKey<Schema.String>;
            readonly origin: Schema.optionalKey<Schema.String>;
            readonly productionBranch: Schema.optionalKey<Schema.String>;
            readonly project: Schema.optionalKey<Schema.String>;
            readonly routePrefix: Schema.String;
            readonly team: Schema.optionalKey<Schema.String>;
        }>>;
        readonly storybook: Schema.optionalKey<Schema.Struct<{
            readonly directory: Schema.String;
            readonly id: Schema.optionalKey<Schema.String>;
            readonly origin: Schema.optionalKey<Schema.String>;
            readonly productionBranch: Schema.optionalKey<Schema.String>;
            readonly project: Schema.optionalKey<Schema.String>;
            readonly routePrefix: Schema.String;
            readonly team: Schema.optionalKey<Schema.String>;
        }>>;
    }>;
    readonly team: Schema.optionalKey<Schema.String>;
}>;
export declare const GeneratedManifestSchema: Schema.Struct<{
    readonly checksum: Schema.optionalKey<Schema.String>;
    readonly generatedAt: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literals<readonly ["site", "api-reference", "storybook", "project"]>;
    readonly path: Schema.String;
    readonly revision: Schema.optionalKey<Schema.String>;
}>;
export declare const ApiReferenceBreadcrumbSchema: Schema.Struct<{
    readonly current: Schema.Boolean;
    readonly href: Schema.optionalKey<Schema.String>;
    readonly label: Schema.String;
}>;
export declare const ApiReferenceCategorySchema: Schema.Struct<{
    readonly collapsed: Schema.Boolean;
    readonly id: Schema.String;
    readonly label: Schema.String;
    readonly order: Schema.Number;
}>;
export declare const ApiReferenceSourceSchema: Schema.Struct<{
    readonly endLine: Schema.optionalKey<Schema.Number>;
    readonly file: Schema.String;
    readonly line: Schema.optionalKey<Schema.Number>;
    readonly repositoryUrl: Schema.String;
    readonly revision: Schema.String;
}>;
export declare const StableLinkSchema: Schema.Struct<{
    readonly external: Schema.Boolean;
    readonly href: Schema.String;
    readonly label: Schema.optionalKey<Schema.String>;
}>;
export declare const ApiReferenceDeclarationSchema: Schema.Struct<{
    readonly categoryId: Schema.String;
    readonly description: Schema.String;
    readonly id: Schema.String;
    readonly introductionVersion: Schema.optionalKey<Schema.String>;
    readonly kind: Schema.Literals<readonly ["function", "const", "class", "interface", "type", "variable", "namespace"]>;
    readonly link: Schema.optionalKey<Schema.Struct<{
        readonly external: Schema.Boolean;
        readonly href: Schema.String;
        readonly label: Schema.optionalKey<Schema.String>;
    }>>;
    readonly name: Schema.String;
    readonly signature: Schema.String;
    readonly source: Schema.optionalKey<Schema.Struct<{
        readonly endLine: Schema.optionalKey<Schema.Number>;
        readonly file: Schema.String;
        readonly line: Schema.optionalKey<Schema.Number>;
        readonly repositoryUrl: Schema.String;
        readonly revision: Schema.String;
    }>>;
}>;
export declare const ApiReferenceRecordSchema: Schema.Struct<{
    readonly breadcrumbs: Schema.$Array<Schema.Struct<{
        readonly current: Schema.Boolean;
        readonly href: Schema.optionalKey<Schema.String>;
        readonly label: Schema.String;
    }>>;
    readonly categories: Schema.$Array<Schema.Struct<{
        readonly collapsed: Schema.Boolean;
        readonly id: Schema.String;
        readonly label: Schema.String;
        readonly order: Schema.Number;
    }>>;
    readonly declarations: Schema.$Array<Schema.Struct<{
        readonly categoryId: Schema.String;
        readonly description: Schema.String;
        readonly id: Schema.String;
        readonly introductionVersion: Schema.optionalKey<Schema.String>;
        readonly kind: Schema.Literals<readonly ["function", "const", "class", "interface", "type", "variable", "namespace"]>;
        readonly link: Schema.optionalKey<Schema.Struct<{
            readonly external: Schema.Boolean;
            readonly href: Schema.String;
            readonly label: Schema.optionalKey<Schema.String>;
        }>>;
        readonly name: Schema.String;
        readonly signature: Schema.String;
        readonly source: Schema.optionalKey<Schema.Struct<{
            readonly endLine: Schema.optionalKey<Schema.Number>;
            readonly file: Schema.String;
            readonly line: Schema.optionalKey<Schema.Number>;
            readonly repositoryUrl: Schema.String;
            readonly revision: Schema.String;
        }>>;
    }>>;
    readonly displayName: Schema.String;
    readonly exportCount: Schema.Number;
    readonly introductionVersion: Schema.optionalKey<Schema.String>;
    readonly link: Schema.optionalKey<Schema.Struct<{
        readonly external: Schema.Boolean;
        readonly href: Schema.String;
        readonly label: Schema.optionalKey<Schema.String>;
    }>>;
    readonly module: Schema.String;
    readonly packageId: Schema.String;
    readonly packageName: Schema.String;
    readonly source: Schema.optionalKey<Schema.Struct<{
        readonly endLine: Schema.optionalKey<Schema.Number>;
        readonly file: Schema.String;
        readonly line: Schema.optionalKey<Schema.Number>;
        readonly repositoryUrl: Schema.String;
        readonly revision: Schema.String;
    }>>;
    readonly summary: Schema.String;
    readonly version: Schema.String;
}>;
export declare const AgentDocumentSchema: Schema.Struct<{
    readonly content: Schema.String;
    readonly context: Schema.optionalKey<Schema.String>;
    readonly description: Schema.optionalKey<Schema.String>;
    readonly id: Schema.String;
    readonly kind: Schema.Literals<readonly ["article", "api-module", "component"]>;
    readonly metadata: Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>;
    readonly source: Schema.optionalKey<Schema.Struct<{
        readonly endLine: Schema.optionalKey<Schema.Number>;
        readonly file: Schema.String;
        readonly line: Schema.optionalKey<Schema.Number>;
        readonly repositoryUrl: Schema.String;
        readonly revision: Schema.String;
    }>>;
    readonly title: Schema.String;
    readonly url: Schema.String;
    readonly version: Schema.optionalKey<Schema.String>;
}>;
export declare const AgentManifestEntrySchema: Schema.Struct<{
    readonly checksum: Schema.String;
    readonly id: Schema.String;
    readonly kind: Schema.Literals<readonly ["article", "api-module", "component"]>;
    readonly markdownUrl: Schema.String;
    readonly title: Schema.String;
    readonly url: Schema.String;
    readonly version: Schema.optionalKey<Schema.String>;
}>;
export declare const AgentSkillArtifactSchema: Schema.Struct<{
    readonly archive: Schema.String;
    readonly checksum: Schema.String;
    readonly directory: Schema.String;
    readonly name: Schema.String;
}>;
export declare const AgentManifestSchema: Schema.Struct<{
    readonly checksum: Schema.String;
    readonly documents: Schema.$Array<Schema.Struct<{
        readonly checksum: Schema.String;
        readonly id: Schema.String;
        readonly kind: Schema.Literals<readonly ["article", "api-module", "component"]>;
        readonly markdownUrl: Schema.String;
        readonly title: Schema.String;
        readonly url: Schema.String;
        readonly version: Schema.optionalKey<Schema.String>;
    }>>;
    readonly generatedAt: Schema.String;
    readonly mcpEndpoint: Schema.optionalKey<Schema.String>;
    readonly skills: Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly archive: Schema.String;
        readonly checksum: Schema.String;
        readonly directory: Schema.String;
        readonly name: Schema.String;
    }>>>;
    readonly version: Schema.Literals<readonly [1]>;
    readonly versions: Schema.$Array<Schema.String>;
}>;
export declare const AgentCorpusSchema: Schema.Struct<{
    readonly checksum: Schema.String;
    readonly documents: Schema.$Array<Schema.Struct<{
        readonly content: Schema.String;
        readonly context: Schema.optionalKey<Schema.String>;
        readonly description: Schema.optionalKey<Schema.String>;
        readonly id: Schema.String;
        readonly kind: Schema.Literals<readonly ["article", "api-module", "component"]>;
        readonly metadata: Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>;
        readonly source: Schema.optionalKey<Schema.Struct<{
            readonly endLine: Schema.optionalKey<Schema.Number>;
            readonly file: Schema.String;
            readonly line: Schema.optionalKey<Schema.Number>;
            readonly repositoryUrl: Schema.String;
            readonly revision: Schema.String;
        }>>;
        readonly title: Schema.String;
        readonly url: Schema.String;
        readonly version: Schema.optionalKey<Schema.String>;
    }>>;
    readonly generatedAt: Schema.String;
    readonly sourceRevision: Schema.optionalKey<Schema.String>;
    readonly version: Schema.Literals<readonly [1]>;
}>;
export declare const AgentSkillConfigSchema: Schema.Struct<{
    readonly enabled: Schema.Boolean;
    readonly name: Schema.String;
}>;
export declare const AgentConfigSchema: Schema.Struct<{
    readonly description: Schema.optionalKey<Schema.String>;
    readonly enabled: Schema.Boolean;
    readonly essentials: Schema.$Array<Schema.String>;
    readonly mcp: Schema.Struct<{
        readonly enabled: Schema.Boolean;
    }>;
    readonly skill: Schema.Struct<{
        readonly enabled: Schema.Boolean;
        readonly name: Schema.String;
    }>;
}>;
export declare const DocsConfigInputSchema: Schema.Struct<{
    readonly agent: Schema.optionalKey<Schema.Struct<{
        readonly description: Schema.optionalKey<Schema.String>;
        readonly enabled: Schema.optionalKey<Schema.Boolean>;
        readonly essentials: Schema.optionalKey<Schema.$Array<Schema.String>>;
        readonly mcp: Schema.optionalKey<Schema.Struct<{
            readonly enabled: Schema.optionalKey<Schema.Boolean>;
        }>>;
        readonly skill: Schema.optionalKey<Schema.Struct<{
            readonly enabled: Schema.optionalKey<Schema.Boolean>;
            readonly name: Schema.optionalKey<Schema.String>;
        }>>;
    }>>;
    readonly api: Schema.optionalKey<Schema.Struct<{
        readonly enabled: Schema.optionalKey<Schema.Boolean>;
        readonly entryPoints: Schema.optionalKey<Schema.$Array<Schema.String>>;
        readonly outputDirectory: Schema.optionalKey<Schema.String>;
        readonly packages: Schema.optionalKey<Schema.$Array<Schema.String>>;
        readonly sourceRepository: Schema.optionalKey<Schema.Struct<{
            readonly branch: Schema.optionalKey<Schema.String>;
            readonly directory: Schema.optionalKey<Schema.String>;
            readonly url: Schema.String;
        }>>;
        readonly typedoc: Schema.optionalKey<Schema.$Record<Schema.String, Schema.Unknown>>;
    }>>;
    readonly landing: Schema.optionalKey<Schema.Struct<{
        readonly description: Schema.optionalKey<Schema.String>;
        readonly primaryAction: Schema.optionalKey<Schema.Struct<{
            readonly href: Schema.String;
            readonly label: Schema.String;
        }>>;
        readonly sections: Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly body: Schema.optionalKey<Schema.String>;
            readonly href: Schema.optionalKey<Schema.String>;
            readonly id: Schema.String;
            readonly title: Schema.String;
        }>>>;
        readonly title: Schema.optionalKey<Schema.String>;
    }>>;
    readonly manifests: Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly checksum: Schema.optionalKey<Schema.String>;
        readonly generatedAt: Schema.optionalKey<Schema.String>;
        readonly kind: Schema.Literals<readonly ["site", "api-reference", "storybook", "project"]>;
        readonly path: Schema.String;
        readonly revision: Schema.optionalKey<Schema.String>;
    }>>>;
    readonly metadata: Schema.optionalKey<Schema.Struct<{
        readonly description: Schema.optionalKey<Schema.String>;
        readonly logo: Schema.optionalKey<Schema.String>;
        readonly name: Schema.optionalKey<Schema.String>;
        readonly repository: Schema.optionalKey<Schema.Struct<{
            readonly branch: Schema.optionalKey<Schema.String>;
            readonly directory: Schema.optionalKey<Schema.String>;
            readonly url: Schema.String;
        }>>;
        readonly title: Schema.optionalKey<Schema.String>;
        readonly url: Schema.optionalKey<Schema.String>;
    }>>;
    readonly navigation: Schema.optionalKey<Schema.Struct<{
        readonly groups: Schema.optionalKey<Schema.$Array<Schema.Struct<{
            readonly id: Schema.String;
            readonly items: Schema.$Array<Schema.Schema<NavigationItemInput>>;
            readonly label: Schema.String;
        }>>>;
    }>>;
    readonly packages: Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly description: Schema.optionalKey<Schema.String>;
        readonly directory: Schema.optionalKey<Schema.String>;
        readonly id: Schema.String;
        readonly name: Schema.String;
        readonly source: Schema.optionalKey<Schema.Struct<{
            readonly branch: Schema.optionalKey<Schema.String>;
            readonly directory: Schema.optionalKey<Schema.String>;
            readonly url: Schema.String;
        }>>;
        readonly version: Schema.optionalKey<Schema.String>;
    }>>>;
    readonly redirects: Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly from: Schema.String;
        readonly status: Schema.optionalKey<Schema.Literals<readonly [301, 302]>>;
        readonly to: Schema.String;
    }>>>;
    readonly routing: Schema.optionalKey<Schema.Struct<{
        readonly documentationPrefix: Schema.optionalKey<Schema.String>;
        readonly storybookPrefix: Schema.optionalKey<Schema.String>;
    }>>;
    readonly storybook: Schema.optionalKey<Schema.Struct<{
        readonly command: Schema.optionalKey<Schema.String>;
        readonly directory: Schema.optionalKey<Schema.String>;
        readonly enabled: Schema.optionalKey<Schema.Boolean>;
        readonly stories: Schema.optionalKey<Schema.$Array<Schema.String>>;
        readonly url: Schema.optionalKey<Schema.String>;
    }>>;
    readonly tokens: Schema.optionalKey<Schema.Struct<{
        readonly dark: Schema.optionalKey<Schema.Struct<{
            readonly accent: Schema.optionalKey<Schema.String>;
            readonly background: Schema.optionalKey<Schema.String>;
            readonly border: Schema.optionalKey<Schema.String>;
            readonly codeBackground: Schema.optionalKey<Schema.String>;
            readonly foreground: Schema.optionalKey<Schema.String>;
            readonly muted: Schema.optionalKey<Schema.String>;
        }>>;
        readonly light: Schema.optionalKey<Schema.Struct<{
            readonly accent: Schema.optionalKey<Schema.String>;
            readonly background: Schema.optionalKey<Schema.String>;
            readonly border: Schema.optionalKey<Schema.String>;
            readonly codeBackground: Schema.optionalKey<Schema.String>;
            readonly foreground: Schema.optionalKey<Schema.String>;
            readonly muted: Schema.optionalKey<Schema.String>;
        }>>;
    }>>;
    readonly vercel: Schema.optionalKey<Schema.Struct<{
        readonly domains: Schema.optionalKey<Schema.$Array<Schema.String>>;
        readonly enabled: Schema.optionalKey<Schema.Boolean>;
        readonly outputDirectory: Schema.optionalKey<Schema.String>;
        readonly productionBranch: Schema.optionalKey<Schema.String>;
        readonly project: Schema.optionalKey<Schema.String>;
        readonly projects: Schema.optionalKey<Schema.Struct<{
            readonly documentation: Schema.optionalKey<Schema.Struct<{
                readonly directory: Schema.optionalKey<Schema.String>;
                readonly id: Schema.optionalKey<Schema.String>;
                readonly origin: Schema.optionalKey<Schema.String>;
                readonly productionBranch: Schema.optionalKey<Schema.String>;
                readonly project: Schema.optionalKey<Schema.String>;
                readonly routePrefix: Schema.optionalKey<Schema.String>;
                readonly team: Schema.optionalKey<Schema.String>;
            }>>;
            readonly landing: Schema.optionalKey<Schema.Struct<{
                readonly directory: Schema.optionalKey<Schema.String>;
                readonly id: Schema.optionalKey<Schema.String>;
                readonly origin: Schema.optionalKey<Schema.String>;
                readonly productionBranch: Schema.optionalKey<Schema.String>;
                readonly project: Schema.optionalKey<Schema.String>;
                readonly routePrefix: Schema.optionalKey<Schema.String>;
                readonly team: Schema.optionalKey<Schema.String>;
            }>>;
            readonly mcp: Schema.optionalKey<Schema.Struct<{
                readonly directory: Schema.optionalKey<Schema.String>;
                readonly id: Schema.optionalKey<Schema.String>;
                readonly origin: Schema.optionalKey<Schema.String>;
                readonly productionBranch: Schema.optionalKey<Schema.String>;
                readonly project: Schema.optionalKey<Schema.String>;
                readonly routePrefix: Schema.optionalKey<Schema.String>;
                readonly team: Schema.optionalKey<Schema.String>;
            }>>;
            readonly storybook: Schema.optionalKey<Schema.Struct<{
                readonly directory: Schema.optionalKey<Schema.String>;
                readonly id: Schema.optionalKey<Schema.String>;
                readonly origin: Schema.optionalKey<Schema.String>;
                readonly productionBranch: Schema.optionalKey<Schema.String>;
                readonly project: Schema.optionalKey<Schema.String>;
                readonly routePrefix: Schema.optionalKey<Schema.String>;
                readonly team: Schema.optionalKey<Schema.String>;
            }>>;
        }>>;
        readonly team: Schema.optionalKey<Schema.String>;
    }>>;
    readonly versions: Schema.optionalKey<Schema.$Array<Schema.Struct<{
        readonly current: Schema.optionalKey<Schema.Boolean>;
        readonly directory: Schema.optionalKey<Schema.String>;
        readonly href: Schema.optionalKey<Schema.String>;
        readonly id: Schema.String;
        readonly label: Schema.optionalKey<Schema.String>;
        readonly order: Schema.optionalKey<Schema.Number>;
        readonly version: Schema.optionalKey<Schema.String>;
    }>>>;
}>;
/** @internal */
export type SiteMetadata = Schema.Schema.Type<typeof SiteMetadataSchema>;
/** @internal */
export type DesignTokens = Schema.Schema.Type<typeof DesignTokensSchema>;
/** @internal */
export type DocumentationVersion = Schema.Schema.Type<typeof DocumentationVersionSchema>;
/** @internal */
export type PackageReference = Schema.Schema.Type<typeof PackageReferenceSchema>;
/** @internal */
export type LandingContent = Schema.Schema.Type<typeof LandingContentSchema>;
/** @internal */
export type Redirect = Schema.Schema.Type<typeof RedirectSchema>;
/** @internal */
export type StorybookConfig = Schema.Schema.Type<typeof StorybookConfigSchema>;
/** @internal */
export type ApiGenerationConfig = Schema.Schema.Type<typeof ApiGenerationConfigSchema>;
/** @internal */
export type SiteRouting = Schema.Schema.Type<typeof SiteRoutingSchema>;
/** @internal */
export type VercelProject = Schema.Schema.Type<typeof VercelProjectSchema>;
/** @internal */
export type VercelProjects = Schema.Schema.Type<typeof VercelProjectsSchema>;
/** @internal */
export type VercelDeployment = Schema.Schema.Type<typeof VercelDeploymentSchema>;
/** @internal */
export type VercelReleaseManifest = Schema.Schema.Type<typeof VercelReleaseManifestSchema>;
/** @internal */
export type VercelConfig = Schema.Schema.Type<typeof VercelConfigSchema>;
/** @internal */
export type GeneratedManifest = Schema.Schema.Type<typeof GeneratedManifestSchema>;
/** @internal */
export type ApiReferenceBreadcrumb = Schema.Schema.Type<typeof ApiReferenceBreadcrumbSchema>;
/** @internal */
export type ApiReferenceCategory = Schema.Schema.Type<typeof ApiReferenceCategorySchema>;
/** @internal */
export type ApiReferenceSource = Schema.Schema.Type<typeof ApiReferenceSourceSchema>;
/** @internal */
export type StableLink = Schema.Schema.Type<typeof StableLinkSchema>;
/** @internal */
export type ApiReferenceDeclaration = Schema.Schema.Type<typeof ApiReferenceDeclarationSchema>;
/** @internal */
export type ApiReferenceRecord = Schema.Schema.Type<typeof ApiReferenceRecordSchema>;
/** @internal */
export type AgentDocument = Schema.Schema.Type<typeof AgentDocumentSchema>;
/** @internal */
export type AgentManifestEntry = Schema.Schema.Type<typeof AgentManifestEntrySchema>;
/** @internal */
export type AgentManifest = Schema.Schema.Type<typeof AgentManifestSchema>;
/** @internal */
export type AgentSearchIndex = Schema.Schema.Type<typeof AgentSearchIndexSchema>;
/** @internal */
export type AgentCorpus = Schema.Schema.Type<typeof AgentCorpusSchema>;
/** @internal */
export type AgentConfig = Schema.Schema.Type<typeof AgentConfigSchema>;
/** @internal */
export type AgentSkillConfig = Schema.Schema.Type<typeof AgentSkillConfigSchema>;
/** @internal */
export type AgentSkillArtifact = Schema.Schema.Type<typeof AgentSkillArtifactSchema>;
/** @internal */
export type DocsConfigInput = Schema.Schema.Type<typeof DocsConfigInputSchema>;
//# sourceMappingURL=Schemas.d.ts.map