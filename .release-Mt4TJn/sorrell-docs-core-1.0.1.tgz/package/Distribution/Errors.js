/**
 *
 *
 * @module @sorrell/docs-core/Errors
 *
 * @file      Errors.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { Data } from "effect";
/** @internal */
export class DocsConfigError extends Data.TaggedError("DocsConfigError") {
    get message() {
        return this.diagnostics.map(formatDiagnostic).join("\n");
    }
}
export /** @internal */ const formatConfigPath = (path) => {
    if (path.length === 0) {
        return "$";
    }
    return path.reduce((result, segment) => typeof segment === "number"
        ? `${result}[${segment}]`
        : `${result}.${String(segment)}`, "$");
};
export /** @internal */ const formatDiagnostic = (diagnostic) => {
    const expected = diagnostic.expected === undefined
        ? ""
        : ` (expected ${diagnostic.expected})`;
    return `${formatConfigPath(diagnostic.path)}: ${diagnostic.message}${expected}`;
};
//# sourceMappingURL=Errors.js.map