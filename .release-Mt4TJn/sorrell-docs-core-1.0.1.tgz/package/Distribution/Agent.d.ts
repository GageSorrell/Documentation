/**
 * Shared agent-document model and deterministic Markdown formatting.
 *
 * @module @sorrell/docs-core/Agent
 *
 * @file      Agent.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import type { AgentDocument, ApiReferenceRecord } from "./Schemas.js";
/** @internal */
export interface AgentMarkdownDiagnostic {
    readonly code: "unresolved-mdx-component" | "unsupported-html";
    readonly message: string;
    readonly line: number;
}
/** @internal */
export interface AgentMarkdownResult {
    readonly markdown: string;
    readonly diagnostics: ReadonlyArray<AgentMarkdownDiagnostic>;
}
export declare const normalizeAgentMarkdown: (value: string) => AgentMarkdownResult;
export declare const formatAgentDocument: (document: AgentDocument) => string;
export declare const apiReferenceRecordToAgentDocument: (record: ApiReferenceRecord) => AgentDocument;
//# sourceMappingURL=Agent.d.ts.map