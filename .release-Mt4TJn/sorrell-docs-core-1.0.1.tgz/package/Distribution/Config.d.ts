/**
 *
 *
 * @module @sorrell/docs-core/Config
 *
 * @file      Config.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { type AgentConfig, type ApiGenerationConfig, type DesignTokens, type DocsConfigInput, type DocumentationVersion, type GeneratedManifest, type LandingContent, type Navigation, type PackageReference, type Redirect, type SiteMetadata, type SiteRouting, type StorybookConfig, type VercelConfig } from "./Schemas.js";
import { DocsConfigError } from "./Errors.js";
import { Effect, Result } from "effect";
/** @internal */
export interface DocsConfig {
    readonly metadata: SiteMetadata;
    readonly tokens: DesignTokens;
    readonly navigation: Navigation;
    readonly versions: ReadonlyArray<DocumentationVersion>;
    readonly packages: ReadonlyArray<PackageReference>;
    readonly landing: LandingContent;
    readonly redirects: ReadonlyArray<Redirect>;
    readonly storybook: StorybookConfig;
    readonly api: ApiGenerationConfig;
    readonly agent: AgentConfig;
    readonly mcpEndpoint: string;
    readonly routing: SiteRouting;
    readonly vercel: VercelConfig;
    readonly manifests: ReadonlyArray<GeneratedManifest>;
}
export declare const DefaultDesignTokens: DesignTokens;
export declare const normalizeDocsConfig: (input: DocsConfigInput) => DocsConfig;
export declare const decodeDocsConfig: (input: unknown) => Result.Result<DocsConfig, DocsConfigError>;
export declare const decodeDocsConfigSync: (input: unknown) => DocsConfig;
export declare const decodeDocsConfigEffect: (input: unknown) => Effect.Effect<DocsConfig, DocsConfigError>;
//# sourceMappingURL=Config.d.ts.map