/**
 *
 *
 * @module @sorrell/docs-core/Config
 *
 * @file      Config.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
import { AgentConfigSchema, AgentSkillConfigSchema, ApiGenerationConfigSchema, DesignTokensSchema, DocsConfigInputSchema, DocumentationVersionSchema, GeneratedManifestSchema, LandingContentSchema, NavigationSchema, PackageReferenceSchema, RedirectSchema, SiteMetadataSchema, SiteRoutingSchema, StorybookConfigSchema, VercelConfigSchema } from "./Schemas.js";
import { DocsConfigError } from "./Errors.js";
import { Effect, Result, Schema, SchemaIssue } from "effect";
const decodeAs = (schema, value) => Schema.decodeUnknownSync(schema)(value);
const omitUndefined = (value) => Object.fromEntries(Object.entries(value).filter(([, entry]) => entry !== undefined));
const defaultColors = {
    accent: "#2563eb",
    background: "#ffffff",
    border: "#e5e7eb",
    codeBackground: "#f3f4f6",
    foreground: "#111111",
    muted: "#6b7280"
};
const defaultDarkColors = {
    accent: "#93c5fd",
    background: "#09090b",
    border: "#27272a",
    codeBackground: "#18181b",
    foreground: "#f4f4f5",
    muted: "#a1a1aa"
};
export /** @internal */ const DefaultDesignTokens = {
    dark: defaultDarkColors,
    light: defaultColors
};
const mergeColors = (base, value) => ({
    ...base,
    ...value
});
const sortedByOrder = (values) => [...values].sort((left, right) => left.order - right.order || left.id.localeCompare(right.id));
const uniqueDiagnostics = (diagnostics) => {
    const seen = new Set();
    return diagnostics.filter((diagnostic) => {
        const key = `${diagnostic.path.join(".")}:${diagnostic.message}`;
        if (seen.has(key)) {
            return false;
        }
        seen.add(key);
        return true;
    });
};
const routePrefixesOverlap = (left, right) => left === right ||
    left.startsWith(`${right}/`) ||
    right.startsWith(`${left}/`);
const issuePath = (issue, prefix = []) => {
    switch (issue._tag) {
        case "Pointer":
            return issuePath(issue.issue, [
                ...prefix,
                ...issue.path.filter((segment) => typeof segment === "string" ||
                    typeof segment === "number")
            ]);
        case "Composite":
        case "AnyOf":
            return issue.issues.flatMap((child) => issuePath(child, prefix));
        case "Filter":
        case "Encoding":
            return issuePath(issue.issue, prefix);
        default:
            return [
                {
                    expected: "valid configuration value",
                    message: SchemaIssue.makeFormatterDefault()(issue),
                    path: prefix
                }
            ];
    }
};
const decodeInput = (input) => {
    const decoded = Schema.decodeUnknownResult(DocsConfigInputSchema)(input);
    if (Result.isFailure(decoded)) {
        return Result.fail(new DocsConfigError({
            diagnostics: uniqueDiagnostics(issuePath(decoded.failure.issue))
        }));
    }
    return Result.succeed(decoded.success);
};
const duplicateDiagnostics = (name, values) => {
    const counts = new Map();
    for (const value of values) {
        counts.set(value.id, (counts.get(value.id) ?? 0) + 1);
    }
    return [...counts.entries()]
        .filter(([, count]) => count > 1)
        .map(([id]) => ({
        expected: "unique identifiers",
        message: `duplicate id "${id}"`,
        path: [name, id]
    }));
};
const validate = (config) => {
    const diagnostics = [];
    if (config.metadata.name.trim() === "") {
        diagnostics.push({
            message: "must not be empty",
            path: ["metadata", "name"]
        });
    }
    if (config.metadata.title.trim() === "") {
        diagnostics.push({
            message: "must not be empty",
            path: ["metadata", "title"]
        });
    }
    if (config.metadata.url !== "" &&
        !/^https?:\/\//.test(config.metadata.url)) {
        diagnostics.push({
            message: "must be an http(s) URL",
            path: ["metadata", "url"]
        });
    }
    if (config.agent.skill.enabled &&
        (config.agent.description === undefined ||
            config.agent.description.trim() === "")) {
        diagnostics.push({
            message: "is required when agent.skill.enabled is true",
            path: ["agent", "description"]
        });
    }
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(config.agent.skill.name)) {
        diagnostics.push({
            message: "must be a kebab-case identifier",
            path: ["agent", "skill", "name"]
        });
    }
    diagnostics.push(...duplicateDiagnostics("versions", config.versions));
    diagnostics.push(...duplicateDiagnostics("packages", config.packages));
    for (const [index, redirect] of config.redirects.entries()) {
        if (!redirect.from.startsWith("/")) {
            diagnostics.push({
                message: "must begin with /",
                path: ["redirects", index, "from"]
            });
        }
        if (!redirect.to.startsWith("/")) {
            diagnostics.push({
                message: "must begin with /",
                path: ["redirects", index, "to"]
            });
        }
    }
    for (const [index, version] of config.versions.entries()) {
        if (!/^[a-z0-9][a-z0-9-]*$/.test(version.id)) {
            diagnostics.push({
                message: "must be a lowercase URL-safe identifier",
                path: ["versions", index, "id"]
            });
        }
    }
    for (const [name, prefix] of Object.entries(config.routing)) {
        if (!prefix.startsWith("/")) {
            diagnostics.push({
                message: "must begin with /",
                path: ["routing", name]
            });
        }
        if (prefix !== "/" && prefix.endsWith("/")) {
            diagnostics.push({
                message: "must not end with /",
                path: ["routing", name]
            });
        }
        if (prefix === "/") {
            diagnostics.push({
                message: "must not be / because / belongs to the landing package",
                path: ["routing", name]
            });
        }
    }
    if (routePrefixesOverlap(config.routing.documentationPrefix, config.routing.storybookPrefix)) {
        diagnostics.push({
            message: "documentationPrefix and storybookPrefix must not overlap",
            path: ["routing"]
        });
    }
    if (config.vercel.projects.landing.routePrefix !== "/") {
        diagnostics.push({
            message: "must be / because Landing owns the public root",
            path: ["vercel", "projects", "landing", "routePrefix"]
        });
    }
    if (config.vercel.projects.documentation.routePrefix !==
        config.routing.documentationPrefix) {
        diagnostics.push({
            message: "must match routing.documentationPrefix",
            path: ["vercel", "projects", "documentation", "routePrefix"]
        });
    }
    if (config.vercel.projects.storybook !== undefined &&
        config.vercel.projects.storybook.routePrefix !==
            config.routing.storybookPrefix) {
        diagnostics.push({
            message: "must match routing.storybookPrefix",
            path: ["vercel", "projects", "storybook", "routePrefix"]
        });
    }
    if (config.agent.mcp.enabled && config.metadata.url === "") {
        diagnostics.push({
            message: "is required when agent.mcp.enabled is true",
            path: ["metadata", "url"]
        });
    }
    if (config.agent.mcp.enabled && config.vercel.projects.mcp === undefined) {
        diagnostics.push({
            message: "is required when agent.mcp.enabled is true",
            path: ["vercel", "projects", "mcp"]
        });
    }
    return uniqueDiagnostics(diagnostics);
};
export /** @internal */ const normalizeDocsConfig = (input) => {
    const metadataInput = input.metadata ?? {};
    const metadata = decodeAs(SiteMetadataSchema, omitUndefined({
        description: metadataInput.description ??
            "Documentation generated with Sorrell documentation tooling.",
        logo: metadataInput.logo,
        name: metadataInput.name ?? "Sorrell Documentation",
        repository: metadataInput.repository,
        title: metadataInput.title ??
            metadataInput.name ??
            "Sorrell Documentation",
        url: metadataInput.url ?? ""
    }));
    const tokenInput = input.tokens ?? {};
    const tokens = decodeAs(DesignTokensSchema, {
        dark: mergeColors(defaultDarkColors, tokenInput.dark),
        light: mergeColors(defaultColors, tokenInput.light)
    });
    const navigation = decodeAs(NavigationSchema, {
        groups: (input.navigation?.groups ?? []).map((group) => ({
            id: group.id,
            items: group.items.map((item) => ({
                ...item,
                kind: item.kind ?? "page"
            })),
            label: group.label
        }))
    });
    const versions = sortedByOrder((input.versions ?? [
        {
            current: true,
            directory: ".",
            id: "current",
            label: "Current",
            order: 0
        }
    ]).map((version, index) => decodeAs(DocumentationVersionSchema, omitUndefined({
        current: version.current ?? index === 0,
        directory: version.directory ?? version.id,
        href: version.href,
        id: version.id,
        label: version.label ?? version.version ?? version.id,
        order: version.order ?? index,
        version: version.version
    }))));
    const packages = [...(input.packages ?? [])]
        .map((value) => ({ ...value }))
        .sort((left, right) => left.id.localeCompare(right.id))
        .map((value) => decodeAs(PackageReferenceSchema, omitUndefined({
        description: value.description,
        directory: value.directory,
        id: value.id,
        name: value.name,
        source: value.source,
        version: value.version
    })));
    const landing = decodeAs(LandingContentSchema, omitUndefined({
        description: input.landing?.description ?? metadata.description,
        primaryAction: input.landing?.primaryAction,
        sections: (input.landing?.sections ?? []).map((section) => ({
            ...section,
            body: section.body ?? ""
        })),
        title: input.landing?.title ?? metadata.title
    }));
    const redirects = [...(input.redirects ?? [])]
        .map((redirect) => decodeAs(RedirectSchema, {
        from: redirect.from,
        status: redirect.status ?? 301,
        to: redirect.to
    }))
        .sort((left, right) => left.from.localeCompare(right.from));
    const storybook = decodeAs(StorybookConfigSchema, omitUndefined({
        command: input.storybook?.command,
        directory: input.storybook?.directory,
        enabled: input.storybook?.enabled ?? false,
        stories: input.storybook?.stories ?? [],
        url: input.storybook?.url
    }));
    const api = decodeAs(ApiGenerationConfigSchema, omitUndefined({
        enabled: input.api?.enabled ?? false,
        entryPoints: input.api?.entryPoints ?? [],
        outputDirectory: input.api?.outputDirectory ?? "Documentation/Api",
        packages: input.api?.packages ?? [],
        sourceRepository: input.api?.sourceRepository,
        typedoc: input.api?.typedoc ?? {}
    }));
    const defaultSkillName = (metadata.name || "product-documentation")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "") || "product-documentation";
    const skill = decodeAs(AgentSkillConfigSchema, {
        enabled: input.agent?.skill?.enabled ?? false,
        name: input.agent?.skill?.name ?? defaultSkillName
    });
    const agent = decodeAs(AgentConfigSchema, omitUndefined({
        description: input.agent?.description,
        enabled: input.agent?.enabled ?? true,
        essentials: input.agent?.essentials ?? [],
        mcp: { enabled: input.agent?.mcp?.enabled ?? false },
        skill
    }));
    const routing = decodeAs(SiteRoutingSchema, {
        documentationPrefix: input.routing?.documentationPrefix ?? "/docs",
        storybookPrefix: input.routing?.storybookPrefix ?? "/storybook"
    });
    const vercelInput = input.vercel;
    const projectInput = vercelInput?.projects;
    const landingProject = projectInput?.landing;
    const documentationProject = projectInput?.documentation;
    const storybookProject = projectInput?.storybook;
    const mcpProject = projectInput?.mcp;
    const projectConfig = (value, directory, routePrefix, fallbackProject) => omitUndefined({
        directory: value?.directory ?? directory,
        id: value?.id,
        origin: value?.origin,
        productionBranch: value?.productionBranch ?? vercelInput?.productionBranch,
        project: value?.project ?? fallbackProject,
        routePrefix: value?.routePrefix ?? routePrefix,
        team: value?.team ?? vercelInput?.team
    });
    const projects = omitUndefined({
        documentation: projectConfig(documentationProject, "Documentation", routing.documentationPrefix),
        landing: projectConfig(landingProject, "Landing", "/", vercelInput?.project),
        mcp: agent.mcp.enabled
            ? projectConfig(mcpProject, "Mcp", "/")
            : undefined,
        storybook: storybook.enabled
            ? projectConfig(storybookProject, "Storybook", routing.storybookPrefix)
            : undefined
    });
    const vercel = decodeAs(VercelConfigSchema, omitUndefined({
        domains: vercelInput?.domains ?? [],
        enabled: vercelInput?.enabled ?? false,
        outputDirectory: vercelInput?.outputDirectory ?? ".",
        productionBranch: vercelInput?.productionBranch ?? "Master",
        project: vercelInput?.project,
        projects,
        team: vercelInput?.team
    }));
    const manifests = (input.manifests ?? []).map((manifest) => decodeAs(GeneratedManifestSchema, manifest));
    const mcpEndpoint = metadata.url === ""
        ? "https://mcp.localhost"
        : `https://mcp.${new URL(metadata.url).host.replace(/^www\./u, "")}`;
    return {
        agent,
        api,
        landing,
        manifests,
        mcpEndpoint,
        metadata,
        navigation,
        packages,
        redirects,
        routing,
        storybook,
        tokens,
        vercel,
        versions
    };
};
export /** @internal */ const decodeDocsConfig = (input) => {
    const decoded = decodeInput(input);
    if (Result.isFailure(decoded)) {
        return Result.fail(decoded.failure);
    }
    const normalized = normalizeDocsConfig(decoded.success);
    const diagnostics = validate(normalized);
    return diagnostics.length > 0
        ? Result.fail(new DocsConfigError({ diagnostics }))
        : Result.succeed(normalized);
};
export /** @internal */ const decodeDocsConfigSync = (input) => {
    const decoded = decodeDocsConfig(input);
    if (Result.isFailure(decoded)) {
        throw decoded.failure;
    }
    return decoded.success;
};
export /** @internal */ const decodeDocsConfigEffect = (input) => Effect.suspend(() => {
    const decoded = decodeDocsConfig(input);
    return Result.isFailure(decoded)
        ? Effect.fail(decoded.failure)
        : Effect.succeed(decoded.success);
});
//# sourceMappingURL=Config.js.map