/**
 *
 *
 * @module @sorrell/docs-core/Errors
 *
 * @file      Errors.ts
 * @author    Gage Sorrell <gage@sorrell.sh>
 * @copyright (c) 2026 Gage Sorrell
 * @license   MIT
 */
/** @internal */
export type ConfigPathSegment = string | number;
/** @internal */
export interface DocsConfigDiagnostic {
    readonly path: ReadonlyArray<ConfigPathSegment>;
    readonly message: string;
    readonly expected?: string;
    readonly actual?: unknown;
}
declare const DocsConfigError_base: new <A extends Record<string, any> = {}>(args: import("effect/Types").VoidIfEmpty<{ readonly [P in keyof A as P extends "_tag" ? never : P]: A[P]; }>) => import("effect/Cause").YieldableError & {
    readonly _tag: "DocsConfigError";
} & Readonly<A>;
/** @internal */
export declare class DocsConfigError extends DocsConfigError_base<{
    readonly diagnostics: ReadonlyArray<DocsConfigDiagnostic>;
}> {
    get message(): string;
}
export declare const formatConfigPath: (path: ReadonlyArray<ConfigPathSegment>) => string;
export declare const formatDiagnostic: (diagnostic: DocsConfigDiagnostic) => string;
export {};
//# sourceMappingURL=Errors.d.ts.map